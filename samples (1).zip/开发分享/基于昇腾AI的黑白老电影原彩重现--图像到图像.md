 **如何使老电影色彩还原？** 
本文有视频直播回放（http://live.vhall.com/880314441）
当然是使用神经网络对图片一帧帧上色，先看效果：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/150108_9739fa72_5651712.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/150143_6949ed3c_5651712.png "屏幕截图.png")

 **黑白图像上色神经网络模型** 
在理解神经网络模型之前，先理解几个基本概念；
1. Lab颜色空间：
L分量用于表示像素的亮度，取值范围是[0,100],表示从纯黑到纯白；
a表示从红色到绿色的范围，取值范围是[127,-128]；
b表示从黄色到蓝色的范围，取值范围是[127,-128]
![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/150553_23c19d60_5651712.png "屏幕截图.png")

2. 卷积
dilation = 0 的普通卷积 以及 dilation > 0的空洞卷积（增大感受野）
![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/150632_6812420f_5651712.png "屏幕截图.png")
图片来自：https://www.jianshu.com/p/f743bd9041b3

3. 反卷积
可以用作上采样的反卷积，例如：pading = 1 dilation =1   stride = 2
![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/151038_30347360_5651712.png "屏幕截图.png")
图片来自：https://www.zhihu.com/question/48279880

4. 卷积核/卷积通道/卷积核数量/featuremap数量
![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/151213_d5fee015_5651712.png "屏幕截图.png")
图片来自：https://blog.csdn.net/Xiao_Bai_Ke/article/details/98998767

 **接下来看黑白图像上色神经网络模型，并尝试理解** 
给黑白照片着色是从灰度一维到 RGB 三维的转换，这是一个无定解的（underconstrained）问题。
思路：对物件（包括背景色）（L通道代表的灰度图）使用卷积运算提取特征，然后同样用卷积进行分类，从而尝试给出对灰度图片每个像素点的色彩预期(ab通道)，然后再转为RGB。
输入：L通道数据（224，224，1）输出：ab通道数据（56，56，2）
![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/151555_ba01b7df_5651712.png "屏幕截图.png")
图片来自：https://hackernoon.com/colorising-black-white-photos-using-deep-learning-4da22a05f531
原始网络来自：github：https://github.com/richzhang/colorization

对该神经网络的计算过程解析，我这里不厌其烦的将每个计算过程都罗列在这里，只是为了帮助大家理解神经网络的工作过程和计算量，如果觉得烦的可跳过；
CONV1： 
224x224x3   （3x3x3） 64   =》  224x224x64    ReLU
224x224x64   (3x3x64)x64  stride=2 => 112x112x64 Relu + BatchNorm

CONV2
112x112x64  (3x3x64) x128 => 112x112x128 Relu
112x112x128  (3x3x128) x128  stride=2 => 56x56x128 Relu + BatchNorm

CONV3
56x56x128 (3x3x128)x256 => 56x56x256 Relu
56x56x256 (3x3x256)x256 => 56x56x256 Relu
56x56x256 (3x3x256)x256 stride=2 => 28x28x256 Relu + BatchNorm

CONV4
28x28x256 (3x3x256)x512 dilation=1 => 28x28x512 Relu
28x28x512 (3x3x512)x512 dilation=1 => 28x28x512 Relu
28x28x512 (3x3x512)x512 dilation=1 => 28x28x512 Batchnorm

CONV5
28x28x512 (3x3x512)x512 dilation=2 => 28x28x512 Relu
28x28x512 (3x3x512)x512 dilation=2 => 28x28x512 Relu
28x28x512 (3x3x512)x512 dilation=2 => 28x28x512 Batchnorm

CONV6
28x28x512 (3x3x512)x512 dilation=2 => 28x28x512 Relu
28x28x512 (3x3x512)x512 dilation=2 => 28x28x512 Relu
28x28x512 (3x3x512)x512 dilation=2 => 28x28x512 Batchnorm

CONV7
28x28x512 (3x3x512)x512 dilation=1 => 28x28x512 Relu
28x28x512 (3x3x512)x512 dilation=1 => 28x28x512 Relu
28x28x512 (3x3x512)x512 dilation=1 => 28x28x512 Batchnorm

Conv8 
反卷积 28x28x512 (4x5x512)x256 stride=2 dilation=1 => 56x56x256 Relu
56x56x256 （3x3x256)x256 dilation=1 => 56x56x256 Relu
56x56x256 （3x3x256)x256 dilation=1 => 56x56x256 Relu

Softmax（用softmax做分类预测每个分类（313个AB对）的概率值）
56x56x256 (1x1x256)x313 dilation=1 => 56x56x313 Scale + softmax

Decoding（用1x1的卷积决定最终选择的某个AB对）
56x56x313 （1x1x313)x2 => 56x56x2   即56x56个（a,b）

根据上面分析的计算过程，我不难看出其中的计算量是多么的惊人：
譬如说特征提取过程，以Conv4第二次卷积计算为例：
计算量估计:（28*28） * （3* 3*512）*512 = 3406823424  = 3.4 * 10^9
参数量估计：（3* 3*512）*512 = 2359296 = 2.35 * 10^6
 
预测(313类）过程：
(56，56，256） 卷积 (1，1，256）卷积核数：313  => 56*56*313
(56，56，313） 卷积（1，1，313)  卷积核数：2 	 => 56*56*2
则计算量：
56*56*1*1*256*313 + 56*56*1*1*313*2 = 253244544 = 2.53*10^8
参数量：1*1*256*313 +  1*1*313*2 = 80754


那么接下来，我们通过开源模型的测试脚本来理解原始模型的输入和输出，以及输入前的计算过程（也叫前处理）和输出后的处理过程（也叫后处理）
通过源测试脚本研究模型推理过程：https://github.com/richzhang/colorization/blob/master/colorization/colorize.py
预处理过程：RGB格式读入转Lab，resize到224*224，提取L通道，减均值（-50）
后处理过程：推理的结果ab通道，resize到224*224，与输入L合并为Lab，转RGB，保存为jpeg图片
![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/153229_8c9b0570_5651712.png "屏幕截图.png")

至此，我们应该已经理解了该模型，接下来是重点：在昇腾处理器上部署该模型。

 **基于昇腾AI处理器的应用开发流程** 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/153813_0c533226_5651712.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/153928_04396336_5651712.png "屏幕截图.png")
在这里，我们不关注模型的训练过程，我们直接使用原作者的预训练模型，所以工程准备阶段我们就忽略了。
另外，关于昇腾处理器（例如Atlas200DK）相关产品的开发环境部署以及准备工作请参考昇腾社区网站（200DK文档：https://support.huaweicloud.com/productdesc-A200dk_3000_c75/atlas200_DK_pdes_19_0002.html）
本模型，我们已经做过测试，模型转换过程也是顺利的，并没有算子不支持的情况，所以算子开发与调试过程我们也忽略，如果您的模型有算子不支持的情况，也可以参考相关文档或者视频教程（https://ascend.huawei.com/#/edu/courses）学习并完成自定义算子开发（当然一系列课程均可以参考学习）。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/155116_b26d39cb_5651712.png "屏幕截图.png")

所以，我们就关注模型转换与评估/业务开发和调试以及性能调优过程；后面一一说明。

 **模型转换** 
原始模型如果想要在昇腾边缘产品上跑起来，还需要将模型转换为离线模型（将开源框架的网络模型（如Caffe、TensorFlow等）以及单算子Json文件，通过ATC（Ascend Tensor Compiler）将其转换成昇腾AI处理器支持的离线模型，模型转换过程中可以实现算子调度的优化、权值数据重排、内存使用优化等，转换后的离线模型可以在单推理设备（相对于训练设备成本低很多）上脱离原始深度学习框架跑起来）。
模型转换的相关细节，这里就不罗嗦了（详情请参考:https://support.huaweicloud.com/tg-A200dk_3000_c75/atlasatc_16_0002.html)。
获取原始模型以及模型转换过程请参考：https://gitee.com/ascend/samples/tree/dev/python/level2_simple_inference/6_other/colorization_picture

模型转换命令：
```
export LD_LIBRARY_PATH=${install_path}/atc/lib64
atc --input_shape="data_l:1,1,224,224" --weight="./colorization.caffemodel" --input_format=NCHW --output="./colorization" --soc_version=Ascend310 --framework=0 --model="./colorization.prototxt"
```

 **模型评估** 
参考 https://gitee.com/ascend/tools/tree/master/msame, 获取msame推理工具及使用方法。
获取到msame可执行文件之后，将待检测om文件放在model文件夹，然后进行性能测试。
使用msame推理工具，参考如下命令，发起推理性能测试： 

```
./msame --model model/colorization.om --output output/ --loop 100
```
```
[INFO] output data success
Inference average time: 10.212930 ms
Inference average time without first time: 10.209758 ms
[INFO] unload model success, model Id is 1
[INFO] Execute sample success.
Test Finish!
```

Batch: 1, shape: 1 * 224 * 224，不带AIPP，平均推理性能10.21ms

值得一提的是，这里的推理工具是构造的随机数据，只是为了验证是否可以推理成功而已。
显然，该模型在昇腾设备上是能够推理成功的，且推理速度相当快，每秒可以处理近100帧图片。

 **业务开发及调试实战** 
应用开发，则是基于AscendCL的应用开发，AscendCL（Ascend Computing Language）你可以理解为一套开放API，利用这套API可以完成Device管理、Context管理、Stream管理、内存管理、模型加载与执行、算子加载与执行、媒体数据处理等，该套API有C接口，同时也有Python接口。

如下左图，我们这里就是要开发一个APP，直接调用ACL完成推理应用开发，至于ACL以下的GE/Runtime/Driver等都可以通过ACL调用。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/170600_78bf7c53_5651712.png "屏幕截图.png")
如上右图，就是一个典型应用的代码逻辑，大家看图理解吧，这里不罗嗦。

**上代码**
完整代码请参考（目前是在dev分支，后面可能会切换到master分支）：
python：https://gitee.com/ascend/samples/tree/dev/cplusplus/level2_simple_inference/6_other/colorization
C++：https://gitee.com/ascend/samples/tree/dev/python/level2_simple_inference/6_other/colorization_picture
这里只说一下业务流程关键代码；
先说下工程下的文件：
acl_model.py ACL模型相关的一些
acl_resource.py
colorize.py
constants.py
data/
model/
.project*
README.md
utils.py

![输入图片说明](https://images.gitee.com/uploads/images/2021/0109/172848_2694c69b_5651712.png "屏幕截图.png")
【未完待续】






