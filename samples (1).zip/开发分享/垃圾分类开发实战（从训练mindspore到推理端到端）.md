本案例以垃圾分类为例，端到端打通从mindspore训练一个mobilenetv2网络，到Ascend310上推理实现的整个流程。
  1. [训练](https://gitee.com/ascend/samples/wikis/MobileNetV2%E5%9E%83%E5%9C%BE%E5%88%86%E7%B1%BB?sort_id=3404387)：
    - 上传训练代码至obs。
    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/095203_593ab877_5400693.png "屏幕截图.png")
    - 创建Notebook。
    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/094957_77293459_5400693.png "屏幕截图.png")
    - 打开Notebook。
    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/095309_dbd5aac7_5400693.png "屏幕截图.png")
    - 同步obs文件到本地目录，随后打开JupyterLab。
    !![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/095806_e32eef06_5400693.png "屏幕截图.png")
    - 打开训练脚本文件。
    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/095914_198c1e22_5400693.png "屏幕截图.png")
    
 2. [推理](https://gitee.com/ascend/samples/tree/master/python/contrib/garbage_picture)：
    该样例是基于[googlenet图片分类样例](https://gitee.com/ascend/samples/tree/master/python/level2_simple_inference/1_classification/googlenet_imagenet_picture)修改而来。该样例详细流程参考[图片目标检测(Python)实验手册](https://gitee.com/ascend/samples/wikis/%E5%9F%BA%E4%BA%8EAtlas%20200DK%E7%9A%84%E5%AE%9E%E9%AA%8C%20%E5%9B%BE%E7%89%87%E7%9B%AE%E6%A0%87%E6%A3%80%E6%B5%8B(Python)?sort_id=3411222)。
    差异点为后处理的标签文件image_net_classes.py。
