### 一、	简介与约束
#### 1、Profiling简介
MindStudio针对昇腾AI处理器提供高效、易用的系统化性能分析工具Profiling，便于快速识别产品的关键性能瓶颈并提出针对性能优化的建议，最终实现产品的极致性能。

Profiling提供针对APP工程的硬件和软件性能数据采集、分析、汇总展示。总体流程如下：
（1）运行Profiling采集。
确保APP工程可正常执行的条件下，用户在配置界面开启Profiling开关。

（2）Profiling采集性能数据。
MindStudio译当前工程生成可执行文件，并将可执行文件拷贝到设备侧，MindStudio向Profiling工具下发数据采集指令，由Profiling工具完成设备侧数据采集任务，采集结束后，将生成的数据文件拷贝到MindStudio侧。

（3）MindStudio查询并解析数据。
Profiling采集结束后，MindStudio调用Profiling工具接口查询数据，并将数据以json格式存储在“工程目录~/profiling ”目录下。

（4）MindStudio展示性能数据。
MindStudio通过对json文件做数据处理，生成前端展示视图数据，此时用户可通过右键单击工程文件名并选择“View Profiling Result”菜单进行数据图形化展示。

2、Profiling使用约束
以下情况不能使用Profiling功能：
（1）Profiling不支持同时从MindStudio安装侧发起2个基于相同结果目录的Profiling。
（2）Profiling功能与Dump功能不建议同时使用，即启动Profiling前，请关闭数据Dump。原因：如果同时开启，由于Dump操作会影响系统性能，会造成Profiling采集的性能数据指标不准确。Dump相关介绍请参考准备离线模型dump数据。
（3）Profiling工具需要配套python3.7版本使用，推荐使用python3.7.5版本。

### 二、	Profiling前准备
环境准备
使用Profiling工具前，您需要参考《CANN 软件安装指南》完成开发环境搭建。
同时，需要使用root用户登录Host侧设置依赖的动态库。操作方法如下：

说明：
本文所有举例场景：以root用户安装Driver、Firmware和AI CPU，默认安装路径/usr/local/Ascend；以HwHiAiUser普通用户安装其他软件包，默认安装路径/home/HwHiAiUser/Ascend。请实际操作时根据您自己的环境进行替换。
本文描述的运行环境，请根据实际情况适配，针对不同环境对应以下情况：Ascend EP环境，表示Host侧环境；Ascend RC表示板端环境。
1、root用户登录运行环境。
2、修改/etc/ld.so.conf文件，在文件最后增加APP工程运行依赖的动态库路径。格式如下：
Ascend EP环境，填入以下内容：
```
/home/HwHiAiUser/Ascend/nnrt/latest/acllib/lib64
/usr/local/Ascend/add-ons
/usr/local/Ascend/driver/lib64
```
Ascend RC环境，填入以下内容：
```
/home/HwHiAiUser/Ascend/acllib/lib64
/usr/lib64
```
3、执行命令ldconfig，使设置生效。

工程准备
完成工程文件开发，并通过MindStudio编译、运行，确保APP工程正常。

### 三、	 启动Profiling
通过以下操作方法启动Profiling：

1、选择已编译完成的工程。
2、单击菜单栏“Run > Run...”，在弹出窗口中选择“Edit Configurations...”，弹出Profiling设置窗口 。如图1所示。
图1 Profiling设置界面
![输入图片说明](https://images.gitee.com/uploads/images/2020/1128/091423_bcdfcec9_5403304.png "屏幕截图.png")

表1 Profiling参数说明

![输入图片说明](https://images.gitee.com/uploads/images/2020/1128/092012_70ff93bb_5403304.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/1128/092037_4627998e_5403304.png "屏幕截图.png")
3、单击“Run”，执行工程的Profiling。
工程执行完成后，MindStudio窗口下方展示Profiling结果视图。
说明：Profiling的过程日志信息可以在下方任务栏的“Run”窗口中查看。

### 四、	查看Profiling数据
Profiling执行成功后，通过右键单击工程目录，选择“View Profiling Result”菜单，查看Profiling数据结果。

图1 查看Profiling数据

![输入图片说明](https://images.gitee.com/uploads/images/2020/1128/092316_1f28e50b_5403304.png "屏幕截图.png")

Profiling结果展示视图位于MindStudio窗口下方，如图2所示。

图2 Profiling视图窗口

![输入图片说明](https://images.gitee.com/uploads/images/2020/1128/092330_2fd2a065_5403304.png "屏幕截图.png")

因Profiling支持Task-Based和Sample-Based两种不同方式的AI Core采集方式，以及两种不同的Metrics采集项（Pipe Utilization和UB L1 L2 && Main Memory Bandwidth），因此，会出现Profiling各页签展示结果不同，本文不再分别截图区分。

更多视图详见 https://support.huaweicloud.com/ug-mindstudioc75/atlasms_02_0120.html


