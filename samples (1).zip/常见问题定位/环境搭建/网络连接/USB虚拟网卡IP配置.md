## USB虚拟网卡IP配置（linux18.04）
### 确认网口名称
以普通用户登录Ubuntu服务器，执行如下命令切换到root用户，获取usb网卡名。
```
su - root
ifconfig -a
```
若系统中有多个USB网卡，可以通过拔插开发者板进行判定。
例如，在USB线没有插入主机前（USB线另外一端连接开发板）：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0203/145803_66745143_5423530.png "屏幕截图.png")

USB线插入主机后，如下的ens160u4u1就是你插入后多出来的一个网卡，但此时该网卡还未分配IP：
### 配置网口IP
![输入图片说明](https://images.gitee.com/uploads/images/2021/0203/145816_b6d87644_5423530.png "屏幕截图.png")

在“/etc/netplan/01-network-manager-all.yaml”文件中添加USB网卡的静态IP。

执行如下命令打开配置文件；
```
vim /etc/netplan/01-network-manager-all.yaml
```
并在文末追加如下内容（例如：为ens160u4u1配置静态IP为192.168.1.123）：
```
network:
  version: 2
  # renderer: NetworkManager
  ethernets:
          ens160u4u1:
                  dhcp4: no
                  dhcp6: no
                  addresses: [192.168.1.123/24]
                  gateway4: 192.168.0.1
                  nameservers:
                          addresses: [114.114.114.144, 8.8.8.8]
```
（**注意**：USB网卡名一定要与你实际查出来的一致，配置静态IP为 192.168.1.xxx网段即可，另外，如果192.168.1.xxx网段已经被用于局域网通讯，为了避免IP冲突，参考[网络冲突解决方法](https://gitee.com/ascend/samples/wikis/%E5%AE%9E%E9%AA%8C%E5%AE%A4Ubuntu%E6%9C%BA%E5%99%A8%E4%BD%BF%E7%94%A8192.168.1.xx%E7%BD%91%E6%AE%B5%EF%BC%8C%E5%BC%80%E5%8F%91%E8%80%85%E6%9D%BF%E8%BF%9E%E6%8E%A5IP%E5%86%B2%E7%AA%81?sort_id=3418669)
### 设置重启后网络配置生效
修改NetworkManager.conf文件，避免重启后网络配置失效。
若是Ubuntu Sever版本，此步骤请忽略。
执行如下命令打开“NetworkManager.conf”文件。
```
vi /etc/NetworkManager/NetworkManager.conf
```
修改文件中的“managed=false”为“managed=true” 。
配置静态IP生效
执行以下命令：
```
netplan apply   
```
然后，ifconfig查看，可以看到虚拟网卡已经被分配了IP：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0203/150035_efc3de8d_5423530.png "屏幕截图.png")

## USB虚拟网卡IP配置（for windows）

### 连接usb连接线前先查看网络连接
![输入图片说明](https://images.gitee.com/uploads/images/2021/0203/150059_5c74c4be_5423530.png "屏幕截图.png")
将开发板通过usb线与windows连接，再查看网络连接，会发现多了一个以太网设备，这个就是windows虚拟出的一个usb网卡，以下图为例，就是“以太网 4”，接下来为该网卡配置静态IP，与开发板在同一网段即可；

![输入图片说明](https://images.gitee.com/uploads/images/2021/0203/150120_a1752e4a_5423530.png "屏幕截图.png")

### 为usb虚拟网卡配置静态IP
因为开发板默认有两个IP（usb设备的IP默认是192.168.1.2， eth0设备的IP默认是192.168.0.2），这里是通过usb连接，所以配置usb虚拟网卡为192.168.1.xxx，例如这里我们将其设置为192.168.1.129，然后确认退出；

![输入图片说明](https://images.gitee.com/uploads/images/2021/0203/150143_2527fa56_5423530.png "屏幕截图.png")

打开cmd窗口，ping 192.168.1.2，应该就可以通了：）
