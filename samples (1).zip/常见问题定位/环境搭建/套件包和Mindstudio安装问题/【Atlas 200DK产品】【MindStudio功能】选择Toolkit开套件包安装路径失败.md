## 本地已成功安装Toolkit 开发套件包，但是在MindStudio 安装时，报错，选择Toolkit开套件包安装路径失败
### 现象描述
本地已成功安装Toolkit 开发套件包，但是在MindStudio 安装时，报错。报错信息如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/152949_880e11cf_5408865.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/153000_b0101dee_5408865.png "屏幕截图.png")

### 可能原因

分析上述报错的信息，可能存在以下故障原因：

套件包安装失败 导致MindStudio无法识别到

### 处理步骤

这种情况需要将toolkit开发工具包卸载掉后重新安装一下。 

卸载的命令是安装包后跟参数 --uninstall

例如当安装的版本是1.73的时候，执行如下命令对套件包进行卸载，命令如下所示：

./Ascend-Toolkit-20.0.RC1-arm64-linux_gcc7.3.0.run --uninstall

./Ascend-Toolkit-20.0.RC1-x86_64-linux_gcc7.3.0.run --uninstall