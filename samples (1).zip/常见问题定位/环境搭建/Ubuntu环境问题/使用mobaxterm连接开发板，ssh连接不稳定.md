【问题描述】

ubuntu虚拟机ssh到开发板稳定不会断，但是使用mobaxterm连接一会就自动断开

【问题解决】

打开mobaxterm设置，配置SSH keepalive即可

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/193514_6ad8ec73_5403304.jpeg "moba.jpg")