原始帖子链接 https://bbs.huaweicloud.com/forum/thread-29830-1-1.html

前言：给Atlas安装一个图形化桌面，系统操作方便，便于软件和文件管理

关键词：  Atlas    图形化桌面    Xrdp     Win

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/172455_8c6e5f03_5403304.png "屏幕截图.png")
1. [连接Atlas和Ubuntu服务器](https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0015.html)（USB方式）
    根据官方教程连接Atlas 200 DK开发者板与Ubuntu服务器

    以USB方式连接并成功登陆后成功进行下一步

2. 配置外网网络 
    将Atlas接入网线，确保atlas和windows在同一个路由下；

    登录root用户；
```
su - root
```
    修改网络配置使atlas可以连接外网；
```
vi /etc/netplan/01-netcfg.yaml
```
    修改eth0的为dhcp，路由器自动为开发板分配IP地址；
```
    eth0:
      dhcp4: true
      addresses: []
      optional: true
```
    wq!保存，用以下命令使其生效；
```
netplan apply
```
3. 更换软件源并更新
    更换软件源为华为源(注意开发板系统为ARM类，软件源也要为arm源，有的源不可以用)；
```
wget -O /etc/apt/sources.list https://repo.huaweicloud.com/repository/conf/Ubuntu-Ports-bionic.list
```
    更新软件源；
```
apt-get update
apt-get upgrade
```
    时间较久请耐心等待；

4. 安装图形化桌面并配置
    安装桌面环境；
```
apt install xfce4 xfce4-goodies xorg dbus-x11 x11-xserver-utils
```
    时间较久请耐心等待；



    安装 Xrdp；
```
apt install xrdp
```
    检测是否正在运行；
```
systemctl status xrdp
```
    成功的话，运行结果：
```
xrdp.service - xrdp daemon
Loaded: loaded (/lib/systemd/system/xrdp.service; enabled; vendor preset: enabled)
Active: active (running) since Sun ...
Docs: man:xrdp(8)
man:xrdp.ini(5)
```

    配置 Xrdp；
```
vim /etc/xrdp/xrdp.ini
```
    在文件末尾添加以下行；
```
exec startxfce4
```
    保存文件并重新启动 Xrdp 服务；
```
sudo systemctl restart xrdp
```
    这样就在atlas上安装好图形界面环境了。



5. 修改冲突IP
```
ifconfig
```
    查看atlas的网络信息，发现eth0得到的地址为192.168.1.143（我的开发板地址是这样）；
```
 ipconfig
```
    查看windows的网络信息，IP地址为192.168.1.117；



    此时IP互相ping不通，因为USB网卡地址为 192.168.1.2 和eht0在同一个网段，将atlas USB虚拟网卡 IP改为192.168.2.2；

    （修改完usb网卡生效后原先usb就不可以连接了，需要在ununtu服务器也修改静态IP到192.168.2.x网段）；
```
service network-manager restart
```
    生效配置的网络；

    重新ping，发现atlas和windows可以相互ping通，可以开始连接。

6. 连接远程桌面
    打开自带远程桌面，输入atlas 的IP地址点击连接;

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/172557_e09cc212_5403304.png "屏幕截图.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/172607_47c5082c_5403304.png "屏幕截图.png")
用户名为root，密码为Mind@123
![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/172623_956c2eb4_5403304.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/172633_1de8ea11_5403304.png "屏幕截图.png")
登陆进去，就可以自由操作Atlas桌面环境了，管理起来方便很多。