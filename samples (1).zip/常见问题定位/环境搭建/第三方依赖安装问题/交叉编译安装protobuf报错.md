【问题描述】
在交叉编译安装ptotobuf报错时，在make install时，出现下方蓝色框出的报错
![输入图片说明](https://images.gitee.com/uploads/images/2021/0203/112220_93344aa1_7401379.png "屏幕截图.png")

【解决办法】
根据蓝色报错提示，设置一下软连接
 **su root** 
 **ln -s /usr/lib/aarch64-linux-gnu /lib/aarch64-linux-gnu** 

设置好之后，继续执行make install