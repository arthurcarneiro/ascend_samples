一、简介

以下步骤在软件包版本Version=1.73.T5.0.B050环境下测试。

ATC在模型转换过程中对模型进行了优化，包括算子消除、算子融合、算子拆分，可能会造成自有实现的算子运算结果与用业界标准算子（如Caffe、TensorFlow）运算结果存在偏差，此时需要提供工具比对两者之间的差距，帮助开发人员快速解决算子精度问题。

精度比对工具提供比对华为自有模型算子的运算结果与Caffe、TensorFlow标准算子的运算结果，以便确认误差发生的算子，目前提供以下比对方法：

Vector比对，包含余弦相似度、最大绝对误差、累积相对误差、欧氏相对距离、KLD散度、标准差的算法比对。

二、约束

•精度比对工具需要配套python3.7.5版本使用。

•精度比对工具不支持以下场景：

◾单个Dump文件的大小超过1GB。

◾模型batch数大于1。

 

•精度比对支持的Dump数据的Format类型：

◾NCHW

◾NHWC

◾ND

◾NC1HWC0

◾FRACTAL_Z

◾HWCN

 

•精度比对支持的Dump数据的类型：◾FLOAT

◾FLOAT16

◾DT_INT8

◾DT_UINT8

◾DT_INT16

◾DT_UINT16

◾DT_INT32

◾DT_INT64

◾DT_UINT32

◾DT_UINT64

◾DT_BOOL

◾DT_DOUBLE

 

三、数据准备

 

1、准备bin文件

bin文件制作步骤:

使用netron工具打开pb模型查看模型的输入数据类型和shape

![输入图片说明](https://images.gitee.com/uploads/images/2020/1127/212906_80690bb3_5403304.png "屏幕截图.png")

使用img2bin工具将图片转换为bin文件

（工具链接  https://gitee.com/ascend/tools/tree/master/img2bin ）

转换命令参考：
```
 python img2bin.py -i ./image/ -w 640 -h 352 -f BGR -a NHWC -t float32 -o ./out
```

之后会在当前目录的out文件夹下生成mask.bin文件

 

2、准备pb的TensorFlow dump文件

拉取docker镜像，命令如下
```
docker pull dopa6/env-dump:tensorflow
```
进入容器
```
docker run -it [容器ID] bash

cd $HOME
```
 

把pb模型和bin文件传入docker中，执行脚本生成.npy数据
```
python tf_generate_npy_data.py ./mask_detection.pb -i ./mask.bin  -n 'images:0' -s [1,352,640,3]
```
会在当前路径下的mask_detection目录生成.npy数据

 

把生成的.npy文件放到c73环境中

 

用c73版本中的dump_data_conversion.pyc工具把.npy数据转换成dump数据

脚本路径
```
/home/HwHiAiUser/Ascend/toolkit/tools/operator_cmp/compare/dump_data_conversion.pyc
```
 

执行命令
```
python3.7.5 dump_data_conversion.pyc -type tf -target dump -i /home/HwHiAiUser/temp/mask_detection/ -o  /home/HwHiAiUser/tfdump_mask 
```
 

3、准备om的dump数据

1）修改acl.json文件（没有就创建）格式如下
```
{                                                                                            

"dump":{                                                                                 

"dump_list":[                                                                        

{ "model_name":"mask_detection_pb"

}                                                                           

],                                                                                   

"dump_path":"pb/dump"                                  

}                                                                                        

}
```
 

这里需要注意的是，model_name字段需要用MindStdio查看或者查看转模型时生成的.json文件中的model_name，必须一字不差。如果需要指定dump的某一层在“model_name”后面加“layer”字段，算子名也必须一字不差。

2）用msame工具跑一遍，就能在/home/HwHiAiUser/ide_daemon/dump/路径下找到dump数据。

Msame工具使用参考

https://gitee.com/ascend/tools/tree/master/msame

        注：msame工具请勿使用码云仓上的，仓上代码无法dump数据，请根据下方链接下载工具

        arm版：（如运行环境为Atlas200DK）https://c7xcode.obs.cn-north-4.myhuaweicloud.com/msame/dump_tmp/arm/msame

        x86版：（如运行环境为Ai1云上服务器）https://c7xcode.obs.cn-north-4.myhuaweicloud.com/msame/dump_tmp/x86/msame

     

四、模型比对

 

在上述的数据都准备完成后，使用c7x版本包中的工具compare_vector.pyc 对比模型

脚本路径：
```
/home/HwHiAiUser/Ascend/toolkit/tools/operator_cmp/compare/compare_vector.pyc
```
 
```
python3.7.5 compare_vector.pyc -l LEFT_DUMP_PATH -r RIGHT_DUMP_PATH -f FUSION_JSON_FILE_PATH -o OUTPUT_PATH
```
•-l：My Model模型的Dump文件目录。

•-r：Ground Truth模型的Dump文件目录。

•-f：离线模型的全网层信息文件（通过使用ATC转换.om模型文件生成的json文件）。可选。

•-q：量化融合规则文件。可选。

•-o：比对数据结果存储目录及文件名。

例如：
```
python3.7.5 compare_vector.pyc -l /home/HwHiAiUser/ide_daemon/dump/mask/dump/20200703161157/0/home_HwHiAiUser_xuyetao_mask_detection/1/0 -r /home/HwHiAiUser/temp/mask_detection_tf_dump -f /home/HwHiAiUser/temp/mask_detection.json -o /home/HwHiAiUser/temp/result.txt
```
 

最后在result.txt中查看比对结果。

