## [1.32.0.0 版本] sample-classification例程Profiling报错
### 现象描述
1.32.0.0 版本的 社区样例 sample-classification  运行Profiling时报错 , 开启profiling 失败 

### 可能原因

因为不是在MindStudio中点击完run按钮后直接就可以运行程序的 而是需要一个python脚本来执行程序。所以无法在MindStudio中直接运行profiling

### 处理步骤

1. 可以修改代码， 通过python脚本运行程序 是将模型的路径，模型的宽高以及用于推理的图片的位置作为 可执行程序的输入参数，传递给可执行程序运行 ，所以可以先熟悉下代码流程 然后照此思路修改下代码 如果在MindStudio中直接点击run按钮可以运行 那么profiling也没有问题。

2. 可以自己在代码块的开头和结尾添加clock函数 求差值以此获取代码块的执行时间。

如果是刚开始使用 Atlas 200 DK 建议使用新软件版本 20.0.0 在这个版本上通过MindStudio导入社区demo 直接运行profiling 是可以的方法可以参考：

https://bbs.huaweicloud.com/forum/forum.php?mod=viewthread&tid=80551



上述修改思路可以成功解决 1.32.0.0 版本 的 社区案例 在开启profiling 失败时的问题.

