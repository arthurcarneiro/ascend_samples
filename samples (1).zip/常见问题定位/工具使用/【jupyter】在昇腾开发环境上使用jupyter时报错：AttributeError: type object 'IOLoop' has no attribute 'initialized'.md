【问题现象】20.1版本，在昇腾开发环境上使用jupyter时报错：AttributeError: type object 'IOLoop' has no attribute 'initialized'
安装命令：sudo apt-get install jupyter-notebook
使用命令：jupyter notebook --ip=xxx.xxx.xxx.xxx --no-browser
![输入图片说明](https://images.gitee.com/uploads/images/2020/1211/115453_a421c0e0_5651712.png "屏幕截图.png")

【问题解决】经过定位分析，发现jupyter与tornado冲突，tornado的版本太高；
而tornado时presenter server运行所需要的依赖，这是samples仓下视频相关案例的一个后处理展现方案。
然后将tornado版本降低，问题解决！
![输入图片说明](https://images.gitee.com/uploads/images/2020/1211/115834_97a4825d_5651712.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/1211/115949_b29106a5_5651712.png "屏幕截图.png")