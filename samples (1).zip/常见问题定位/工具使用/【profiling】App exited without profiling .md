【问题描述】

运行profiling 报错，App exited without profiling 

![输入图片说明](https://images.gitee.com/uploads/images/2021/0118/142116_0b4c1e90_5423530.png "屏幕截图.png")

【问题处理】

sudo dpkg-reconfigure dash

![输入图片说明](https://images.gitee.com/uploads/images/2021/0118/142125_7a74c632_5423530.png "屏幕截图.png")

选择No