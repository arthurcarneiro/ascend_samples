## 安装完toolkit套件包并设置完环境变量 再开启MindStudio时报以下的错误：
![tengxz](https://images.gitee.com/uploads/images/2020/1120/173851_deed56a0_5408865.png "屏幕截图.png")

### 现象描述
进入bin中run那个shell文件是遇到了报错：lack of _sqlite3 module
但是python中是有这个sqlite3的，terminal-->python3-->import sqlite3 没有报错
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/182444_981c369e_5408865.png "屏幕截图.png")

### 问题原因及解决步骤

问题是出在了 ~/.bashrc的配置项中：    export LD_LIBRARY_PATH=${install_path}/atc/lib64:$LD_LIBRARY_PATH 

这个${install_path}/atc/lib64 会对Mind Studio的启动造成干扰。

解决办法：

首先将 ~/.bashrc中的 export LD_LIBRARY_PATH=${install_path}/atc/lib64:$LD_LIBRARY_PATH 这句话给去掉。

关闭当前终端，开启的终端全部关闭，重新打开终端，因为这时终端中已经将 ${install_path}/atc/lib64 添加到了环境变量 LD_LIBRARY_PATH 中，所以source ~/.bashrc是没用的。注意：一定要关闭终端后重新打开终端。

将这句话去掉后 所带来的影响是：不能使用 ATC 进行命令行转换模型，但是可以在Mind Studio中转换模型。如果想使用ATC转换模型，那么就再另外开启一个终端，首先命令行中输入：export LD_LIBRARY_PATH=${install_path}/atc/lib64:$LD_LIBRARY_PATH  作用是使当前终端可以读取到${install_path}/atc/lib64 这个路径。然后就可以使用ATC进行命令行转模型。但是记住，此时就不要在当前终端开Mind Studio 了，会有冲突。如果想使用Mind Studio，就另外开一个终端。