在python运行路径创建脚本deep，注意不带.sh后缀名。

touch deep

修改deep内容为python 执行命令，例如 ： python3 deeplabv3.py  ./data

在PC侧运行profiling命令：
python3.7.5 hiprof.pyc --ip_address=192.168.1.2 --result_dir=$HOME/Download --profiling_options=task_trace --app_dir=/home/HwHiAiUser/deeplab    --app=deep

可以得到profiling结果。
