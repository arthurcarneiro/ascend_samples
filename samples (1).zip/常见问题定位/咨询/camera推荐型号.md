摄像头推荐型号，RASPBERRY PI 树莓派V2.1
可参考以下购买链接:
https://item.jd.com/10540338321.html

Atlas200DK单板分为IT21DMDA/IT21DMDB
参考以下链接：
https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0006.html

主板为IT21DMDA，推荐摄像头排线 
https://item.taobao.com/item.htm?spm=a1z09.2.0.0.5edc2e8dyjMoZt&id=543826723574&_u=2ug0shb37dd