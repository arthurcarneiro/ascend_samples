## error while loading shared libraries: libascendcl.so
### 现象描述
第一种情况：
Mind Studio 运行报错

在Mind Studio中运行程序时 点击Run 按钮时 提示程序运行输错，报错内容如下所示：

报错:

2020-08-12 11:29:46 - [INFO] Assigning execute permission to run.sh on the remote host.
./workspace_mind_studio_colorization: error while loading shared libraries: libascendcl.so: cannot open shared object file: No such file or directory

2020-08-12 11:29:46 - [ERROR] Failed to execute workspace_mind_studio_colorization on the remote host. Please go to remote host for logging details(log files under /var/log/npu/slog on your core

而登录到设备后，在设备侧执行是没有问题的。

第二种情况：

在终端是可以执行推理的。

将其写入到python里会显示缺少库，我把交互的代码摘了出来，如下。
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/152052_2fc644f1_5408865.png "屏幕截图.png")
执行之后会报错
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/152117_c58ac082_5408865.png "屏幕截图.png")


### 可能原因

报错分析：报错是缺少libascendcl.so文件，解决办法有以下两种方案：

### 处理步骤

第一种解决方法：

1、使用Mind Studio的安装用户(比如为ascend), 登录到设备，比如，执行如下命令登录到设备：

ssh HwHiAiUser@192.168.1.2

![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/152157_9e8387b3_5408865.png "屏幕截图.png")

2. 输入ps -ef | grep ada  ，此时会显示出两个进程信息。
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/152210_c3a8675b_5408865.png "屏幕截图.png")

用kill 命令杀死显示出来的第一个进程，即/var/ada那个进程，比如执行如下命令 kill -9 1987：
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/152224_c98e0c2d_5408865.png "屏幕截图.png")

由上图可知ada 命令所在路径为/var, 我们进入到/var目录下，执行命令 ./ada & 即可重启ada服务，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/152242_d3ac6446_5408865.png "屏幕截图.png")
第二种：

使用第一种方法时，下次当设备重新上电后，如果要使用Mind Studio运行程序，要重复上面的操作。  

第二种方法是一个一劳永逸的方法， 将动态链接库路径 添加到 ldconfig 文件中，这样程序运行时会自动搜索此路径下的动态库，这样程序运行时就不会报错，具体操作如下所示：

切换到root用户下搜索 libascendcl.so 所在的路径：
su root

find / -name libascendcl.so

![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/152304_60b9a79e_5408865.png "屏幕截图.png")

cd /etc/ld.so.conf.d
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/152313_0ce19fb4_5408865.png "屏幕截图.png")
执行 vim mind_so.conf

添加路径到此文件中：
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/152328_de5545e8_5408865.png "屏幕截图.png")

添加完成后，执行 ldconfig 
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/152339_c6f6ed57_5408865.png "屏幕截图.png")

再次通过Mind Studio 运行程序，可以顺利运行。
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/152352_320119a4_5408865.png "屏幕截图.png")

