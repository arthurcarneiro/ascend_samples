 ## 报错信息
Sorry, user HwHiAiUser is not allowed to execute './tsdaemon_add_to_usermemory.sh 7531' as root on davinci-mini.

首先，经了解，tsdaemon_add_tousermemory.sh脚本的作用：限制AI CPU进程的内存使用，为操作系统预留足够的内存空间。

那么看来，该脚本还是必要运行的，当前报HwHiAiUser无操作该文件的权限；
那么在sudoers中为其他添加权限（添加对tsdaemon_add_to_usermemory.sh的免密可执行权限）：
HwHiAiUser ALL=(root) NOPASSWD:/opt/mini/minirc_install_phase1.sh,/bin/date -s *,/var/ide_cmd.sh *,/bin/sed -i * /etc/network/interfaces,/usr/bin/perf stat *,/usr/bin/perf record *,/usr/bin/perf script *,/usr/bin/pkill -2 perf, /var/tsdaemon_add_to_usermemory.sh

然后，重新运行应用，仍然报错，这里是由于该脚本中，写入的文件路径不对，而且权限不足，导致写入失败。
![输入图片说明](https://images.gitee.com/uploads/images/2020/1204/204716_6136d95c_5651712.png "屏幕截图.png")

## 解决方案如下：
1. 修改tsdaemon_add_tousermemory.sh文件内容（其中文件路径错误），将其中的/usermemory删掉，修改后如下：
![输入图片说明](https://images.gitee.com/uploads/images/2020/1204/205942_98b0c7f7_5651712.png "屏幕截图.png")

2. 切换到root用户下，修改/sys/fs/cgroup/memory/cgroup.procs的权限为666
root@davinci-mini:/var# chmod 666 /sys/fs/cgroup/memory/cgroup.procs

## 然后再重新运行应用，发现没有错误了：
![输入图片说明](https://images.gitee.com/uploads/images/2020/1204/210159_5d3264a8_5651712.png "屏幕截图.png")