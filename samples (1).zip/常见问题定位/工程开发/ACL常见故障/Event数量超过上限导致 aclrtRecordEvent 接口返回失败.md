##  Event 数量超过上限导致 aclrtRecordEvent 接口返回失败
### 现象描述
调用aclrtRecordEvent接口在Stream中记录一个Event时，日志中的报错如下，红框中
是关键日志信息，提示Event ID申请失败：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/105322_31af441d_5423530.png "屏幕截图.png")

### 可能原因

分析上述日志信息，可能存在以下故障原因：Event ID的数量超过上限。

### 处理步骤

多Stream之间同步等待的场景下，Event ID的资源是可以复用的，复用Event ID的流
程是：在调用aclrtRecordEvent接口和aclrtStreamWaitEvent接口后，若指定的Event
已完成，则需要及时调用aclrtResetEvent接口释放Event资源。

需要用户按照复用Event ID的流程优化代码逻辑。