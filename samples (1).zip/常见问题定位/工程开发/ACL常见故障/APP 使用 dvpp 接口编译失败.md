##  APP 使用 dvpp 接口编译失败
### 现象描述

编译提示DVPP的相关接口未定义，如下图所示。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/104721_7b99c353_5423530.png "屏幕截图.png")

### 可能原因

分析上述日志信息，可能存在以下故障原因：

DVPP与ACL已经分别打包到libacl_dvpp.so与libascendcl.so，测试用例使用了DVPP的
相关接口，但没有链接libacl_dvpp.so。

### 处理步骤

针对分析的故障可能原因，可以参考下面步骤处理：

排查测试用例是否使用了预处理的接口，但未链接libacl_dvpp.so。如果未链接，需要
在编译文件中链接libacl_dvpp.so。

排查结果示例图：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/104731_c0cb4af0_5423530.png "屏幕截图.png")