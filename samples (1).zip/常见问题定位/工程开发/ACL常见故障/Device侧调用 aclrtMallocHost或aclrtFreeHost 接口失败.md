##  Device 侧调用 aclrtMallocHost/aclrtFreeHost 接口失败
### 现象描述
Device侧调用aclrtMallocHost与aclrtFreeHost接口时，日志报错误信息“current app
is not support on device side”，如下图所示，日志信息：current app is not support on device side。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/105215_5591d2b9_5423530.png "屏幕截图.png")

### 可能原因

分析上述日志信息，可能存在以下故障原因：

aclrtMallocHost与aclrtFreeHost接口只支持在Host侧调用，不支持在Device侧调用。

### 处理步骤

针对分析的故障可能原因，可以参考下面步骤处理：

排查在Device侧运行的测试用例是否有用aclrtMallocHost与aclrtFreeHost接口操作内
存，如果有，则需要替换为Device侧可以使用的内存操作接口。