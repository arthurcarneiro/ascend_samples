## 使用 dump 功能未获取 dump 结果
### 现象描述
日志显示正确执行了Dump功能，但在Dump结果路径下没有Dump的结果。如下图所示。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/105114_90b3cb5a_5423530.png "屏幕截图.png")

### 可能原因

分析上述日志信息，可能存在以下故障原因：Dump配置的模型名与实际的模型名不匹
配。

### 处理步骤

针对分析的故障可能原因，可以参考下面步骤处理：

检查Dump配置文件acl.json，确保Dump配置文件合法，例如model_name是否配置
正确，如下图所示。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/105129_8056e199_5423530.png "屏幕截图.png")