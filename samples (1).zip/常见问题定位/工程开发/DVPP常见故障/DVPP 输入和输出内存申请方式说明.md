##  DVPP 输入和输出内存申请方式说明
### 现象描述
DVPP输入输出内存申请要求说明：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/114054_3a81c857_5423530.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/114105_2832f53a_5423530.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/114113_ec46d764_5423530.png "屏幕截图.png")