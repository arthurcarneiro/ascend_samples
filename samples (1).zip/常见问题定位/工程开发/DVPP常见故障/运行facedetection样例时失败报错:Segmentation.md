## [1.73 版本] 目标检测 运行 facedetection 样例时失败报错:Segmentation
### 现象描述
修改 人脸检测案例中的模型为 目标检测 模型 实现实时的目标检测 : 参考这个样例进行修改  https://gitee.com/ascend/samples/tree/master/facedetection/for_atlas200dk_1.7x.0.0_c++ 

编译完成后运行过程中出现段错误,报错提示和响应的截图如下所示:
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/154152_91c27d21_5408865.png "屏幕截图.png")

### 可能原因
按照如下所示步骤进行排查：
1.  通过查看日志 来排查问题 ，将slog下的host-0日志 使用rm 命令清空 ，保证没有历史日志的积累 ，然后重新运行一遍程序，这样host-0下面保存的日志文件记录的就是最新的错误。
2.  如果程序运行过程中出现了段错误的话 需要 参考这个链接中关于定位段错误的方法 :  https://bbs.huaweicloud.com/forum/thread-36954-1-1.html 
3. 当通过上述方法在开发板上通过  gdb 命令调试后出现相关的错误信息: https://bbs.huaweicloud.com/forum/thread-36954-1-1.html 
4.通过函数调用栈发现 问题是出在dvpp上,因为当前版本的dvpp的的编码功能有些bug 可能会造成内存踩踏.

建议再屏蔽 object_detect.cpp中的这个代码块：
![输入图片说明](https://images.gitee.com/uploads/images/2020/1120/154554_5167bf02_5408865.png "屏幕截图.png")

编译运行，如果在运行过程中没有出现段错误 基本可以定位为 是dvpp的YUV转jpg的功能(即dvpp的编码功能)有问题。

规避的思路如下所示:

 ImageData 结构体中的data数据保存的是YUV数据，width和height分别表示图片的宽度和高度

需要取出data中的数据转换成Mat对象 - > 然后使用cvtColor将YUV数据转换成RGB数据 -> 然后使用imencode将RGB数据编码为jpg格式

然后将数据写到ImageFrame中 发送到presenter server展示。

1. 取出data中的数据转换成Mat对象 

int img_height = image.height;

int img_width = image.width;

cv::Mat jpegSrc(img_height * 3 / 2, img_width, CV_8UC1);

int copy_size = img_width * img_height * 3 / 2;

int destination_size = jpegSrc.cols * jpegSrc.rows * jpegSrc.elemSize();

memcpy(jpegSrc.data, image.data.get(), copy_size);



2. 然后使用cvtColor将YUV数据转换成RGB数据

cv::Mat jpegDst;

cvtColor(jpegSrc, jpegDst, cv::COLOR_YUV420sp2RGB);



3. 然后使用imencode将RGB数据编码为jpg格式 并放入到ImageFrame中 发送到presenter server展示

vector<int> param = vector<int>(2);

param[0] = cv::IMWRITE_JPEG_QUALITY;

param[1] = 100;//default(95) 0-100

cv::imencode(".jpg", origImg, encodeImg, param);



ImageFrame frame;

frame.format = ImageFormat::kJpeg;

frame.width = image.cols;

frame.height = image.rows;

frame.size = encodeImg.size();

frame.data = reinterpret_cast<uint8_t*>(encodeImg.data());

frame.detection_results = detRes;



相关解决案例 可以参考这篇帖子: https://bbs.huaweicloud.com/forum/forum.php?mod=viewthread&tid=80775 按照以上描述的方法 已成功解决此类问题





上述修改思路可以成功解决 1.73 版本 的 社区案例 在开启profiling 失败时的问题.