## 设置帧序号但回调接收的 hiai_data 对象却为空
### 现象描述
回调函数传给用户的形参hiai_data为NULL。

回调函数格式：void (*call_back)(FRAME* frame,void * hiai_data)

### 可能原因

形参hiai_data为NULL的可能原因有以下：

● VDEC本身支持多帧码流一次性调用VdecCtl送入，但用户若设置了hiai_data_sp对象，就只能每次调用VdecCtl送入一帧。而此问题可能是用户设置了一个hiai_data_sp对象，但此对象对应多帧码流一次性调用VdecCtl送入导致。

● 码流参考帧间隔超过30帧，参考帧周期过长导致帧序号小的hiai_data_sp对象从队列中被丢弃。

### 处理步骤

针对分析的可能原因，请参考以下方法处理：

步骤1 检查日志中是否出现“not find node, currFid = ***, reqFid = ***, chanid = ***”内容信
息，若有则说明是第1条可能原因所致，请排查传入数据正确性。

步骤2 检查日志中是否出现“clear expired node, expiredFid = ***, reqFid = ***, chanid =
***”，若有则说明是第2条可能原因所致，对于参考帧周期过长的码流（参考帧间隔超
过30帧）不支持设置帧序号。