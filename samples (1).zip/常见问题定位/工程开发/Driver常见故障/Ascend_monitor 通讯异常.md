## Ascend_monitor 通讯异常
### 现象描述
run包安装完成后重启，Host侧日志会有 sendmsg fail:Connection refused相关报错打
印,如下图所示。发送信息失败：拒绝连接。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/113553_59315f60_5423530.png "屏幕截图.png")

### 可能原因

分析上述日志信息，可能存在以下故障原因：

设备重启后，监控进程Ascend_monitor还没完全建立好服务端，被监控进程（如：
slogd、sklogd、log-daemon）就与监控进程Ascend_monitor建立连接，注册心跳，
可能会出现首次注册心跳失败。

### 处理步骤

针对分析的故障可能原因，可以参考下面步骤处理：

步骤1 查看报错信息后续的日志是否出现注册成功的信息，如图5-11所示，有则无需处理，
对正常功能无影响。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/113602_e3de024a_5423530.png "屏幕截图.png")

步骤2 如果没有出现注册成功信息，则判断为进程监控通讯异常，需联系华为售后工程师处
理。