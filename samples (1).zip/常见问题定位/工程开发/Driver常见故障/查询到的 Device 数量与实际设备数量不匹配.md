## 查询到的 Device 数量与实际设备数量不匹配
### 现象描述
环境上插了一张PCIE标卡（4个Device），使用npu-smi工具或upgrade-tool工具查
询，只查到了1个Device。如下图所示。设备查询。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/113312_cbfb0fdf_5423530.png "屏幕截图.png")

### 可能原因

根据查询信息分析，可能存在以下原因：

● 主机散热不好，导致PCIE标卡温度过高，设备进入过温保护状态。

● Device的主机侧中断数量不足，无法自动加载驱动。

● Device通信线路问题：

– Device硬件通信线路不通

– Device通信线路断链

### 处理步骤

针对上述可能原因，可以参考以下方法处理：

步骤1 针对主机散热不好造成的Device异常，可以主机下电后再重新启动。
进入/var/log/npu/hisi_logs/device-XX/目录查看黑匣子日志，结合《黑匣子异常重启错误码列表》中LPM3页签的内容，确认是否存在温度过高造成的异常码。

步骤2 使用dmesg命令查看打印信息，查看是否存在图5-5所示的日志信息。
如果存在图中的日志信息，则为硬件环境问题：

● 若安装昇腾AI处理器的主机为物理机，请更换为性能配置更高的硬件设备。

● 若安装昇腾AI处理器的主机为虚拟机，则给该虚拟机增加CPU配置数量。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/113324_afad76c5_5423530.png "屏幕截图.png")

步骤3 使用lspci | grep d100 命令查询链接状态。
如下图，显示Device数量比实际数量少，原因为Device硬件通信线路不通。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/113333_aff3ac1e_5423530.png "屏幕截图.png")

如下图，显示Device有“ff”状态，原因为Device通信线路断链。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0115/113342_6afa8483_5423530.png "屏幕截图.png")

可能是PCIE标卡与主机接触不良，则下电后重新插拔板卡，再上电启动。

如果以上操作无法解决该异常现象，请联系华为工程师处理。