##  input_fp16_nodes 参数指定的节点名字不存在
### 现象描述
模型转换失败，报错日志中有“Can not find node [***] in graph, please check
input_fp16_nodes param”，如下图所示。日志信息：Can not find node [***] in graph, please check input_fp16_nodes
param

![输入图片说明](https://images.gitee.com/uploads/images/2020/1119/141718_9fafd95f_7401379.png "屏幕截图.png")

### 可能原因

分析上述日志信息，可能存在以下故障原因：

转模型使用了input_fp16_nodes参数指定支持输入数据类型为FP16，该参数后面带的
是输入节点的名字，该处报错是指这个节点名字没有找到。如果日志报类似这样的信息：input_fp16_nodes: res5c_relu is not a input node name，表示input_fp16_nodes参数指定的节点不是输入节点。

### 处理步骤

针对分析的故障可能原因，可以参考下面步骤处理：

打开原始model确认输入节点的名字与input_fp16_nodes后面的是否一致。
