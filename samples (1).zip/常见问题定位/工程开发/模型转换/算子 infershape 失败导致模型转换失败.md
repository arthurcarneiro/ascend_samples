## 算子 infershape 失败导致模型转换失败
### 现象描述
目标模型转换失败，报错日志中有以下类似信息：“Run ge_passes infershape for
preprocess failed”，如下图所示。日志信息：Run ge_passes infershape for preprocess failed

![输入图片说明](https://images.gitee.com/uploads/images/2020/1119/141816_b22ecc5b_7401379.png "屏幕截图.png")

### 可能原因

分析上述日志信息，可能存在以下故障原因：

报错算子的输入有问题。

### 处理步骤

针对分析的故障可能原因，可以参考下面步骤处理：

步骤1 定位报错算子实现的infershape失败的原因，确认异常输入的上个算子infershape实现
是否正确。

步骤2 不断向上回溯到infershape实现异常的问题算子。
