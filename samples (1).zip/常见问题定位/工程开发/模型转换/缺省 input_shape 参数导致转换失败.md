## 缺省 input_shape 参数导致转换失败
### 现象描述
模型转换失败，日志中有“input x shape is empty”的内容信息。如下图所示。日志信息：input x shape is empty

![输入图片说明](https://images.gitee.com/uploads/images/2020/1119/120600_970587ad_7401379.png "屏幕截图.png")

### 可能原因

分析上述日志信息，可能存在以下故障原因：

原始的TensorFlow模型输入是动态shape，如“?×299×299×3”，转换模型的时候缺
省了input_shape选项导致报错。

### 处理步骤

步骤1 使用Netron工具查看模型，确认模型输入的shape。

步骤2 对于动态shape的模型，转换时必须加上input_shape参数。命令行举例：
atc --model=./resnetv2.pb --framework=3 --input_shape="input_tensor:
8,299,299,3" --input_format="NHWC" --output=./resnetv2 --soc_version=Ascend310