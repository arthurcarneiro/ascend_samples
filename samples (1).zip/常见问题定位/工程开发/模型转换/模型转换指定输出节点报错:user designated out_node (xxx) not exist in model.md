## 模型转换指定输出节点报错
### 问题描述
指定输出节点报错：user designated out_node (anchors_0/Shape
) not exist in model
pb转om模型转换时指定输出节点报错如下：
![输入图片说明](https://images.gitee.com/uploads/images/2020/1119/142952_9f99682f_7401379.png "屏幕截图.png")
但是在pb中是存在anchors_0/Shape这个节点的。
![输入图片说明](https://images.gitee.com/uploads/images/2020/1119/143000_c31cb307_7401379.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/1119/143007_1c9ab9c9_7401379.png "屏幕截图.png")
### 解决方法
命令行转换pb模型
https://ascend.huawei.com/doc/Atlas%20200%20DK/1.3.0.0/zh/zh-cn_topic_0165968579.html
注意使用输出节点时需要加编号“ ：0” ，表示这个节点的第1个输出。
例如：“node_name1:0;node_name1:1;node_name2:0”。


