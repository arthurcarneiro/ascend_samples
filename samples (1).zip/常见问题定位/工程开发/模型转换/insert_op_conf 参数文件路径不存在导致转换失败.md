## insert_op_conf 参数文件路径不存在导致转换失败
### 现象描述
模型转换失败，报错日志中有“insert op file not found:”，如下图所示。日志信息：insert op file not found

![输入图片说明](https://images.gitee.com/uploads/images/2020/1119/141931_26695717_7401379.png "屏幕截图.png")

### 可能原因

分析上述日志信息，可能存在以下故障原因：

insert_op_conf入参是在aipp场景下才需要的，后面是aipp配置文件的路径，路径访问
不到。

### 处理步骤

针对分析的故障可能原因，可以参考下面步骤处理：

步骤1 确认是否是aipp场景，若不是，则不需要此入参。

步骤2 如果是aipp场景，确定路径是否正确，若路径正确则查看属组权限是否正常。
