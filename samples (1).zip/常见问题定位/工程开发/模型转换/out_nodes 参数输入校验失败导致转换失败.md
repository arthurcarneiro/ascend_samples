## out_nodes 参数输入校验失败导致转换失败
### 现象描述
模型转换失败，报错日志中有“The input format of --out_nodes is invalid”，如下图所示。日志信息：The input format of -out_nodes is invalid

![img](img/1-2-5-1.png)

### 可能原因

分析上述日志信息，可能存在以下故障原因：

转模型使用了out_nodes参数指定输出节点（算子名称），但未指定第几个输出，输入
格式校验错误。

### 处理步骤

针对分析的故障可能原因，可以参考下面步骤处理：

确认out_nodes入参的格式，需要指定第几个输出，例如--
out_nodes="node_name1:0;node_name1:1;node_name2:0"
