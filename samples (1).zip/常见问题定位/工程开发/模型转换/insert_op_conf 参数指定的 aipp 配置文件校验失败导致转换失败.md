##  insert_op_conf 参数指定的 aipp 配置文件校验失败导致转换失败
### 现象描述
模型转换失败，报错日志中有“Read AIPP conf file error”，如下图所示。日志信息：Read AIPP conf file error
![输入图片说明](https://images.gitee.com/uploads/images/2020/1119/142045_cd178733_7401379.png "屏幕截图.png")
### 可能原因

分析上述日志信息，可能存在以下故障原因：

insert_op_conf入参指定的aipp文件解析失败。

### 处理步骤

针对分析的故障可能原因，可以参考下面步骤处理：

确认aipp配置文件是否正确，是否是protobuf文件格式。
