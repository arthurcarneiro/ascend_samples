
### 一、购买Ai1云服务器
参考[购买Ai1S云服务器](https://gitee.com/ascend/samples/wikis/%E5%8D%8E%E4%B8%BA%E4%BA%91Ai1S%E7%8E%AF%E5%A2%83%E8%B4%AD%E4%B9%B0%E6%96%B9%E6%B3%95?sort_id=3556478)

### 二、连接Ai1云服务器

这里我们选择使用MobaXterm去连接Ai1云服务器。

1.在MobaXterm中新建Session。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100948_5d8734bb_7380811.png "屏幕截图.png")
2.在弹出的窗口中选择ssh连接，并进行配置，如下图所示。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/101042_7fdcadae_7380811.png "屏幕截图.png")
第一次建立连接的时候要输入Ai1 root用户的密码，root密码是申请ai1环境时高级配置中填写的密码，之后就可以直接连接。
3.连接上Ai1后，在root用户下执行如下命令，给HwHiAiUser用户设置密码。
`passwd HwHiAiUser`

```
root@ecs-bf1d:~# passwd HwHiAiUser
Enter new UNIX password:
Retype new UNIX password:
passwd: password updated successfully
root@ecs-bf1d:~#
```
### 三、版本确认

1.查看当前安装的CANN版本
![输入图片说明](https://images.gitee.com/uploads/images/2021/0209/145430_0b909f02_5423530.png "屏幕截图.png")
当前版本为CANN20.1，需要卸载，更新为CANN20.2版本

2.执行以下命令，更新apt依赖。
执行过程中如果要求填写[Y/N]，请填写Y。
```
apt-get update
apt-get upgrade
```
3.清理无用的安装包
```
apt-get remove
```
4.配置用户权限
执行以下命令，在root用户下打开“/etc/sudoers”文件。
```
chmod u+w /etc/sudoers
vi /etc/sudoers
```
在该文件“ # User privilege specification”下面增加如下内容：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/104024_c12ab787_7380811.png "屏幕截图.png")
其中， **HwHiAiUser** 为开发环境中普通用户用户名，需要根据自己的环境修改。

完成后，执行以下命令取消“ /etc/sudoers”文件的写权限。
` chmod u-w /etc/sudoers`
### 四、安装新版本驱动

安装推理卡相关驱动和固件

1.执行 lspci | grep d100 命令，查看环境中是否有Atlas300推理卡。

```
root@ecs-bf1d:~# lspci | grep d100
00:0d.0 Processing accelerators: Huawei Technologies Co., Ltd. Device d100 (rev 20)
```
如上显示，证明环境中有300推理卡。
2.下载推理卡驱动和固件包
如下图，下载推理卡驱动和固件包。
下载链接：https://ascend.huawei.com/#/hardware/firmware-drivers
![输入图片说明](https://images.gitee.com/uploads/images/2021/0209/150424_9a909369_5423530.png "屏幕截图.png")

3.将这两个软件包上传到ai1环境的/opt目录下，执行以下命令，以root用户进入/opt目录，给软件包加执行权限。

```
cd /opt
chmod +x *.run 
```

```
root@ecs-bf1d:~# cd /opt/
root@ecs-bf1d:/opt# chmod +x *.run
root@ecs-bf1d:/opt# ll
total 93748
-rwxr-xr-x 1 root root  6012186 Jan 30 16:22 A300-3000-3010-npu-firmware_1.76.22.3.220.run
-rwxr-xr-x 1 root root 89973342 Jan 30 16:23 A300-3010-npu-driver_20.2.0_ubuntu18.04-x86_64.run

```
4.安装驱动
执行以下命令，进行驱动安装。
 **./A300-3010-npu-driver_20.2.0_ubuntu18.04-x86_64.run --full** 
安装成功后，执行以下命令，重启环境。
 **reboot** 
重启完成后，以root用户重新登陆，并执行以下命令进入/opt文件夹。
 **cd /opt** 

5.安装固件（Ai1S因为是云上分配虚设备，此步跳过）
执行以下命令，进行固件安装 。
 **./A300-3000-3010-npu-firmware_1.76.22.3.220.run --full** 
安装过程中提示[y/n]，填入y。

安装成功后，执行以下命令，重启环境。
 **reboot** 
重启完成后，以root用户重新登陆。

6.检查安装
执行以下命令，检查是否安装成功。
 **npu-smi info** 
回显如下，则证明安装成功。
```
root@ecs-c76:/opt# npu-smi info
+------------------------------------------------------------------------------+
| npu-smi 20.2.0                       Version: 20.2.0                         |
+-------------------+-----------------+----------------------------------------+
| NPU     Name      | Health          | Power(W)          Temp(C)              |
| Chip    Device    | Bus-Id          | AICore(%)         Memory-Usage(MB)     |
+===================+=================+========================================+
| 0       310       | OK              | 12.8              46                   |
| 0       0         | 0000:00:0D.0    | 0                 2703 / 8192          |
+===================+=================+========================================+

```

### 五、运行环境搭建(等CANN20.2版本上线)

 1.下载离线推理引擎包和实用工具包
如下图，下载运行环境所需的离线推理引擎包和实用工具包。
下载链接：https://www.huaweicloud.com/ascend/resource/Software
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/104700_64949612_7380811.png "屏幕截图.png")

2.HwHiAiUser普通用户登录云环境。
mobax新建会话，以普通用户HwHiAiUser登录ai1环境。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/104727_f1844694_7380811.png "屏幕截图.png")
执行以下命令，使用bash命令模式。
 **bash** 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/104742_3f4f26d4_7380811.png "屏幕截图.png")

3.上传软件包至ai1环境
将下载的离线推理引擎包和实用工具包上传到ai1环境中普通用户家目录下。
并执行以下命令，增加软件包的可执行权限。
`chmod +x *.run`

```
HwHiAiUser@ecs-bf1d:~$ chmod +x *.run
HwHiAiUser@ecs-bf1d:~$ ls -l
total 6456
-rwxrwxr-x 1 HwHiAiUser HwHiAiUser 5559441 Jul 29 17:48 Ascend-cann-nnrt_20.2.rc1_linux-x86_64.run
-rwxrwxr-x 1 HwHiAiUser HwHiAiUser 1030800 Jul 29 17:49 Ascend-cann-toolbox_20.2.rc1_linux-x86_64.run
drwx------ 3 HwHiAiUser HwHiAiUser    4096 Jul 29 17:26 hdcd
d-wxr-x--- 2 HwHiAiUser HwHiAiUser    4096 Apr 10 15:15 hdc_ppc
drwx------ 3 HwHiAiUser HwHiAiUser    4096 Jul 29 17:31 ide_daemon
drwxr-x--- 2 HwHiAiUser HwHiAiUser    4096 Apr 10 15:14 profiler
HwHiAiUser@ecs-bf1d:~$
```

4.安装软件包
执行以下命令，在普通用户中安装离线推理引擎包。
 **./Ascend-cann-nnrt_20.2.rc1_linux-x86_64.run --install** 
执行以下命令，在普通用户中安装实用工具包。
 **./Ascend-cann-toolbox_20.2.rc1_linux-x86_64.run --install** 

### 六、开发环境安装(等CANN20.2版本上线)
开发环境即ubuntu18.04虚拟机环境（双系统也可，后面都以虚拟机做介绍），是AI代码的编译环境，主要用来做模型转换、代码编写、代码编译等操作。结合Mindstudio工具，充分体现了易操作，易安装、易使用等多种能力。

###     
我们是在普通用户下安装的，首先确保当前环境中有一个普通用户和一个root用户，如果是新建的虚拟机需要先给root用户配置密码后才可以正常登录root用户（sudo passwd root）。以下安装普通用户以ascend举例。

用户权限配置。
普通用户安装开发套件，需要有sudo权限，所以首先需要给普通用户配置权限。

切换为root用户。
`su root`

给sudoer文件配置写权限，并打开该文件。

```
chmod u+w /etc/sudoers
vi /etc/sudoers
```

在该文件“ # User privilege specification”下面增加如下内容：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/112334_f996724c_7380811.png "屏幕截图.png")

其中， **ascend** 为开发环境种普通用户用户名，需要根据自己的环境修改。

完成后，执行以下命令取消“ /etc/sudoers”文件的写权限。
` chmod u-w /etc/sudoers`
2.源配置。
由于安装过程中涉及很多apt依赖和pip依赖的安装，所以配置一个国内源是一个加快进度的好办法。

1. 配置ubuntu18.04-x86的apt清华源。
   root用户下打开apt源文件。
   `vi /etc/apt/sources.list`

将源文件内容替换为以下ubuntu18.04-x86的apt清华源。

```
root@ubuntu:/home/ascend# cat /etc/apt/sources.list
# 默认注释了源码镜像以提高 apt update 速度，如有需要可自行取消注释
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-updates main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-updates main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-backports main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-backports main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-security main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-security main restricted universe multiverse
root@ubuntu:/home/ascend# 
```
执行以下命令更新源。
 **apt-get update** 
 **说明：
如果apt-get update失败，可以试用其他的国内源https://www.cnblogs.com/dream4567/p/9690850.html。** 
2. 配置pip源（建议使用清华源或中科大源）。
执行以下命令，切换为普通用户。
 **exit** 

执行以下命令，创建后打开普通用户家目录下的.pip/pip.conf文件。

```
mkdir $HOME/.pip/
vi $HOME/.pip/pip.conf
```


将如下内容填写到pip.conf文件中。

```
ascend@ubuntu:~$ cat /home/ascend/.pip/pip.conf 
[global]
timeout = 6000
index-url = http://mirrors.aliyun.com/pypi/simple/
trusted-host = mirrors.aliyun.com
ascend@ubuntu:~$
```
3.安装相关apt依赖。
普通用户下安装，这些是开发环境中套件包所依赖的一些apt软件，都需要成功安装。
`sudo apt-get install -y gcc make cmake unzip zlib1g zlib1g-dev libsqlite3-dev openssl libssl-dev libffi-dev pciutils net-tools`

4.安装python环境。
执行以下命令，进入普通用户家目录。
 `cd $HOME`

下载python3.7.5源码包并解压。

```
wget https://www.python.org/ftp/python/3.7.5/Python-3.7.5.tgz
tar -zxvf Python-3.7.5.tgz
```

进入解压后的文件夹，执行配置、编译和安装命令。

```
cd Python-3.7.5
./configure --prefix=/usr/local/python3.7.5 --enable-shared
make -j8
sudo make install
```

执行以下命令将so拷贝到lib中，并设置软链接。

```
sudo cp /usr/local/python3.7.5/lib/libpython3.7m.so.1.0 /usr/lib
sudo ln -s /usr/local/python3.7.5/bin/python3 /usr/bin/python3.7
sudo ln -s /usr/local/python3.7.5/bin/pip3 /usr/bin/pip3.7
sudo ln -s /usr/local/python3.7.5/bin/python3 /usr/bin/python3.7.5
sudo ln -s /usr/local/python3.7.5/bin/pip3 /usr/bin/pip3.7.5
```

执行以下命令，安装环境所需的相关pip依赖。

```
pip3.7.5 install attrs psutil decorator numpy protobuf==3.11.3 scipy sympy cffi grpcio grpcio-tools requests --user

```
### 安装toolkit开发工具包

如下图，下载开发环境所需要的toolkit包。
下载链接：https://www.huaweicloud.com/ascend/resource/Software
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/112917_399ea0d9_7380811.png "屏幕截图.png")

将包放置到开发环境普通用户的$HOME目录下。
并执行以下命令，切换到普通用户的$HOME目录下。
`cd $HOME`
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/112938_4f3d92b7_7380811.png "屏幕截图.png")

执行以下命令，给run包增加可执行权限。
`chmod 755 *.run`

执行以下命令，安装toolkit包。
`./Ascend-Toolkit-20.0.0.RC1-x86_64-linux_gcc7.3.0.run --install`
### 安装mindstudio

如下图，获取最新的mindstudio工具，并安装。
下载链接：https://www.huaweicloud.com/ascend/resources/Tools/0
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/113256_95777f75_7380811.png "屏幕截图.png")
将压缩包放置到开发环境普通用户的$HOME目录下。并执行以下命令，安装Mindstudio。

```
cd $HOME
tar -zxvf mindstudio.tar.gz
cd MindStudio-ubuntu/bin
./Mindstudio.sh
```

注：运行过程中会有红字提示需要继续安装的软件包，安装完成后重新执行 **./Mindstudio.sh** 运行即可

导入设置选择 **Do not import settins** 即可。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/113323_31d0bc83_7380811.png "屏幕截图.png")

要求选择toolkit路径，选择对应路径即可（本案例为/home/ascend/Ascend/ascend-toolkit/20.0.RC1）。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/113336_07a99ab9_7380811.png "屏幕截图.png")

点击OK后，Mindstudio搭建完成。

通过以上步骤，一个基本的环境就搭建完了。

