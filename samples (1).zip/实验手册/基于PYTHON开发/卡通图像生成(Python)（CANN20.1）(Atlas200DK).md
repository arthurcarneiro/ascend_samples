<!-- GFM-TOC -->

* [1 实验介绍](#1-实验介绍)
* [2 实验原理](#2-实验原理)
* [3 实验环境](#3-实验环境)
* [4 快速体验](#4-快速体验)
* [5 卡通图像生成原理](#5-卡通图像生成原理)
* [6 开发步骤和关键代码分析](#6-开发步骤和关键代码分析)
  <!-- GFM-TOC -->
# 1 实验介绍

本实验是基于Atlas 200DK的卡通图像生成项目，使用cartoonization模型进行推理。该示例代码部署在Atlas 200DK上 ，通过读取本地图像数据作为输入，将原始图像转换为卡通图片，通过OpenCV将转换的结果展示出来。
# 2 实验原理
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/104743_5782a7a5_7380811.png "屏幕截图.png")


 **1)运行管理资源申请** ：用于初始化系统内部资源，固定的调用流程。

 **2)加载模型文件并构建输出内存：** 从文件加载离线模型数据，需要由用户自行管理模型运行的内存，根据内存中加载的模型获取模型的基本信息包含模型输入、输出数据的数据buffer大小；由模型的基本信息构建模型输出内存，为接下来的模型推理做好准备。

 **3)获取本地图像并进行预处理：** 从本地存放有图像数据的目录中使用DVPP循环读取图像数据，对读入的图像数据进行预处理，然后构建模型的输入数据。

 **4)模型推理：** 根据构建好的模型输入数据进行模型推理。

 **5)解析推理结果：** 根据模型输出，解析模型的推理结果。使用OpenCV将转换后的卡通图像数据保存成图片文件。

# 3 实验环境

实验前需要制作SD卡，连接Atlas 200DK的Ubuntu服务器上准备好软件环境，安装步骤请参考文档链接：
https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0003.html

# 4 快速体验

### 步骤 1 在Ubuntu18.04服务器上获卡通图像生成应用源码包

1)切换至普通用户（如ascend），执行如下命令：
`su ascend`
2)执行如下命令在ascend用户下创建工程存放目录，并进入该目录：

```
mkdir -p $HOME/AscendProjects
cd $HOME/AscendProjects
```

3)执行如下命令获取卡通图像生成工程：
`wget https://obs-book.obs.cn-east-2.myhuaweicloud.com/liuyuan/20.1samples/cartoonGAN_picture.zip`
如果使用wget下载失败，可使用如下命令下载代码。
`curl -OL https://obs-book.obs.cn-east-2.myhuaweicloud.com/liuyuan/20.1samples/cartoonGAN_picture.zip`
如果curl也下载失败，可复制下载链接到浏览器，手动上传至服务器。
4)解压工程文件压缩包：
`unzip cartoonGAN_picture.zip`
工程文件目录如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/111116_c7af247a_7380811.png "屏幕截图.png")

工程目录说明如下表所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/111158_bef02908_7380811.png "屏幕截图.png")

### 步骤 2 模型转换

在本项目中，20.1版本 由于版本问题，此模型在20.1版本不能正确转换。因此20.1版本直接获取om模型
1)切换到工程所在的model目录
`cd $HOME/AscendProjects/samples/python/contrib/cartoonGAN_picture/model`
2)下载om文件
`wget https://c7xcode.obs.cn-north-4.myhuaweicloud.com/models/cartoonGAN_picture/cplus/cartoonization.om`
如下图所示，模型下载完毕：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/111427_691e763f_7380811.png "屏幕截图.png")
 **注：本次的模型在C75环境转换不成功，需要在C76 上转换，故此处直接提供已经转换好的om 文件** 

### 步骤 3 准备开发板运行环境

本次实验使用USB直连的方式连接Ubuntu服务器与开发板，开发板的IP地址为192.168.1.2，下文中涉及开发板IP地址的操作请替换为实际IP地址。
1)创建开发板工程主目录
如果已经创建过开发板工程主目录，则此步骤可跳过。
如果首次使用开发板，则需要使用如下命令创建开发板工程主目录：
`ssh HwHiAiUser@192.168.1.2 "mkdir HIAI_PROJECTS"`
提示password时输入开发板密码，开发板默认密码为Mind@123。
2)将应用代码（含转换后的离线模型）拷贝至开发板
`scp -r /home/ascend/AscendProjects/samples/python/contrib/cartoonGAN_picture/ HwHiAiUser@192.168.1.2:~/HIAI_PROJECTS`
提示password时输入开发板密码，开发板默认密码为Mind@123，如下图：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/111534_61cc09e9_7380811.png "屏幕截图.png")

3)拷贝ACL库文件至开发板
可以参考此链接进行操作https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0017.html
- 下载“Ascend-pyACL-20.1.rc1-linux.aarch64.run“并拷贝到开发板上

```
wget https://obs-9be7.obs.cn-east-2.myhuaweicloud.com/turing/resource/atlas200dk/20.1/Ascend-pyACL-20.1.rc1-linux.aarch64.run
scp Ascend-cann-toolkit_20.1.rc1_linux-aarch64/run_package/Ascend-pyACL-20.1.	rc1-linux.aarch64.run HwHiAiUser@192.168.1.2:~/
```

- ssh登录到开发板上然后执行如下命令安装PyACL包

```
chmod +x Ascend-pyACL-20.1.rc1-linux.aarch64.run
./Ascend-pyACL-20.1.rc1-linux.aarch64.run --install --run
```


- 如下图所示，PyACL安装成功：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/111640_e34afc6b_7380811.png "屏幕截图.png")

- 执行如下命令可以看到PyACL安装成功：
`ls /home/HwHiAiUser/Ascend`
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/111714_f5ce0715_7380811.png "屏幕截图.png")

4)配置开发板环境变量
使用如下命令检查开发板是否已配置环境变量：
`ssh HwHiAiUser@192.168.1.2 "cat ~/.bashrc | grep PATH"`
如下图所示，如果打印输出包含如下红框中的内容则跳过此步骤：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/111736_791c9aea_7380811.png "屏幕截图.png")

如果上述命令打印输出不包含上图中红框的内容，则需要执行如下命令更新开发板环境变量配置：
`ssh HwHiAiUser@192.168.1.2 "echo 'export LD_LIBRARY_PATH=/home/HwHiAiUser/Ascend/acllib/lib64:/home/HwHiAiUser/ascend_ddk/arm/lib:\${LD_LIBRARY_PATH}' >> .bashrc ; echo 'export PYTHONPATH=/home/HwHiAiUser/Ascend/pyACL/python/site-packages/acl:\${PYTHONPATH}' >> .bashrc"`
使用如下命令确认环境变量，下图中红框中的内容为更新的内容：
`ssh HwHiAiUser@192.168.1.2 "tail -n8  .bashrc"`
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/111805_3cb95154_7380811.png "屏幕截图.png")

### 步骤 4 准备推理输入数据

本实验的图片可以从如下链接下载作为推理输入数据，
`wget https://c7xcode.obs.cn-north-4.myhuaweicloud.com/models/cartoonGAN_picture/scenery.jpg`
图片存放在工程目录下的./data目录中，如下图所示
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/111838_733e35ba_7380811.png "屏幕截图.png")
用户可将要推理的图片存放于此目录作为推理输入数据。

### 步骤 5 登录开发板运行工程

1)使用如下命令登录开发板
`ssh HwHiAiUser@192.168.1.2`
2)进入拷贝至开发板中的工程目录，执行如下命令运行工程

```
cd ~/HIAI_PROJECTS/cartoonGAN_picture
python3 cartoonization.py ./data/
```

3)程序执行过程中会提示输入HwHiAiUser用户的密码，要输入HwHiAiUser的密码
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/111958_7a7ca5c7_7380811.png "屏幕截图.png")

4)查看推理图片。
推理产生的结果图片保存在outputs文件夹，可传到Mindstudio安装用户的家目录中查看。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/112009_9ebecbca_7380811.png "屏幕截图.png")
可执行如下命令：
`scp -r HwHiAiUser@192.168.1.2:/home/HwHiAiUser/HIAI_PROJECTS/cartoonGAN_picture/outputs ~`
在本地Ubuntu中查看传回的推理结果图片
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/112040_819b77a0_7380811.png "屏幕截图.png")

# 5 卡通图像生成原理

卡通图像生成代码流程图如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/112143_073c204f_7380811.png "124.png")

详细开发步骤及代码逻辑分析参见下述说明。

# 6 开发步骤和关键代码分析

将模型部署到Atlas 200DK的步骤一般是这样的：
- 首先，模型转换，得到在昇腾AI处理器上能够跑起来的离线模型，经过上面的实验准备环节，已经得到了om模型。
- 然后，基于ACL接口进行应用开发。
代码的开发过程大致分为以下步骤：

1）. 运行管理资源申请；
2）. 加载模型文件，构建模型输出内存；
3）. 数据获取并进行预处理，获取要进行推理的原始图像，根据模型的输入要求，对输入图像进行预处理；
4）. 模型推理，将数据输入到模型进行推理；
5）. 解析模型推理结果，将经过解析的模型推理结果展示出来；
6）. 释放资源。

### 步骤 1 运行管理资源申请

运行管理资源申请的功能封装在了函数中。
 **函数源码如下所示，ACL相关功能接口的调用已在函数中进行了说明：** 

```
1. 	  print("[Sample] init resource stage:")  
2.  	  #init  
3.        ret = acl.init()   
4.        check_ret("acl.rt.set_device", ret)  
5.        ret = acl.rt.set_device(self.device_id)    
6.        check_ret("acl.rt.set_device", ret)    
7.        self.context, ret = acl.rt.create_context(self.device_id)  
8.        check_ret("acl.rt.create_context", ret)  
9.        self.stream, ret = acl.rt.create_stream()  
10.       check_ret("acl.rt.create_stream", ret)  
11.       self.run_mode, ret = acl.rt.get_run_mode()  
12.       check_ret("acl.rt.get_run_mode", ret)  
13.       print("[Sample] Init resource stage success")  
```

### 步骤 2 加载模型文件，构建模型输出内存

1)加载本地om模型文件到内存中，并创建并获取模型的描述信息，此函数功能封装在class Model的init_resource函数中。
对应文件是acl_model.py
 **函数定义及相关源码注释如下所示：** 

```
1.def _init_resource(self):    
2.        print("Init model resource")    
3.        #load model file    
4.        self.model_id, ret = acl.mdl.load_from_file(self.model_path)    
5.        check_ret("acl.mdl.load_from_file", ret)    
6.        self.model_desc = acl.mdl.create_desc()    
7.        ret = acl.mdl.get_desc(self.model_desc, self.model_id)    
8.        check_ret("acl.mdl.get_desc", ret)    
9.    
10.       #get model output    
11.       output_size = acl.mdl.get_num_outputs(self.model_desc)    
12.    
13.       #create model output dataset    
14.       self._gen_output_dataset(output_size)    
15.       print("[Model] class Model init resource stage success")    
16.    
17.       #get model output description    
18.       self._get_output_desc(output_size)    
19.    
20.       #create input buffer     
21.       self._init_input_buffer()    
22.       return SUCCESS
```
    

2)根据模型的描述信息，获取模型的每路输出数据在设备上所需的空间大小
此函数功能封装在class Model的函数_gen_output_dataset中。
ACL库内置数据类型说明：aclmdlDataset主要用于描述模型推理时的输入数据或输出数据，模型可能存在多个输入、多个输出，每个输入或输出的内存地址、内存大小用aclDataBuffer类型的数据来描述。
对应文件是acl_model.py
 **函数定义及相关源码注释如下所示：** 

```
1.def _gen_output_dataset(self, size):    
2.     print("[Model] create model output dataset:")    
3.     dataset = acl.mdl.create_dataset()    
4.     for i in range(size):    
5.         # create output memory     
6.         size = acl.mdl.get_output_size_by_index(self.model_desc, i)
7.
8.         buffer, ret = acl.rt.malloc(size, ACL_MEM_MALLOC_NORMAL_ONLY)
9.         check_ret("acl.rt.malloc", ret)
10.
11.        dataset_buffer = acl.create_data_buffer(buffer, size)
12. 
14.        _, ret = acl.mdl.add_dataset_buffer(dataset, dataset_buffer)  
16.        if ret:    
17.             #free resource     
18.             acl.rt.free(temp_buffer)    
19.             acl.destroy_data_buffer(dataset)    
20.             check_ret("acl.destroy_data_buffer", ret)    
21.    self.output_dataset = dataset    
22.    print("[Model] create model output dataset success") 
```
   

### 步骤 3 读取本地图像数据并进行预处理

读取本地图像数据后，使用DVPP的jpegd功能对图像数据进行解码；将解码后的图片传入dvpp的接口crop_and_paste中，将原图抠图粘贴到和模型所需要的大小一致的图上，对应的文件是acl_devpp.py 和cartoonization.py。
 **函数定义及相关源码注释如下所示：** 

```
1.def crop_and_paste(self, image, width, height, crop_and_paste_width, crop_and_paste_height):      
2.    '''     
3.    :image: input image    
4.    
5.    :width: input image width        
6.    :height: input image height     
7.    
8.    :crop_and_paste_width: crop_and_paste_width    
9.    
10.   :crop_and_paste_height: crop_and_paste_height    
11.    
12.   :return: return AclImage       
13.   '''       
14.   print('[Dvpp] vpc crop and paste stage:')       
15.   input_desc = self._gen_input_pic_desc(image)        
16.   output_desc, out_buffer, out_buffer_size = \       
17.        self._gen_resize_out_pic_desc(crop_and_paste_width, crop_and_paste_heigh     
18.   self._crop_config = acl.media.dvpp_create_roi_config(0, (width >> 1 << 1) - 1, 0, (height >> 1 << 1) - 1)      
19.   self._paste_config = acl.media.dvpp_create_roi_config(0, crop_and_paste_width - 1, 0, crop_and_paste_height - 1)      
20.   ret = acl.media.dvpp_vpc_crop_and_paste_async(self._dvpp_channel_desc,       
21.                                                  input_desc,    
22.    
23.                                                  output_desc,    
24.    
25.                                                  self._crop_config,    
26.    
27.                                                  self._paste_config,        
28.                                                  self._stream)        
29.   check_ret("acl.media.dvpp_vpc_crop_and_paste_async", ret)    
30.   ret = acl.rt.synchronize_stream(self._stream)    
31.   check_ret("acl.rt.synchronize_stream", ret)    
32.   print('[Dvpp] vpc crop and paste stage success')       
33.   stride_width = align_up16(crop_and_paste_width)     
34.   stride_height = align_up2(crop_and_paste_height)      
35.   return AclImage(out_buffer, stride_width,      
36.                    stride_height, out_buffer_size, MEMORY_DVPP)    
```

 **函数定义及相关源码注释如下所示：** 

```
1.  def pre_process(self, image):  
2.        yuv_image = self._dvpp.jpegd(image)   
3.        crop_and_paste_image = \  
4.            self._dvpp.crop_and_paste(yuv_image, image.width, image.height, self._model_width, self._model_height)  
5.        print("[Sample] crop_and_paste yuv end")  
6.        return crop_and_paste_image 
```
  


### 步骤 4 构建模型输入数据，进行模型推理

构建模型的输入数据，构建模型输入数据的功能函数封装在class Model的函数_gen_input_dataset中。
对应文件是acl_model.py
 **函数定义及相关源码注释如下所示：** 

```
1.  def _gen_input_dataset(self, data, data_size):   
2.        self.input_dataset = acl.mdl.create_dataset()   
3.        input_dataset_buffer = acl.create_data_buffer(data, data_size)   
4.        _, ret = acl.mdl.add_dataset_buffer(   
5.            self.input_dataset,   
6.            input_dataset_buffer)   
7.        if ret:  
8.            ret = acl.destroy_data_buffer(self.input_dataset)    
9.            check_ret("acl.destroy_data_buffer", ret)  

```
### 步骤 5 模型推理

根据已经加载到内存中，要进行推理的模型ID、构建好的模型推理输入数据，调用ACL库中模型推理接口进行模型推理。
模型推理功能函数封装在了Model.execute中。对应文件是acl_model.py
 **函数定义及相关源码注释如下所示：** 

```
1.def execute(self, data, data_size):  
     self._gen_input_dataset(data, data_size)  
2.   ret = acl.mdl.execute(self.model_id,  
3.   self.input_dataset,  
4.   self.output_dataset)  
5.   check_ret("acl.mdl.execute", ret)  
6.   self._release_dataset(self.input_dataset)  
7.   return self._output_dataset_to_numpy()  
```

### 步骤 6 解析模型推理结果

模型推理结果解析的功能函数封装在post_process中，对推理出的数据先进行色彩空间的转化RGB转成BGR，再将其resize成原图的大小，保存在outputs文件路径下。对应文件是cartoonization.py
 **函数定义及相关源码注释如下所示：** 

```
1. def post_process(self, infer_output, image_file, origin_image):  
2.        print("[Sample] post process")   
3.        data = ((np.squeeze(infer_output[0]) + 1) * 127.5)  
4.        img = cv2.cvtColor(data, cv2.COLOR_RGB2BGR)  
5.        img = cv2.resize(img, (origin_image.width, origin_image.height))  
6.        output_path = os.path.join("../outputs", os.path.basename(image_file))   
7.        cv2.imwrite(output_path, img) 
```
 
### 步骤 7 资源释放

推理接收后要卸载模型，并释放与模型推理相关的资源，此功能函数封装在class Model 的__del__（self）函数中。
对应文件是acl_model.py
 **函数定义及相关源码注释如下所示：** 

```
1.def __del__(self):  
2.        self._release_dataset(self.output_dataset)  
3.        if self.model_id:    
4.            ret = acl.mdl.unload(self.model_id)  
5.            check_ret("acl.mdl.unload", ret)  
6.        if self.model_desc:  
7.            ret = acl.mdl.destroy_desc(self.model_desc)  
8.            check_ret("acl.mdl.destroy_desc", ret)   
9.        print("[Model] Model release source success")      

```

运行管理资源释放以及ACL去初始化的功能函数封装在class AclResource中的__del__函数
对应文件是acl_resource.py
 **函数定义及相关源码注释如下所示：** 

```
1. def __del__(self):  
2.        if self._model:  
3.           del self._model   
4.        if self._dvpp:  
5.            del self._dvpp  
6.        if self.stream:  
7.            acl.rt.destroy_stream(self.stream)  
8.        if self.context:    
9.            acl.rt.destroy_context(self.context)   
10.       acl.rt.reset_device(self.device_id)   
11.       acl.finalize()  
12.       print("[Sample] class Samle release source success")  
```
 





