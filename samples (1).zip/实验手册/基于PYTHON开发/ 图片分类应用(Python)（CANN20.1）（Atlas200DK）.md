<!-- GFM-TOC -->

* [1 实验介绍](#1-实验介绍)
* [2 实验原理](#2-实验原理)
* [3 实验环境](#3-实验环境)
* [4 快速体验](#4-快速体验)
* [5 图像分类原理](#5-图像分类原理)
* [6 开发步骤和关键代码分析](#6-开发步骤和关键代码分析)
  <!-- GFM-TOC -->

## 1 实验介绍

本实验是基于Atlas 200DK的图像分类项目，基于googlenet分类网络编写的示例代码，该示例代码部署在Atlas 200DK上 ，通过读取本地图像数据作为输入，对图像中的物体进行识别分类，并将分类的结果展示出来。

## 2 实验原理


![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/115008_07f9f332_7380811.png "屏幕截图.png")

 **1)运行管理资源申请：** 用于初始化系统内部资源，固定的调用流程。

 **2)加载模型文件并构建输出内存：** 从文件加载离线模型数据，需要由用户自行管理模型运行的内存，根据内存中加载的模型获取模型的基本信息包含模型输入、输出数据的数据buffer大小；由模型的基本信息构建模型输出内存，为接下来的模型推理做好准备。

 **3)获取本地图像并进行预处理：** 从本地存放有图像数据的目录中循环读取图像数据并使用DVPP的JPEGD功能将图片数据解码为YUV420SP，并使用DVPP的resize功能对图像数据进行缩放至模型要求的输入图像分辨率。

 **4)模型推理：** 根据构建好的模型输入数据进行模型推理。

 **5)解析推理结果：** 根据模型输出，解析图片分类的结果，获取当前图像中识别出的物体类别以及对应的置信度，将分类结果标注在图片上进行展示。


## 3 实验环境

实验前需要制作SD卡，连接Atlas 200DK的Ubuntu服务器上准备好软件环境，并且在开发板上安装Python环境，请参考文档：《环境搭建指导_Atlas 200DK场景（C75）.docx》

## 4 快速体验

### 步骤 1 在Ubuntu18.04服务器上获取图片分类源码包

1) 切换至普通用户（如ascend），执行如下命令：

```
su - ascend
```

2) 执行如下命令在ascend用户下创建工程存放目录，并进入该目录：

```
mkdir ~/AscendProjects
cd ~/AscendProjects
```

3) 执行如下命令获取图片分类工程文件：
```
wget https://c7xcode.obs.cn-north-4.myhuaweicloud.com/code_Ascend/classification_python.zip --no-check-certificate
```
如果服务器上没有wget命令，使用以下命令进行安装：
`sudo apt-get install wget`

如果使用wget下载失败，可使用如下命令下载代码。
```
curl -OL https://c7xcode.obs.cn-north-4.myhuaweicloud.com/code_Ascend/classification_python.zip
```
如果服务器上没有curl命令，使用以下命令进行安装：

```
sudo apt-get install curl
```
如果curl也下载失败，可复制下载链接到浏览器，手动下载压缩包，并上传至服务器。

4) 解压工程文件压缩包：
```
unzip classification_python.zip
```
如果服务器上没有unzip命令，使用以下命令进行安装：
``` 
sudo apt-get install unzip
```
工程文件目录如下所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/142746_5124afdb_7380811.png "屏幕截图.png")

工程目录说明如下表所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/142927_7a4e2253_7380811.png "图片2.png")


### 步骤 2 模型转换（图形界面方式）

我们选择caffe的googlenet模型，需要将其转换为昇腾AI处理器支持的Davinci模型文件，这里我们选择使用MindStudio工具对模型进行转换。

1) 执行如下命令在ascend用户下创建模型存放目录并进入该目录

```
mkdir -p ~/models/googlenet_yuv
cd ~/models/googlenet_yuv
```

2) 下载原始网络模型和权重文件

```
wget https://c7xcode.obs.cn-north-4.myhuaweicloud.com/models/googlenet/googlenet.caffemodel
wget https://c7xcode.obs.cn-north-4.myhuaweicloud.com/models/googlenet/googlenet.prototxt
```

如下图所示，模型下载完毕：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143026_3995722a_7380811.png "屏幕截图.png")

3) 将原始网络模型转换为昇腾AI处理器支持的Davinci模型

使用如下命令打开Mind Studio工具：

```
cd ~/MindStudio-ubuntu/bin
./MindStudio.sh &
```

在Mind Studio操作界面的顶部菜单栏中选择Ascend > Model Converter，进入模型转换界面，在弹出的Model Conversion操作界面中进行模型转换配置，参照以下图片进行参数配置：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143039_ed77a2d3_7380811.png "屏幕截图.png")


- ​Model File选择步骤2）中下载的模型文件，此时会自动匹配到权重文件并填写在Weight File中；

- 修改模型的名字为googlenet_yuv，若修改模型名称，需对应修改classify.py文件中的MODEL_PATH；

- Type修改为Uint8

点击Next继续配置，如下图：

 ![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143116_06401f3c_7380811.png "屏幕截图.png")



- Model Image Format选择BGR，原始模型需要的图片格式为BGR。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143128_58d92a8a_7380811.png "屏幕截图.png")

点击Finish执行转换，转换成功后会提示“Model converted successfully”，如下图所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143137_1afc3820_7380811.png "屏幕截图.png")
4) 将转换好的模型拷贝至工程对应的目录下

```
cp ~/modelzoo/googlenet_yuv/device/googlenet_yuv.om ~/AscendProjects/classification_python/model/
```

### 步骤 3 准备开发板运行环境

本次实验使用网线直连的方式连接Ubuntu服务器与开发板，开发板的IP地址为192.168.0.2，下文中涉及开发板IP地址的操作请替换为实际IP地址。

1) 创建开发板工程主目录

如果已经创建过开发板工程主目录，则此步骤可跳过。

如果首次使用开发板，则需要使用如下命令创建开发板工程主目录：

```
ssh HwHiAiUser@192.168.0.2 "mkdir HIAI_PROJECTS"
```

提示password时输入开发板密码，开发板默认密码为Mind@123。

2) 将应用代码（含转换后的离线模型）拷贝至开发板

```
scp -r ~/AscendProjects/classification_python HwHiAiUser@192.168.0.2:/home/HwHiAiUser/HIAI_PROJECTS
```

提示password时输入开发板密码，开发板默认密码为Mind@123，如下图：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0118/162107_28e3bd8e_7380811.png "屏幕截图.png")
3) 拷贝ACL库文件至开发板

使用如下命令检查开发板是否已有ACL库文件（acl.so）：

```
ssh HwHiAiUser@192.168.0.2 "ls ~/Ascend/"
```

 如下图所示，如果打印输出包含acl.so文件则跳过此步骤：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0118/162121_57437f24_7380811.png "屏幕截图.png")
 **如果上述命令打印输出不包含acl.so，则需要执行如下步骤：** 

-  进入到包含“Ascend-cann-toolkit_20.1.rc1_linux-aarch64.run”的路径下，在本地开发环境中执行如下命令对套件包进行解压：
-  如果路径下没有，可参考如下链接下载：https://ascend.huawei.com/#/software/cann/community

```
./Ascend-cann-toolkit_20.1.rc1_linux-aarch64.run --extract=./Ascend-cann-toolkit_20.1.rc1_linux-aarch64 --noexec
```

- 执行如下命令将解压之后的run包里面的“Ascend-pyACL-20.1.rc1-linux.aarch64.run“拷贝到开发板上。

```
scp Ascend-cann-toolkit_20.1.rc1_linux-aarch64/run_package/Ascend-pyACL-20.1.rc1-linux.aarch64.run HwHiAiUser@192.168.0.2:~/
```

-  ssh登录到开发板上然后执行如下命令安装PyACL包
`ssh HwHiAiUser@192.168.0.2`
```
./Ascend-pyACL-20.1.rc1-linux.aarch64.run --install --run
```


- 如下图所示，PyACL安装成功：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143313_dcced508_7380811.png "屏幕截图.png")

- 执行如下命令可以看到PyACL安装成功：

```
ls /home/HwHiAiUser/Ascend
```
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143337_f4aadc6f_7380811.png "屏幕截图.png")

4) 配置开发板环境变量

使用如下命令检查开发板是否已配置环境变量：

```
cat ~/.bashrc | grep PATH
```

如下图所示，如果打印输出包含如下红框中的内容则跳过此步骤：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0118/162259_40a65026_7380811.png "屏幕截图.png")

如果上述命令打印输出不包含上图中红框的内容，则需要执行如下命令更新开发板环境变量配置：

```
ssh HwHiAiUser@192.168.0.2 "echo 'export LD_LIBRARY_PATH=/home/HwHiAiUser/Ascend/acllib/lib64:/home/HwHiAiUser/ascend_ddk/arm/lib:${LD_LIBRARY_PATH}' >> .bashrc ; echo 'export PYTHONPATH=/home/HwHiAiUser/Ascend/ascend-toolkit/latest/arm64-linux/pyACL/python/site-packages/acl:${PYTHONPATH}' >> .bashrc"
```

使用如下命令确认环境变量，下图中红框中的内容为更新的内容：

```
ssh HwHiAiUser@192.168.0.2 "tail -n8  .bashrc"
```
![输入图片说明](https://images.gitee.com/uploads/images/2021/0118/162326_4f3da87b_7380811.png "屏幕截图.png")

### 步骤 4 准备推理输入数据

本实验的工程文件包中包含预置的3张图片作为推理输入数据，图片存放在工程目录下的./data目录中，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143413_ed3aa46e_7380811.png "屏幕截图.png")

用户可将要推理的图片存放于此目录作为推理输入数据。

### 步骤 5 登录开发板运行工程

1) 使用如下命令登录开发板

```
ssh HwHiAiUser@192.168.0.2
```

2) 进入程序所在开发板中的工程目录，执行如下命令运行工程

```
cd ~/HIAI_PROJECTS/classification_python/
python3 classify.py ./data/
```

3) 查看工程运行完成后的推理结果，如下图

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143426_c8cc8d2d_7380811.png "屏幕截图.png")

如图所示，文件名为dog2_1024_683.jpg的图像推理结果中置信度最高分类为standard poodle。

4) 查看推理图片

推理产生的结果图片保存在outputs文件夹，可拷贝至Mindstudio安装用户的家目录中查看。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143439_758fec56_7380811.png "屏幕截图.png")

在PC机执行如下命令进行拷贝：

```
scp -r HwHiAiUser@192.168.0.2:~/HIAI_PROJECTS/classification_python/outputs ~
```

在本地Ubuntu中查看拷贝后的推理结果图片，如下：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143450_b762ae69_7380811.png "屏幕截图.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143502_80c8c0bd_7380811.png "屏幕截图.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143506_26ccc87a_7380811.png "屏幕截图.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/143510_2480ce03_7380811.png "屏幕截图.png")



## 5 图像分类原理

图片分类代码流程图如下所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/115657_7f506420_7380811.png "图片1.png")
详细开发步骤及代码逻辑分析参见下述说明。

## 6 开发步骤和关键代码分析

将模型部署到Atlas 200DK的步骤一般是这样的：

- 首先，模型转换，得到在昇腾AI处理器上能够跑起来的离线模型，经过上面的实验准备环节，已经得到了om模型。


- 然后，基于ACL接口进行应用开发。

代码的开发过程大致分为以下步骤：


1)运行管理资源申请；

2)加载模型文件，构建模型输出内存；

3)数据获取，并对图像数据进行预处理；

4)构建模型输入数据； 

5)模型推理，将数据输入到模型进行推理；

6)解析模型推理结果，将推理结果标注在图像上；

7)释放资源，包括卸载模型，释放模型推理时在设备上申请的内存空间以及运行管理资源释放。



### 步骤 1 运行管理资源申请 

运行管理资源申请的功能封装在了函数Classify._init_resource 中。

 **函数源码如下所示，ACL相关功能接口的调用已在函数中进行了说明：** 		

```
1. def _init_resource(self):
2.     print("[Sample] init resource stage:")
3.     # aclc初始化
4.     ret = acl.init()
5.     check_ret("acl.rt.set_device", ret)
6.
7.     # 指定运行设备
8.     ret = acl.rt.set_device(self.device_id)
9.     check_ret("acl.rt.set_device", ret)
10.
11.     # 创建context
12.     self.context, ret = acl.rt.create_context(self.device_id)
13.     check_ret("acl.rt.create_context", ret)
14.
15.     # 创建stream
16.     self.stream, ret = acl.rt.create_stream()
17.     check_ret("acl.rt.create_stream", ret)
18.
19.     # 获取当前昇腾AI软件栈的运行模式
20.     self.run_mode, ret = acl.rt.get_run_mode()
21.     check_ret("acl.rt.get_run_mode", ret)
22.
23.     print("Init resource stage success")
```

### 步骤 2 加载模型文件，构建模型输出内存

1) 加载本地om模型文件到内存中，并创建并获取模型的描述信息，此函数功能封装在Model.init_resource。

 **函数定义及相关源码注释如下所示：** 

```
1. def init_resource(self):
2.     print("[Model] class Model init resource stage:")
3.     # 加载模型
4.     self.model_id, ret = acl.mdl.load_from_file(self.model_path)
5.     check_ret("acl.mdl.load_from_file", ret)
6.     # 创建模型描述信息
7.     self.model_desc = acl.mdl.create_desc()
8.     # 获取模型描述信息
9.     ret = acl.mdl.get_desc(self.model_desc, self.model_id)
10.    check_ret("acl.mdl.get_desc", ret)
11.    # 根据模型描述信息，获取模型输出个数
12.    output_size = acl.mdl.get_num_outputs(self.model_desc)
13.    self._gen_output_dataset(output_size)
14.    print("[Model] class Model init resource stage success")
15.    self._get_output_info(output_size)
16.    return SUCCESS

```

2) 根据模型的描述信息，获取模型的每路输出数据在设备上所需的空间大小

此函数功能封装在Model._gen_output_dataset中。

ACL库内置数据类型说明：aclmdlDataset主要用于描述模型推理时的输入数据或输出数据，模型可能存在多个输入、多个输出，每个输入或输出的内存地址、内存大小用aclDataBuffer类型的数据来描述。

 **函数定义及相关源码注释如下所示：** 

```
1. def _gen_output_dataset(self, size):
2.     print("[Model] create model output dataset:")
3. # 创建 aclmdlDataset 类型数据
4. dataset = acl.mdl.create_dataset()
5. for i in range(size):
6.     # 根据aclmdlDesc类型的数据，获取指定输出的大小
7.     temp_buffer_size = acl.mdl. \
8.         get_output_size_by_index(self.model_desc, i)
9.     # 申请Device上的内存
10.    temp_buffer, ret = acl.rt.malloc(temp_buffer_size,
11.                                     ACL_MEM_MALLOC_NORMAL_ONLY)
12.    check_ret("acl.rt.malloc", ret)
13.    # 创建aclDataBuffer类型的数据
14.    dataset_buffer = acl.create_data_buffer(temp_buffer,
15.                                            temp_buffer_size)
16.    # 向aclmdlDataset中增加aclDataBuffer
17.    _, ret = acl.mdl.add_dataset_buffer(dataset, dataset_buffer)
18.    if ret:
19.        acl.destroy_data_buffer(dataset)
20.        check_ret("acl.destroy_data_buffer", ret)
21. self.output_dataset = dataset
22. print("[Model] create model output dataset success")
```

### 步骤 3 读取本地图像数据并进行预处理

读取本地图像数据后，使用DVPP的JPEGD功能将图片数据解码为YUV420SP并使用DVPP的resize功能对图像数据进行缩放至模型要求的输入图像分辨率；将读取到的图像数据拷贝至设备侧申请的内存空间中，为接下来构建模型输入数据做好准备。

DVPP的解码功能函数封装在Dvpp.jpegd中。

 **函数定义及相关源码注释如下所示：** 

```
1. def jpegd(self, image):
2.     print('[Dvpp] vpc decode stage:')
3.     # 将图像数据拷贝到设备侧
4.     device_image = image.copy_to_device(self._run_mode)
5.     # 获取图像解码后输出图像描述信息以及所在内存空间地址
6.     output_desc, out_buffer = self._gen_jpegd_out_pic_desc(image)
7.     # 解码图片，解码后图片格式为YUV420SP
8.     ret = acl.media.dvpp_jpeg_decode_async(self._dvpp_channel_desc,
9.                                            device_image.data(),
10.                                           image.size,
11.                                           output_desc,
12.                                           self._stream)
13.    if ret != ACL_ERROR_NONE:
14.        print("dvpp_jpeg_decode_async failed ret={}".format(ret))
15.        return None
16.    # 阻塞应用程序运行，等待图像解码完成
17.    ret = acl.rt.synchronize_stream(self._stream)
18.    if ret != ACL_ERROR_NONE:
19.        print("dvpp_jpeg_decode_async failed ret={}".format(ret))
20.        return None
21.    width = align_up16(image.width)
22.    height = align_up2(image.height)
23.    # 返回解码后的图像数据信息
24.    return AclImage(out_buffer, width, height, yuv420sp_size(width, height))

```

DVPP的大小缩放功能函数封装在Dvpp.resize中。

 **函数定义及相关源码注释如下所示：** 

```
1. def resize(self, image, resize_width, resize_height):
2.     print('[Dvpp] vpc resize stage:')
3.     # 创建并获取输入图像描述信息
4.     input_desc = self._gen_input_pic_desc(image)
5.     # 创建并获取输出图像描述信息以及缩放后图像数据内存地址和数据大小
6.     output_desc, out_buffer, out_buffer_size = \
7.         self._gen_resize_out_pic_desc(resize_width, resize_height)
8.     # 对图像进行大小缩放，缩放至模型要求的输入图像分辨率
9.     ret = acl.media.dvpp_vpc_resize_async(self._dvpp_channel_desc,
10.                                          input_desc,
11.                                          output_desc,
12.                                          self._resize_config,
13.                                          self._stream)
14.    check_ret("acl.media.dvpp_vpc_resize_async", ret)
15.    # 阻塞应用程序运行，等待图像大小缩放完成
16.    ret = acl.rt.synchronize_stream(self._stream)
17.    check_ret("acl.rt.synchronize_stream", ret)
18.    print('[Dvpp] vpc resize stage success')
19.    stride_width = align_up16(image.width)
20.    stride_height = align_up2(image.height)
21.    # 返回缩放后图像数据信息
22.    return AclImage(out_buffer, stride_width, stride_height, out_buffer_size)

```

### 步骤 4 构建模型输入数据，进行模型推理

构建模型的输入数据，本样例中的googlenet模型有一路输入，此输入是描述设备侧包含有图像数据的内存空间。 

构建模型输入数据的功能函数封装在Model._gen_input_dataset中。

 **函数定义及相关源码注释如下所示：** 

```
1. def _gen_input_dataset(self, data, data_size):
2.     # 创建aclmdlDataset类型的数据
3.     self.input_dataset = acl.mdl.create_dataset()
4.     # 创建aclDataBuffer类型的数据
5.     input_dataset_buffer = acl.create_data_buffer(data, data_size)
6.     # 向aclmdlDataset中增加aclDataBuffer
7.     _, ret = acl.mdl.add_dataset_buffer(
8.         self.input_dataset,
9.         input_dataset_buffer)
10.    if ret:
11.        ret = acl.destroy_data_buffer(self.input_dataset)
12.        check_ret("acl.destroy_data_buffer", ret)

```

### 步骤 5 模型推理

根据已经加载到内存中，要进行推理的模型ID、构建好的模型推理输入数据，调用ACL库中模型推理接口进行模型推理。

模型推理功能函数封装在了Model.execute中。

 **函数定义及相关源码注释如下所示：** 

```
1. def execute(self, data, data_size):
2.     # 构建模型的输入数据
3.     self._gen_input_dataset(data, data_size)
4.     # 执行模型推理，阻塞等待，直到返回推理结果
5.     ret = acl.mdl.execute(self.model_id,
6.                           self.input_dataset,
7.                           self.output_dataset)
8.     check_ret("acl.mdl.execute", ret)
9.     # 模型推理后每一路输出数据转换为numpy数组插入到列表中，返回numpy数组列表，用来解析推理结果
10.    return self._output_dataset_to_numpy()

```

### 步骤 6 解析模型推理结果

模型的输出为1000个float型数据，1000个float型数据代表1000中物体类别，每个float型数据为归一化数据范围0 ~ 1。代表该类物体识别的置信度，选取其中置信度最高的类别，作为图像的分类结果。

模型推理结果解析的功能函数封装在Classify.post_process中。

 **函数定义及相关源码注释如下所示：** 

```
1. def post_process(self, infer_output, image_file):
2.     print("post process")
3.     # 提取模型第一路输出数据
4.     data = infer_output[0]
5.     # 降维成一维数组
6.     vals = data.flatten()
7.     # 每一个数据代表一类物体的置信度
8.     # 获取置信度为前5的数据的索引下标
9.     top_k = vals.argsort()[-1:-6:-1]
10.    # 本次推理的图片名及存放路径
11.    print("images:{}".format(image_file))
12.    print("======== top5 inference results: =============")
13.    for n in top_k:
14.        # 根据下标索引获取当前置信度对应的物体的类别
15.        object_class = get_image_net_class(n)
16.        # 将分类结果打印到终端显示
17.        print("label:%d  confidence: %f, class: %s" % (n, vals[n], object_class))
18.    # 使用pillow，将置信度最高的类别写在图片上，并保存到本地
19.    if len(top_k):
20.        object_class = get_image_net_class(top_k[0])
21.        output_path = os.path.join("./outputs", os.path.basename(image_file))
22.        origin_img = Image.open(image_file)
23.        draw = ImageDraw.Draw(origin_img)
24.        font = ImageFont.truetype("SourceHanSansCN-Normal.ttf", size=30)
25.        draw.text((10, 50), object_class, font=font, fill=255)
26.        origin_img.save(output_path)

```

### 步骤 7 资源释放

推理接收后要卸载模型，并释放与模型推理相关的资源，此功能函数封装在Model.__del__中。

 **函数定义及相关源码注释如下所示：** 

```
1.def __del__(self):
2.    # 释放模型的输入输出数据描述
3.    self._release_dataset()
4.    # 系统完成模型推理后，可调用该接口传入模型ID卸载模型
5.    if self.model_id:
6.        ret = acl.mdl.unload(self.model_id)
7.        check_ret("acl.mdl.unload", ret)
8.    # 销毁模型描述信息(aclmdlDesc类型的数据)
9.    if self.model_desc:
10.        ret = acl.mdl.destroy_desc(self.model_desc)
11.        check_ret("acl.mdl.destroy_desc", ret)
12.    print("Model release source success")
```

释放存放图像数据的内存空间的功能函数封装在AclImage.destroy中。

 **函数定义及相关源码注释如下所示：** 

```
# 释放存放图像数据的内存空间
1. def destroy(self):
2.     if self._memory_type == MEMORY_DEVICE:
3.         acl.rt.free(self._data)
4.     elif self._memory_type == MEMORY_HOST:
5.         acl.rt.free_host(self._data)
6.     elif self._memory_type == MEMORY_DVPP:
7.         acl.rt.free_dvpp(self._data)
```

运行管理资源释放以及ACL去初始化的功能函数封装在Classify.__del__中。

 **函数定义及相关源码注释如下所示：** 

```
1. def __del__(self):
2.     # 释放模型管理对象
3.     if self._model:
4.         del self._model
5.     # 释放dvpp图像预处理管理对象
6.     if self._dvpp:
7.         del self._dvpp
8.     # 销毁stream
9.     if self.stream:
10.        acl.rt.destroy_stream(self.stream)
11.    # 销毁Context
12.    if self.context:
13.        acl.rt.destroy_context(self.context)
14.    # 复位当前运算的Device，释放Device上的资源
15.    acl.rt.reset_device(self.device_id)
16.    # 应用的进程退出前，显示调用该接口实现ACL去初始化
17.    acl.finalize()
18.    print("[Sample] class Samle release source success")

```

