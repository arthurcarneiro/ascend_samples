<!-- GFM-TOC -->

* [1 实验介绍](#1-实验介绍)
* [2 实验原理](#2-实验原理)
* [3 实验环境](#3-实验环境)
* [4 快速体验](#4-快速体验)
* [5 语义分割原理](#5-语义分割原理)
* [6 开发步骤和关键代码分析](#6-开发步骤和关键代码分析)
  <!-- GFM-TOC -->
# 1 实验介绍

本实验是基于Atlas 200DK的语义分割项目，基于deeplabv_plus语义分割网络编写的示例代码，该示例代码部署在Atlas 200DK上 ，通过读取本地图像数据作为输入，对图像中的物体进行目语义分割，得到分割后的结果，最后使用OpenCV写到本地文件中。
# 2 实验原理

![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/161711_9c25ecee_7380811.png "屏幕截图.png")
 **1)运行管理资源申请：** 用于初始化系统内部资源，固定的调用流程。

 **2)加载模型文件并构建输出内存：** 从文件加载离线模型数据，需要由用户自行管理模型运行的内存，根据内存中加载的模型获取模型的基本信息包含模型输入、输出数据的数据buffer大小；由模型的基本信息构建模型输出内存，为接下来的模型推理做好准备。

 **3)获取本地图像并进行预处理：** 从本地存放有图像数据的目录中循环读取图像数据并OpenCV的resize功能对图像数据进行缩放至模型要求的输入图像分辨率。

 **4)模型推理：** 根据构建好的模型输入数据进行模型推理。

 **5)解析推理结果：** 根据模型输出，解析模型的推理结果。使用OpenCV处理推理后的图像数据。

# 3 实验环境

实验前需要制作SD卡，连接Atlas 200DK的Ubuntu服务器上准备好软件环境，安装步骤请参考文档链接：
https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0003.html


# 4 快速体验

### 步骤 1 在Ubuntu18.04服务器上获取语义分割源码包

1)切换至普通用户（如ascend），执行如下命令：
`su - ascend`
2)执行如下命令在ascend用户下创建工程存放目录，并进入该目录：

```
mkdir -p ~/AscendProjects
cd ~/AscendProjects
```

3)执行如下命令获取语义分割工程：
`wget https://obs-book.obs.cn-east-2.myhuaweicloud.com/liuyuan/20.1samples/deeplabv3_pascal_pic.zip`
如果服务器上没有wget命令，使用以下命令进行安装：
`sudo apt-get install wget`
如果使用wget下载失败，可使用如下命令下载代码。
`curl -OL https://obs-book.obs.cn-east-2.myhuaweicloud.com/liuyuan/20.1samples/deeplabv3_pascal_pic.zip`
如果服务器上没有curl命令，使用以下命令进行安装：
`sudo apt-get install curl`
如果curl也下载失败，可复制下载链接到浏览器，手动上传至服务器。
4)解压工程文件压缩包：
`unzip deeplabv3_pascal_pic.zip`
如果服务器上没有unzip命令，使用以下命令进行安装：
`sudo apt-get install unzip`
工程文件目录如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/163318_5f37b796_7380811.png "屏幕截图.png")
工程目录说明如下表所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/163451_db4ec39e_7380811.png "屏幕截图.png")

### 步骤 2 获取模型

我们选择tensorflow的deeplabv3+模型，此处提供了可以直接使用的om 模型。
1)执行如下命令在到deeplabv3_plus工程的model目录下
`cd $HOME/AscendProjects/deeplabv3_pascal_pic/model`
2)下载原始网络模型
`wget https://modelzoo-train-atc.obs.cn-north-4.myhuaweicloud.com:443/003_Atc_Models/nkxiaolei/DeepLapV3_Plus/deeplabv3_plus.om`
如下表示下载完成
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/164705_699105d6_7380811.png "屏幕截图.png")

`注：本次的模型在C75环境转换不成功，需要在C76 上转换，故此处直接提供已经转换好的om 文件`
### 步骤 3准备开发板运行环境

本次实验使用USB直连的方式连接Ubuntu服务器与开发板，开发板的IP地址为192.168.1.2，下文中涉及开发板IP地址的操作请替换为实际IP地址。
1)创建开发板工程主目录
如果已经创建过开发板工程主目录，则此步骤可跳过。
如果首次使用开发板，则需要使用如下命令创建开发板工程主目录：
`ssh HwHiAiUser@192.168.1.2 "mkdir HIAI_PROJECTS"`
提示password时输入开发板密码，开发板默认密码为Mind@123。
2)将应用代码（含转换后的离线模型）拷贝至开发板
`scp -r ~/AscendProjects/deeplabv3_pascal_pic HwHiAiUser@192.168.1.2:~/HIAI_PROJECTS`
提示password时输入开发板密码，开发板默认密码为Mind@123，如下图：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/164746_7b628903_7380811.png "屏幕截图.png")

3)拷贝ACL库文件至开发板
可以参考此链接进行操作https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0017.html
- 下载“Ascend-pyACL-20.1.rc1-linux.aarch64.run“并拷贝到开发板上

```
wget https://obs-9be7.obs.cn-east-2.myhuaweicloud.com/turing/resource/atlas200dk/20.1/Ascend-pyACL-20.1.rc1-linux.aarch64.run
scp Ascend-cann-toolkit_20.1.rc1_linux-aarch64/run_package/Ascend-pyACL-20.1.	rc1-linux.aarch64.run HwHiAiUser@192.168.1.2:~/
```
- ssh登录到开发板上然后执行如下命令安装PyACL包

```
chmod +x Ascend-pyACL-20.1.rc1-linux.aarch64.run
./Ascend-pyACL-20.1.rc1-linux.aarch64.run --install --run
```

- 如下图所示，PyACL安装成功：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/164859_9c365abb_7380811.png "屏幕截图.png")

- 执行如下命令可以看到PyACL安装成功：
`ls /home/HwHiAiUser/Ascend`
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/164916_108dc765_7380811.png "屏幕截图.png")

4)配置开发板环境变量
使用如下命令检查开发板是否已配置环境变量：
`ssh HwHiAiUser@192.168.1.2 "cat ~/.bashrc | grep PATH"`
如下图所示，如果打印输出包含如下红框中的内容则跳过此步骤：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/164928_962f6c88_7380811.png "屏幕截图.png")

如果上述命令打印输出不包含上图中红框的内容，则需要执行如下命令更新开发板环境变量配置：
`ssh HwHiAiUser@192.168.1.2 "echo 'export LD_LIBRARY_PATH=/home/HwHiAiUser/Ascend/acllib/lib64:/home/HwHiAiUser/ascend_ddk/arm/lib:\${LD_LIBRARY_PATH}' >> .bashrc ; echo 'export PYTHONPATH=/home/HwHiAiUser/Ascend/pyACL/python/site-packages/acl:\${PYTHONPATH}' >> .bashrc"`
使用如下命令确认环境变量，下图中红框中的内容为更新的内容：
`ssh HwHiAiUser@192.168.1.2 "tail -n8  .bashrc"`
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/164950_5f5e3c23_7380811.png "屏幕截图.png")

### 步骤 4 准备推理输入数据

本实验的工程文件包中包含预置的3张图片作为推理输入数据，图片存放在工程目录下的./data目录中，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/165021_cadb5453_7380811.png "屏幕截图.png")

用户可将要推理的图片存放于此目录作为推理输入数据。

### 步骤 5 登录开发板运行工程

1)使用如下命令登录开发板
`ssh HwHiAiUser@192.168.1.2`
2)进入拷贝至开发板中的工程目录，执行如下命令运行工程

```
cd ~/HIAI_PROJECTS/deeplabv3_pascal_pic/
python3 src/deeplabv3.py ./data/
```

3)程序执行过程中会提示输入HwHiAiUser用户的密码，要输入HwHiAiUser的密码
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/165103_c3a88972_7380811.png "屏幕截图.png")

4)查看推理图片。
推理产生的结果图片保存在outputs文件夹，可传到Mindstudio安装用户的家目录中查看。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/165109_00d9bbf0_7380811.png "屏幕截图.png")
可执行如下命令：
`scp -r HwHiAiUser@192.168.1.2:/home/HwHiAiUser/HIAI_PROJECTS/deeplabv3_pascal_pic/outputs ~`
在本地Ubuntu中查看传回的推理结果图片
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/165121_70631179_7380811.png "屏幕截图.png")

# 5 语义分割原理

语义分割代码流程图如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0126/165233_ff3a518d_7380811.png "333.png")

详细开发步骤及代码逻辑分析参见下述说明。
# 6 开发步骤和关键代码分析

将模型部署到Atlas 200DK的步骤一般是这样的：

- 首先，模型转换，得到在昇腾AI处理器上能够跑起来的离线模型，经过上面的实验准备环节，已经得到了om模型。
- 然后，基于ACL接口进行应用开发。

代码的开发过程大致分为以下步骤：
1)运行管理资源申请；
2)加载模型文件，构建模型输出内存；
3)数据获取，并对图像数据进行预处理；
4)构建模型输入数据； 
5)模型推理，将数据输入到模型进行推理；
6)解析模型推理结果，将推理结果保存成图片。
7)释放资源，包括卸载模型，释放模型推理时在设备上申请的内存空间以及运行管理资源释放。

### 步骤 1 运行管理资源申请

运行管理资源申请的功能封装在了class AclResource的函数init中，对应的文件为acl_resource.py
关于ACL的相关介绍可以查询如下链接：
https://support.huaweicloud.com/asdevg-c-A200dk_3000_c75/atlasapi_07_0244.html
 **函数源码如下所示，ACL相关功能接口的调用已在函数中进行了说明：** 

```
1.def init(self):    
2.        """init"""    
3.        print("[Sample] init resource stage:")    
4.        ret = acl.init()    
5.        check_ret("acl.rt.set_device", ret)    
6.    
7.        ret = acl.rt.set_device(self.device_id)    
8.        check_ret("acl.rt.set_device", ret)    
9.    
10.        self.context, ret = acl.rt.create_context(self.device_id)    
11.        check_ret("acl.rt.create_context", ret)    
12.    
13.        self.stream, ret = acl.rt.create_stream()    
14.        check_ret("acl.rt.create_stream", ret)    
15.    
16.        self.run_mode, ret = acl.rt.get_run_mode()    
17.        check_ret("acl.rt.get_run_mode", ret)    
18.  
19.        print("Init resource success")    
20.        return    
```


### 步骤 2 加载模型文件，构建模型输出内存

1)加载本地om模型文件到内存中，并创建并获取模型的描述信息，此函数功能封装在class Model的init_resource函数中。
对应文件是acl_model.py
 **函数定义及相关源码注释如下所示：** 

```
1.def _init_resource(self):    
2.        print("Init model resource")    
3.        #load model file    
4.        self.model_id, ret = acl.mdl.load_from_file(self.model_path)    
5.        check_ret("acl.mdl.load_from_file", ret)    
6.        self.model_desc = acl.mdl.create_desc()    
7.        ret = acl.mdl.get_desc(self.model_desc, self.model_id)    
8.        check_ret("acl.mdl.get_desc", ret)    
9.    
10.        #get model output    
11.        output_size = acl.mdl.get_num_outputs(self.model_desc)    
12.    
13.        #create model output dataset    
14.        self._gen_output_dataset(output_size)    
15.        print("[Model] class Model init resource stage success")    
16.    
17.        #get model output description    
18.        self._get_output_desc(output_size)    
19.    
20.        #create input buffer     
21.        self._init_input_buffer()    
22.        return SUCCESS    
```


2)根据模型的描述信息，获取模型的每路输出数据在设备上所需的空间大小
此函数功能封装在class Model的函数_gen_output_dataset中。
ACL库内置数据类型说明：aclmdlDataset主要用于描述模型推理时的输入数据或输出数据，模型可能存在多个输入、多个输出，每个输入或输出的内存地址、内存大小用aclDataBuffer类型的数据来描述。
对应文件是acl_model.py
 **函数定义及相关源码注释如下所示：** 

```
1.def _gen_output_dataset(self, size):    
2.     print("[Model] create model output dataset:")    
3.     dataset = acl.mdl.create_dataset()    
4.     for i in range(size):    
5.         # create output memory     
6.         temp_buffer_size = acl.mdl.\    
7.             get_output_size_by_index(self.model_desc, i)    
8.         temp_buffer, ret = acl.rt.malloc(temp_buffer_size,    
9.                                          ACL_MEM_MALLOC_NORMAL_ONLY)    
10.         check_ret("acl.rt.malloc", ret)    
11.         #create output data buffer    
12.         dataset_buffer = acl.create_data_buffer(temp_buffer,    
13.                                                 temp_buffer_size)    
14.         #add data buffer to output dataset    
15.         _, ret = acl.mdl.add_dataset_buffer(dataset, dataset_buffer)    
16.         if ret:    
17.             #free resource     
18.             acl.rt.free(temp_buffer)    
19.             acl.destroy_data_buffer(dataset)    
20.             check_ret("acl.destroy_data_buffer", ret)    
21.     self.output_dataset = dataset    
22.     print("[Model] create model output dataset success")    
23.     return   
```
### 步骤 3 读取本地图像数据并进行预处理

读取本地图像数据后，使用OpenCV 的resize功能对图像数据进行缩放至模型要求的输入图像分辨率；将读取到的图像数据拷贝至设备侧申请的内存空间中，为接下来构建模型输入数据做好准备。
对应的文件是deeplabv3.py
 **函数定义及相关源码注释如下所示：** 

```
1.  def preprocess(picPath):    
2.    """preprocess"""    
3.    #read img    
4.    bgr_img = cv.imread(picPath)    
5.    print(bgr_img.shape)    
6.    #get img shape    
7.    orig_shape = bgr_img.shape[:2]    
8.    #resize img    
9.    img = cv.resize(bgr_img, (MODEL_WIDTH, MODEL_HEIGHT)).astype(np.int8)    
10.    # save memory C_CONTIGUOUS mode    
11.    if not img.flags['C_CONTIGUOUS']:    
12.        img = np.ascontiguousarray(img)    
13.    return orig_shape, img    
```


### 步骤 4 构建模型输入数据，进行模型推理

构建模型的输入数据，构建模型输入数据的功能函数封装在class Model的函数_gen_input_dataset中。
对应文件是acl_model.py
 **函数定义及相关源码注释如下所示：** 

```
1. def _gen_input_dataset(self, input_list):    
2.       ret = SUCCESS    
3.       if len(input_list) != self._input_num:    
4.           print("Current input data num %d unequal to"    
5.                 " model input num %d" % (len(input_list), self._input_num))    
6.           return FAILED    
7.    
8.       self.input_dataset = acl.mdl.create_dataset()    
9.       for i in range(self._input_num):    
10.           item = input_list[i]    
11.           data, size = self._parse_input_data(item, i)                
12.           if (data is None) or (size == 0):    
13.               ret = FAILED    
14.               print("The %d input is invalid" % (i))    
15.               break    
16.    
17.           dataset_buffer = acl.create_data_buffer(data, size)    
18.           _, ret = acl.mdl.add_dataset_buffer(self.input_dataset,    
19.                                               dataset_buffer)    
20.           if ret:    
21.               print("Add input dataset buffer failed")    
22.               acl.destroy_data_buffer(self.input_dataset)    
23.               ret = FAILED    
24.               break    
25.       if ret == FAILED:    
26.           self._release_dataset(self.input_dataset)    
27.       return ret    
```

### 步骤 5 模型推理

根据已经加载到内存中，要进行推理的模型ID、构建好的模型推理输入数据，调用ACL库中模型推理接口进行模型推理。
模型推理功能函数封装在了Model.execute中。对应文件是acl_model.py
 **函数定义及相关源码注释如下所示：** 

```
1. def execute(self, input_list):    
2.     """execute"""    
3.     ret = self._gen_input_dataset(input_list)    
4.     if ret == FAILED:    
5.         print("Gen model input dataset failed")    
6.         return None    
7.             
8.     start = datetime.datetime.now()    
9.     ret = acl.mdl.execute(self.model_id,    
10.                           self.input_dataset,    
11.                           self.output_dataset)    
12.     if ret != ACL_ERROR_NONE:    
13.         print("Execute model failed for acl.mdl.execute error ", ret)    
14.         return None    
15.     end = datetime.datetime.now()            
16.     print("acl.mdl.execute exhaust ", end - start)    
17.     self._release_dataset(self.input_dataset)    
18.     self.input_dataset = None    
     return self._output_dataset_to_numpy()    
```

### 步骤 6 解析模型推理结果

模型推理结果解析的功能函数封装在post_process中。对应文件是deeplabv3.py
 **函数定义及相关源码注释如下所示：** 

```
1. def postprocess(result_list, pic, orig_shape, pic_path):    
2.    """postprocess"""    
3.    result_img = result_list[0].reshape(513, 513)    
4.    result_img = result_img.astype('uint8')    
5.    orig_img = cv.imread(pic_path)    
6.    img = cv.merge((result_img, result_img, result_img))    
7.    bgr_img = cv.resize(img, (orig_shape[1], orig_shape[0]))    
8.    bgr_img = (bgr_img + 255)    
9.    output_pic = os.path.join(OUTPUT_DIR, "out_" + pic)    
10.   cv.imwrite(output_pic, bgr_img)  
```
  
### 步骤 7 资源释放

推理接收后要卸载模型，并释放与模型推理相关的资源，此功能函数封装在class Model 的__del__（self）函数中。
对应文件是acl_model.py
 **函数定义及相关源码注释如下所示：** 

```
1.def __del__(self):    
2.        if self._is_released:    
3.            return    
4.        self.acl_resource.unregister_resource(self)    
5.    
6.        print("Model start release...")    
7.        self._release_dataset(self.input_dataset)    
8.        self._release_dataset(self.output_dataset)    
9.        if self.model_id:    
10.            ret = acl.mdl.unload(self.model_id)    
11.            if ret != ACL_ERROR_NONE:    
12.                print("acl.mdl.unload error:", ret)    
13.    
14.        if self.model_desc:    
15.            ret = acl.mdl.destroy_desc(self.model_desc)    
16.            if ret != ACL_ERROR_NONE:    
17.                print("acl.mdl.destroy_desc error:", ret)    
18.        self._is_released = True    
19.        print("Model release source success")    
20.        return    
```


运行管理资源释放以及ACL去初始化的功能函数封装在class AclResource中的__del__函数
对应文件是acl_resource.py
 **函数定义及相关源码注释如下所示：** 

```
1. def __del__(self):    
2.        print("Release acl resource, ", len(self.other_resource_list))    
3.        for i in range(len(self.other_resource_list)):     
4.            print("Start relase resource ", i)               
5.            if self.other_resource_list[i][DICT_KEY_STATUS] == DICT_VAL_REG:    
6.                del self.other_resource_list[i][DICT_KEY_RESOURCE]    
7.    
8.        if self.stream:    
9.            acl.rt.destroy_stream(self.stream)    
10.        if self.context:    
11.            acl.rt.destroy_context(self.context)    
12.        acl.rt.reset_device(self.device_id)    
13.        acl.finalize()    
14.        print("Release acl resource success")    
15.        return    
```

