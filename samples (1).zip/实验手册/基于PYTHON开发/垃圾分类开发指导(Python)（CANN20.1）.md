<!-- GFM-TOC -->
* [1. 项目介绍](#1-项目介绍)
* [2. 实验目的](#2-实验目的)
* [3. 预备知识](#3-预备知识)
* [4. 实验环境](#4-实验环境)
* [5. 运行垃圾分类工程](#5-运行垃圾分类工程)
* [6. 实验原理及流程](#6-实验原理及流程)
* [7. 实验任务及步骤](#7-实验任务及步骤)
<!-- GFM-TOC -->

# 1 项目介绍

本文档主要介绍垃圾分类代码开发并部署在Atlas 200 DK开发板上执行的方法。通过Atlas 200 DK开发板来实现垃圾分类推理实验，通过读取本地图像数据作为输入，对图像中的垃圾物体进行检测，并且将检测结果图片保存到文件中。用户可以通过垃圾分类项目对Atlas 200 DK开发板在AI方面的应用有全面的认识。

# 2 实验目的

了解熟悉垃圾分类应用代码的编写(Python语言)。
掌握将应用部署在Atlas 200 DK开发板上的操作。

# 3 预备知识

具备一定的深度学习理论知识，对业界主流的深度学习框架（MindSpore 、Caffe、TensorFlow等）有一定了解。
具备Python开发能力。
了解Linux操作系统的基本使用。

# 4 实验环境

实验环境需要从硬件和软件两个方面进行准备：

（1） 硬件配件准备环境：
    使用Atlas 200 DK前，需自行购买相关配件，包含制作Atlas 200 DK启动系统的micro SD卡、读卡器，与Ubuntu虚拟机相连接的Type-C数据线，详细的配件信息如表4.1所示：
 
**表4-1硬件配件清单** 

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/092414_bb10be4f_8018002.png "屏幕截图.png")

（2）软件部署环境：
    参考文档：[https://support.huaweicloud.com/asdevg-python-A200dk_3000_c75/atlaspython_01_0035.html](https://support.huaweicloud.com/asdevg-python-A200dk_3000_c75/atlaspython_01_0035.html)

# 5 运行垃圾分类工程

开发者可以先从此链接[https://gitee.com/ascend/samples/tree/master/python/contrib/garbage_picture](https://gitee.com/ascend/samples/tree/master/python/contrib/garbage_picture)下载的样例工程根据readme所述跑通样例工程，体会一下整体的执行流程。

# 6 实验原理及流程

## 6.1 实验原理

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/092933_9e6eb9f8_8018002.png "屏幕截图.png")
**图6.1 垃圾分类实验原理图** 

本实验是基于Atlas 200DK的图像分类项目，基于garbage_yuv分类网络编写的示例代码，该示例代码部署在Atlas 200DK上 ，通过读取本地图像数据作为输入，对图像中的物体进行识别分类，并将分类的结果展示出来

在本实验中，主要聚焦在Atlas 200 DK开发板上的应用案例移植环节，因此读者需要重点关注图片数据预处理及数据推理、检测结果后处理环节的操作。

完整的实验流程涉及到的模块介绍如下：

1. 预处理模块读取本地data目录下的jpg格式的图片，读取图片之后调用DVPP的jpegd函数将jpg格式的图片解码成YUV格式，然后再调用DVPP的resize函数将YUV格式的图片缩放至模型需要的尺寸。
2. 推理模块接收经过预处理之后的图片数据，调用ACL库中模型推理接口进行模型推理。将推理得到的垃圾类别的置信度集合作为输出传给后处理模块。
3. 后处理模块接收推理结果，选取其中置信度最高的类别，作为垃圾分类的分类结果，并使用PIL将分类结果写入图片中。

## 6.2 实验流程
![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/093155_6262f8c9_8018002.png "屏幕截图.png")
 **图 6.2 垃圾分类应用案例移植流程图** 

在本实验中，默认已完成硬件环境和软件环境的准备工作，在此基础上进行垃圾分类应用项目的实验操作，由上图可知，本实验需要分别在Ubuntu主机PC端完成基于Python的垃圾分类应用代码的编写工作，以及垃圾分类模型转换，最后在Atlas 200 DK开发板上进行项目部署执行工作。

本案例移植的源代码编写及运行以链接
（[https://gitee.com/ascend/samples/tree/master/python/contrib/garbage_picture](https://gitee.com/ascend/samples/tree/master/python/contrib/garbage_picture)
）里的源码为例进行说明，实验任务及步骤将围绕图6.2所示四个方面分别展开介绍。

# 7 实验任务及步骤

 **任务一 实验准备** 

本实验使用Python进行开发，并使用命令行操作进行应用的部署和使用，因此我们选用官方提供的图像分类应用案例作为接下来开发的模板工程。图像分类应用案例可在[https://gitee.com/ascend/samples/tree/master/python/level2_simple_inference/1_classification/googlenet_imagenet_picture](https://gitee.com/ascend/samples/tree/master/python/level2_simple_inference/1_classification/googlenet_imagenet_picture)中进行下载。

参考该案例的README _cn.md进行软件准备、部署、运行等步骤。确保环境配置无误，并能够得到正确的结果，即可进行下一步的开发。

 **任务二 模型转换** 

在完成垃圾分类模型的训练（训练可参考[https://gitee.com/ascend/samples/wikis/MobileNetV2%E5%9E%83%E5%9C%BE%E5%88%86%E7%B1%BB?sort_id=3404387](https://gitee.com/ascend/samples/wikis/MobileNetV2%E5%9E%83%E5%9C%BE%E5%88%86%E7%B1%BB?sort_id=3404387)）得到mindspore的mobilenetv2.air算法模型之后，首先需要进行离线模型转换这一步骤，将mindspore的mobilenetv2.air模型转换为Ascend 310芯片支持的模型（Davinci架构模型），才可进一步将其部署在Atlas 200 DK开发板上。

通过ATC命令对训练得到的mindspore的模型进行转化。

步骤 1 设置LD_LIBRARY_PATH环境变量


```
export install_path=$HOME/Ascend/ascend-toolkit/latest
export PATH=/usr/local/python3.7.5/bin:${install_path}/atc/ccec_compiler/bin:${install_path}/atc/bin:$PATH
export PYTHONPATH=${install_path}/atc/python/site-packages:${install_path}/atc/python/site-packages/auto_tune.egg/auto_tune:${install_path}/atc/python/site-packages/schedule_search.egg:$PYTHONPATH
export LD_LIBRARY_PATH=${install_path}/atc/lib64:$LD_LIBRARY_PATH
export ASCEND_OPP_PATH=${install_path}/opp
```

步骤 2  获取配置文件

```
wget https://c7xcode.obs.cn-north-4.myhuaweicloud.com/models/garbage_picture/insert_op_yuv.cfg
```

步骤 3  ATC转化

```
atc --model=./mobilenetv2.air --framework=1 --output=garbage_yuv --soc_version=Ascend310 --insert_op_conf=./insert_op_yuv.cfg --input_shape="data:1,3,224,224" --input_format=NCHW
```

执行完之后会在当前执行ATC命令的目录下生成garbage_yuv.om文件

 **任务三 应用代码修改** 

完成以上步骤后，我们得到了所需要的网络模型。我们基于任务一获取的Python模板工程进行修改和补充，构建垃圾分类算法应用。接下来我们将对预处理模块、推理模块以及后处理模块的更新和补充进行介绍。

步骤 1  预处理模块

预处理模块调用DVPP的jpegd功能将本地图片解码成YUV格式，之后调用DVPP的resize将YUV图片resize至模型需要的宽高，最后输入模型进行推理。

该部分的代码如清单7.1所示，更详细的代码请查看项目代码。

清单7.1 预处理模块代码

```
    def pre_process(self, image):
        yuv_image = self._dvpp.jpegd(image)
        print("decode jpeg end")
        resized_image = self._dvpp.resize(yuv_image, 
                        self._model_width, self._model_height)
        print("resize yuv end")
        return resized_image
```

步骤 2  推理模块

推理模块对应的函数为classify_test.py中的 inference(self, resized_image):，完成推理过程后，即可得到推理结果。

该部分的代码如清单7.2所示，更详细的代码请查看项目代码。

清单7.2推理模块

```
def inference(self, resized_image):
    return self._model.execute(resized_image.data(), resized_image.size)
```

步骤 3  后处理模块
在得到推理模块输出的结果后，我们需要对其进行后处理，首先提取模型第一路输出得到置信度最高的垃圾类别，使用pillow将置信度最高的垃圾类别写在图片上，并保存到本地文件。

该部分的代码如清单7.3所示，更详细的代码请查看项目代码。

清单7.3后处理模块

```
 def post_process(self, infer_output, image_file):
        print("post process")
        data = infer_output[0]
        vals = data.flatten()
        top_k = vals.argsort()[-1:-6:-1]
        object_class = get_image_net_class(top_k[0])
        output_path = os.path.join(os.path.join(SRC_PATH, "../outputs/"),'out_'+ os.path.basename(image_file))
        origin_img = Image.open(image_file)
        draw = ImageDraw.Draw(origin_img)
        font = ImageFont.load_default()
        font.size =50
        draw.text((10, 50), object_class, font=font, fill=255)
        origin_img.save(output_path)
        object_class = get_image_net_class(top_k[0])        
        return object_class
```

 **任务四 应用运行** 
本应用的运行过程是在开发板上执行，需要将工程文件拷贝到开发板上。

我们在如下链接[https://gitee.com/ascend/samples/tree/master/python/contrib/garbage_picture](https://gitee.com/ascend/samples/tree/master/python/contrib/garbage_picture)的readme中详细提供了运行本案例部署和运行步骤、脚本使用方法与各参数的意义供读者阅读与实验。

步骤 1 准备开发板运行环境

本次实验使用USB直连的方式连接Ubuntu服务器与开发板，开发板的IP地址为192.168.1.2，下文中涉及开发板IP地址的操作请替换为实际IP地址。

1)创建开发板工程主目录

如果已经创建过开发板工程主目录，则此步骤可跳过。

如果首次使用开发板，则需要使用如下命令创建开发板工程主目录：


```
ssh HwHiAiUser@192.168.1.2 "mkdir HIAI_PROJECTS"
```

提示password时输入开发板密码，开发板默认密码为Mind@123。

2)将应用代码（含转换后的离线模型）拷贝至开发板

```
scp -r ~/AscendProjects/garbage_picture HwHiAiUser@192.168.1.2:/home/HwHiAiUser/HIAI_PROJECTS
```

提示password时输入开发板密码，开发板默认密码为Mind@123，如下图：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/094201_760c916a_8018002.png "屏幕截图.png")

3)拷贝ACL库文件至开发板

可以参考此链接进行操作[https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0017.html](https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0017.html)

- 下载“Ascend-pyACL-20.1.rc1-linux.aarch64.run“并拷贝到开发板上

```
wget https://obs-9be7.obs.cn-east-2.myhuaweicloud.com/turing/resource/atlas200dk/20.1/Ascend-pyACL-20.1.rc1-linux.aarch64.run
scp Ascend-cann-toolkit_20.1.rc1_linux-aarch64/run_package/Ascend-pyACL-20.1.	rc1-linux.aarch64.run HwHiAiUser@192.168.1.2:~/
```

- ssh登录到开发板上然后执行如下命令安装PyACL包

```
chmod +x Ascend-pyACL-20.1.rc1-linux.aarch64.run
./Ascend-pyACL-20.1.rc1-linux.aarch64.run --install --run
```

- 如下图所示，PyACL安装成功：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/094420_ae1aec61_8018002.png "屏幕截图.png")

- 执行如下命令可以看到PyACL安装成功：

```
ls /home/HwHiAiUser/Ascend
```

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/094521_8ae579e2_8018002.png "屏幕截图.png")

4)配置开发板环境变量

使用如下命令检查开发板是否已配置环境变量：

```
ssh HwHiAiUser@192.168.1.2 "cat ~/.bashrc | grep PATH"
```

如下图所示，如果打印输出包含如下红框中的内容则跳过此步骤：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/094612_eae60264_8018002.png "屏幕截图.png")

如果上述命令打印输出不包含上图中红框的内容，则需要执行如下命令更新开发板环境变量配置：

```
ssh HwHiAiUser@192.168.1.2 "echo 'export LD_LIBRARY_PATH=/home/HwHiAiUser/Ascend/acllib/lib64:/home/HwHiAiUser/ascend_ddk/arm/lib:\${LD_LIBRARY_PATH}' >> .bashrc ; echo 'export PYTHONPATH=/home/HwHiAiUser/Ascend/pyACL/python/site-packages/acl:\${PYTHONPATH}' >> .bashrc"
```

使用如下命令确认环境变量，下图中红框中的内容为更新的内容：

```
ssh HwHiAiUser@192.168.1.2 "tail -n8  .bashrc"
```

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/094702_63ca658c_8018002.png "屏幕截图.png")

步骤 2 准备推理输入数据

本实验的工程文件包中包含预置的4张图片作为推理输入数据，图片存放在工程目录下的./data目录中，如下图所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/094839_1f40e116_8018002.png "屏幕截图.png")

用户可将要推理的图片存放于此目录作为推理输入数据。

步骤 3  登录开发板运行工程

1)使用如下命令登录开发板

```
ssh HwHiAiUser@192.168.1.2
```

2)进入拷贝至开发板中的工程目录，执行如下命令运行工程

```
cd HIAI_PROJECTS/garbage_picture/
python3 src/classify_test.py ./data/
```

3)查看工程运行完成后的推理结果，如下图

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/094939_1eb97d57_8018002.png "屏幕截图.png")

4)查看推理图片

推理产生的结果图片保存在outputs文件夹

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/094954_2d634f17_8018002.png "屏幕截图.png")

将推理结果图片从Atlas200dk拷贝至本地Ubuntu的家目录中查看。在本地Ubuntu执行如下命令进行拷贝：

```
scp -r HwHiAiUser@192.168.1.2:~/HIAI_PROJECTS/garbage_picture/outputs ~
```

在本地Ubuntu中查看拷贝后的推理结果图片，如下：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/095019_7c693e2f_8018002.png "屏幕截图.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/095026_dc93aac0_8018002.png "屏幕截图.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/095032_f172cb7a_8018002.png "屏幕截图.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/095040_72cbfb28_8018002.png "屏幕截图.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0127/095044_4defbdd1_8018002.png "屏幕截图.png")