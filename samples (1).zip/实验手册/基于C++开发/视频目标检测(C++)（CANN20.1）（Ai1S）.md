<!-- GFM-TOC -->

* [1 实验介绍](#1-实验介绍)
* [2 实验原理](#2-实验原理)
* [3 实验环境](#3-实验环境)
* [4 快速体验](#4-快速体验)
* [5 视频目标检测原理](#5-视频目标检测原理)
* [6 开发步骤和关键代码分析](#6-开发步骤和关键代码分析)
  <!-- GFM-TOC -->

## 1 实验介绍

本实验是基于Ai1s服务器的视频目标检测项目，基于yolov3检测网络编写的示例代码，该示例代码部署在Ai1s服务器上，通过读取本地视频文件作为输入数据，对视频帧中的物体进行目标检测，并将检测的结果展示在PC网页上，用户可以通过视频目标检测项目对Ai1s服务器在AI方面的应用有一定的认识。

## 2 实验原理

![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/150951_d6d2b42e_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)1762.png")

 **1)运行管理资源申请：** 用于初始化系统内部资源，固定的调用流程。

 **2)加载模型文件并构建输出内存：** 从文件加载离线模型数据，根据内存中加载的模型获取模型的基本信息包含模型输入、输出数据的数据buffer大小；由模型的基本信息构建模型输出内存，为接下来的模型推理做好准备。

 **3)读取本地视频并进行预处理：** 使用OpenCV打开本地视频文件，循环读取每一帧图像数据，将图像数据缩放至模型要求的宽高比例；然后构建模型的输入数据。

 **4)模型推理：** 根据构建好的模型输入数据，调用模型推理接口，进行模型推理。

 **5)解析推理结果：** 根据模型输出解析目标检测的结果，得到图像数据中检测到的目标框，检测到的物体类别以及相似度，然后调用Presenter Agent的接口发送到主机端上部署好的Presenter Server服务进程，进行Web UI展示。

 **6)Presenter Server接收推理结果：** Presenter Server根据接收到的推理结果，在JPEG图片上进行目标框位置及目标的类别和置信度的标记，并将图像信息推送给主机端Web Ul，通过浏览器访问Presenter Server, 实时查看视频中的各类物体检测信息。

## 3 实验环境

实验前需要在Ai1s服务器上准备好软件环境，请参考文档：

《环境搭建指导_Ai1s弹性云服务器场景(C75).docx》

## 4 快速体验

### 步骤1 在本地开发环境搭建好的Ubuntu18.04环境上获取目标检测源码包

1）切换至普通用户（如ascend），并行如下命令：

```linux
 su ascend                             
```

2）执行如下命令在ascend用户下创建工程存放目录，并进入该目录：

```
mkdir -p $HOME/AscendProjects

cd $HOME/AscendProjects
```

3）执行如下命令获取目标检测工程：

```
wget https://obs-book.obs.cn-east-2.myhuaweicloud.com/liuyuan/20.1samples/ai1s/objectdetection_video.zip
```

   如果使用wget下载失败，可使用如下命令下载代码。

```
curl -OL https://obs-book.obs.cn-east-2.myhuaweicloud.com/liuyuan/20.1samples/ai1s/objectdetection_video.zip
```

 如果curl也下载失败，可复制下载链接到浏览器，手动上传至服务器。

4）解压工程文件压缩包：

```
unzip objectdetection_video.zip
```

工程目录如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/153400_b47f15f8_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)2948.png")

工程文件说明如下表所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/155028_4a2de85b_7380811.png "图片2.png")

### 步骤2模型转换(命令行方式)

我们选择caffe的YOLOV3模型，需要将其转换为昇腾AI处理器支持的Davinci模型文件，这里我们选择使用命令行方式对模型进行转换。

1) 获取此应用中所需要的原始网络模型，下载原始网络模型和权重文件至Mind Studio所在的ubuntu服务器(即本地开发环境)任意目录，如:$HOME/yolov3

```
mkdir -p $HOME/yolov3
cd  $HOME/yolov3
wget -P $HOME/yolov3 https://c7xcode.obs.cn-north-4.myhuaweicloud.com/models/yolov3/yolov3.caffemodel
wget -P $HOME/yolov3 https://c7xcode.obs.cn-north-4.myhuaweicloud.com/models/yolov3/yolov3.prototxt
wget -P $HOME/yolov3 https://c7xcode.obs.myhuaweicloud.com/models/yolov3/aipp_bgr.cfg
```

如下图所示，模型下载完毕：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/160216_2b83ed83_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)4169.png")




2) 将原始网络模型转换为昇腾AI处理器支持的Davinci模型

执行如下命令，进入目录下：

```
cd ${HOME}/yolov3
```

执行如下命令设置环境变量：

```
export install_path=$HOME/Ascend/ascend-toolkit/20.1.rc1/x86_64-linux    
export PATH=/usr/local/python3.7.5/bin:${install_path}/atc/ccec_compiler/bin:${install_path}/atc/bin:$PATH
export PYTHONPATH=${install_path}/atc/python/site-packages:${install_path}/atc/python/site-packages/auto_tune.egg/auto_tune:${install_path}/atc/python/site-packages/schedule_search.egg:$PYTHONPATH
export LD_LIBRARY_PATH=${install_path}/atc/lib64:$LD_LIBRARY_PATH
export ASCEND_OPP_PATH=${install_path}/opp
```

在普通用户下使用atc命令进行模型转换：

```
atc --model=yolov3.prototxt --weight=yolov3.caffemodel --framework=0 --output=yolov3 --soc_version=Ascend310 --insert_op_conf=aipp_bgr.cfg
```

模型转换成功后，存放在当前的目录下：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/160239_102c0935_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)4913.png")




执行如下命令，将转换成功的模型放到工程目录的model文件夹下：

```
cp ./yolov3.om $HOME/AscendProjects/objectdetection_video/model/
```

转换成功的模型在工程目录的model文件夹下：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/160309_fa9272ab_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)5037.png")

### 步骤3在MindStudio中打开工程文件

1) 打开对应的工程

切换至安装Mind Studio的用户（如ascend），并进入“MindStudio-ubuntu/bin”目录，如：$HOME/MindStudio-ubuntu/bin。执行如下命令启动Mind Studio：

```
./MindStudio.sh &
```

启动成功后，打开objectdetection_video工程如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/160632_c4bc5af3_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)5232.png")

工程打开后如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/160658_5d69bee9_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)5246.png")

###  步骤4编译工程文件

1) 修改Presenter Server的IP。

将script/object_detection.conf中的presenter_server_ip、presenter_view_ip、presenter_agent_ip 修改为Ai1s所在Ubuntu服务器的内网ip地址，
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/161217_42265e65_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)5393.png")


比如 内网ip地址为 192.168.1.161 如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/161234_bb5ffff3_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)5427.png")

将src/object_detect.cpp中的 param.host_ip修改为Ai1s所在Ubuntu服务器的内网ip地址，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/161250_0a1a5677_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)5500.png")

 **说明：ai1s所在服务器的内网ip地址请通过ifconfig命令查看，如下图所示：** 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/161304_7610f314_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)5544.png")

给公网ip开端口

请参考 https://bbs.huaweicloud.com/forum/thread-61588-1-1.html 

2) 编译配置，在Mind Studio工具栏中依次点击Build > Edit Build Configuration，“Target OS” 选择为“Linux” ，”Target Architecture”选择为 “x86_64”, 然后“Build”。如下图所示： 

![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/161402_14d538a6_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)5751.png")

3) 然后再依次点击Build > Build > Build Configuration，如下图所示，会在目录下生成build和out文件夹
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/161427_e4ae9cb2_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)5822.png")

4) 启动Presenter Server

假设ai1s服务器的公网ip地址为 114.117.233.x。在Mind Studio中打开Terminal 窗口 执行如下命令：将presenter server发送到ai1s所在的服务器上。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/161454_fec6b9af_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)5943.png")

等待文件上传成功，上传ai1s服务器成功后如下图所示。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/161531_165aef62_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)5973.png")

然后通过 ssh 登录到 ai1s服务器，进入到script脚本目录下 执行如下命令开启presenter server。

```
cd script/
bash run_presenter_server.sh &
```

Presenter Server 启动后如下图所示，返回登录Presenter Server网站的URL
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/161611_1a255296_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)6132.png")

打开Mind Studio工具的Terminal，在应用代码存放路径下，执行如下命令在后台启动objectdetection_video应用的Presenter Server主程序。

```
bash script/run_presenter_server.sh &
```

如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/161631_b410bfa6_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)6272.png")

Presenter Server 启动后如下图所示，返回登录Presenter Server网站的URL
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/161643_0584b595_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)6327.png")

### 步骤5运行工程

1) 在Mind Studio的工具栏中找到Run按钮，单击 Run > Edit Configurations，在Target Host Ip中添加远端ai1s的ip地址，用于连接ai1s，如下图所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/162530_3e8c9bde_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)6434.png")

单击右侧“+”按钮后弹出Device Manager 界面，如下图所示操作，添加Ai1s服务器的公网ip：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/162544_05ab2061_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)6490.png")

Ai1s的ip添加成功，如下图所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/162557_71f23a3b_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)6511.png")

在Command Arguments 中添加运行参数 ../data/detection.mp4（输入视频文件的路径），之后分别点击Apply、OK。如下图所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/162618_032e054d_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)6595.png")

2) 单击 Run > Run 'objectdetection_video'，可执行程序在ai1s服务器上执行，如下图所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/162701_4dbff03f_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)6658.png")

3) 启动Presenter Server服务时提示的URL是ai1s环境内网的ip。此时我们只要将ip替换为ai1s环境的公网ip，就可以在windows的浏览器中直接打开网页了。

比如，本ai1s环境的显示内容如下Please visit http://192.168.1.161:7007 for object_detect  只需要将192.168.1.161替换为Ai1环境的公网ip，如124.70.8.192。

在浏览器中输入 http://124.70.8.192:7007 即可打开Presenter Server网页。

等待Presenter Agent传输数据给服务端，单击“Refresh“刷新，当有数据时相应的Channel 的Status变成绿色，如下图所示。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/162730_aaef93be_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)7002.png")
单击右侧对应的View Name链接，比如上图的“video”，查看结果。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/162751_4cd4a044_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)7041.png")

## 5 视频目标检测原理

视频目标检测代码流程如下图所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/163019_2e7b1ea5_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)7094.png")

详细开发步骤及代码逻辑分析参见下述说明。

## 6 开发步骤和关键代码分析

将模型部署到Ai1s的步骤一般是这样的：


- 首先，模型转换，得到在昇腾AI处理器上能够跑起来的离线模型，经过上面的实验准备环节，已经得到了om模型。

- 然后，基于ACL接口进行应用开发。

代码的开发过程大致分为以下步骤：

1) 运行管理资源申请；

2) 加载模型文件，构建模型输出内存；

3) 数据获取，读取本地视频文件，使用OpenCV循环读取每一帧图像数据；

4) 数据预处理，对模型输入的每一帧图像数据进行预处理；

5) 模型推理，将数据输入到模型进行推理；

6) 解析模型推理结果，打印模型推理输出的结果，分析模型的输出格式，将推理结果通过调用Presenter Agent的API发送到主机端UI host上部署的Presenter Server服务进程，通过浏览器访问Presenter Server，实时查看视频中的物体检测信息。

本实验项目是利用Presenter Server实现检测结果的显示，读者也可根据实际情况，自定义物体检测结果的显示方式，例如直接将检测数据结果打印在终端里显示，或者将检测数据结果保存在文件中。

### 步骤1运行管理资源申请

运行管理资源申请的功能封装在了函数SampleProcess::InitResource()中。

 **函数源码如下所示，ACL相关功能的调用已在函数中进行了说明：** 

```n
1.Result ObjectDetect::InitResource()
2.{   
3.    // 配置文件相对路径
4.    const char *aclConfigPath = "../src/acl.json";
5.    // ACL初始化接口
6.    aclError ret = aclInit(aclConfigPath);
7.    if (ret != ACL_ERROR_NONE) {
8.        ERROR_LOG("acl init failed");
9.        return FAILED;
10.    }
11.    INFO_LOG("acl init success");
12.
13.    // 指定运算的设备ID
14.    ret = aclrtSetDevice(deviceId_);
15.    if (ret != ACL_ERROR_NONE) {
16.        ERROR_LOG("acl open device %d failed", deviceId_);
17.        return FAILED;
18.    }
19.    INFO_LOG("open device %d success", deviceId_);
20.
21.    // 根据运算的设备ID创建一个Context 
22.    ret = aclrtCreateContext(&context_, deviceId_);
23.    if (ret != ACL_ERROR_NONE) {
24. ERROR_LOG("acl create context failed");
25.        return FAILED;
26.    }
27.    INFO_LOG("create context success");
28.
29.    // 创建stream
30.    ret = aclrtCreateStream(&stream_);
31.    if (ret != ACL_ERROR_NONE) {
32.        ERROR_LOG("acl create stream failed");
33.        return FAILED;
34.    }
35.    INFO_LOG("create stream success");
36.    
37.    // 获取当前应用程序是在主机上运行还是在设备上运行
38.    ret = aclrtGetRunMode(&runMode_);
39.    if (ret != ACL_ERROR_NONE) {
40.        ERROR_LOG("acl get run mode failed");
41.        return FAILED;
42.    }
43.    return SUCCESS;
44.}
```

### 步骤2加载模型文件，构建模型输出内存

1) 加载本地om模型文件到内存中，对应的功能函数原型为：

```
1.Result ModelProcess::LoadModelFromFile(const char *modelPath)
```

参数说明 —— modelPath：描述本地模型文件的存放路径

 **函数定义及相关源码注释如下所示：** 

```
1.// 加载本地模型文件
2.Result ModelProcess::LoadModelFromFile(const char *modelPath)
3.{
4.    // 标志位，判断当前是否已经加载了模型文件
5.    if (loadFlag_) {
6.        ERROR_LOG("has already loaded a model");
7.        return FAILED;
8.    }
9.
10.    aclError ret;
11.
12.    // 从文件加载离线模型数据，通过modelid获取：系统完成模型加载后生成的模型ID
13.    ret = aclmdlLoadFromFile(modelPath, &modelId_);
14.    if (ret != ACL_ERROR_NONE) {
15.        ERROR_LOG("load model from file failed, model file is %s", modelPath);
16.        return FAILED;
17.    }
18.
19.    // 设置模型加载成功的标志位
20.    loadFlag_ = true;
21.    INFO_LOG("load model %s success", modelPath);
22.    return SUCCESS;
23.}
```

2) 根据加载的模型ID，获取模型的描述信息，对应的功能函数原型为：

```
1.Result ModelProcess::CreateDesc()
```
 **函数定义及相关源码注释如下所示：** 

```
1.// 根据加载成功的模型的ID，获取该模型的描述信息
2.Result ModelProcess::CreateDesc()
3.{
4.    // 为模型描述信息创建空间，返回模型信息描述对象指针
5.    modelDesc_ = aclmdlCreateDesc();
6.    if (modelDesc_ == nullptr) {
7.        ERROR_LOG("create model description failed");
8.        return FAILED;
9.    }
10.
11.    // 根据加载的模型ID获取该模型的描述信息，记录在modelDesc_中
12.    aclError ret = aclmdlGetDesc(modelDesc_, modelId_);
13.    if (ret != ACL_ERROR_NONE) {
14.        ERROR_LOG("get model description failed");
15.        return FAILED;
16.    }
17.    INFO_LOG("create model description success");
18.    return SUCCESS;
19.}
```

3) 根据模型的描述信息，获取模型的输出个数，以及每路输出在设备上所需的空间大小

 **对应的功能函数原型为：** 

```
1.Result ModelProcess::CreateOutput()
```

ACL库内置数据类型说明：aclmdlDataset主要用于描述模型推理时的输入数据或输出数据，模型可能存在多个输入、多个输出，每个输入或输出的内存地址、内存大小用aclDataBuffer类型的数据来描述。

 **CreateOutput函数定义及相关源码注释如下所示：** 

```
1.// 为模型的输出在设备上申请好空间
2.Result ModelProcess::CreateOutput()
3.{
4.    // 当模型描述信息为空时返回
5.    if (modelDesc_ == nullptr) {
6.        ERROR_LOG("no model description, create ouput failed");
7.        return FAILED;
8.    }
9.
10.    // 获取aclmdlDataset类型的数据
11.    output_ = aclmdlCreateDataset();
12.    if (output_ == nullptr) {
13.        ERROR_LOG("can't create dataset, create output failed");
14.        return FAILED;
15.    }
16.
17.    // 根据模型描述信息，获取模型的输出有几路数据
18.    size_t outputSize = aclmdlGetNumOutputs(modelDesc_);
19.    for (size_t i = 0; i < outputSize; ++i) {
20.        // 根据模型描述信息以及输出数据的下标(即为第几路输出数据)，获取指定输出的大小
21.        // 输出大小作为返回值记录在buffer_size中
22.        size_t buffer_size = aclmdlGetOutputSizeByIndex(modelDesc_, i);
23.        void *outputBuffer = nullptr;
24.        // 使用ACL接口aclrtMalloc在设备上申请大小为buffer_size的空间
25.        // 地址记录在outputBuffer中
26.        aclError ret = aclrtMalloc(&outputBuffer, buffer_size, ACL_MEM_MALLOC_NORMAL_ONLY);
27.        if (ret != ACL_ERROR_NONE) {
28.            ERROR_LOG("can't malloc buffer, size is %zu, create output failed", buffer_size);
29.            return FAILED;
30.        }
31.
32.        // 创建aclDataBuffer类型的数据用于描述在设备上申请的内存空间地址以及相应的大小
33.        aclDataBuffer* outputData = aclCreateDataBuffer(outputBuffer, buffer_size);
34.        if (aclDataBuffer == nullptr) {
35.            ERROR_LOG("can't create data buffer, create output failed");
36.            // aclDataBuffer类型数据创建失败，则释放在设备上申请的空间
37.            aclrtFree(outputBuffer);
38.            return FAILED;
39.        }
40.
41.        // 向output_中添加outputData
42.        ret = aclmdlAddDatasetBuffer(output_, outputData);
43.        if (ret != ACL_ERROR_NONE) {
44.            ERROR_LOG("can't add data buffer, create output failed");
45.            // 向aclmdlDataset的地址中添加失败时，释放在设备上申请的空间
46.            aclrtFree(outputBuffer);
47.            // 释放aclDataBuffer类型数据空间
48.            aclDestroyDataBuffer(outputData);
49.            return FAILED;
50.        }
51.    }
52.
53.    INFO_LOG("create model output success");
54.    return SUCCESS;
55.}
```

### 步骤3读取本地视频帧数据并进行图像预处理

使用OpenCV打开本地视频文件，循环获取每一帧图像数据，将图像数据进行大小缩放，缩放至模型要求输入图像的宽高，本例中模型要求的输入图像宽高为416和416；将读取到的图像数据拷贝至设备侧申请的内存空间中，为接下来构建模型输入数据做好准备。

 **预处理函数在ObjectDetect::Preprocess 中实现：** 

```
1.Result ObjectDetect::Preprocess(cv::Mat& frame)
```

 **Main函数中实现了总的代码调用流程，这里仅将功能调用的源码列举出来：** 

```
1.cv::VideoCapture capture(videoFile);
2.if (!capture.isOpened()) {
3.	cout << "Movie open Error" << endl;
4.	return FAILED;
5.}
6.//逐帧推理
7.while(1) {
8.	//读一帧图像
9.	cv::Mat frame;
10.	//当读取到最后一帧图像的时候退出当前的循环
11.	if (!capture.read(frame)) {
12.		INFO_LOG("Video capture return false");
13.		break;
14.	}
15.	//对一帧图像进行预处理
16.	Result ret = detect.Preprocess(frame);
17.	if (ret != SUCCESS) {
18.		ERROR_LOG("Read file %s failed, continue to read next",
19.				  videoFile.c_str());
20.		continue;
21.	}
22.	//将预处理后的图像输入模型推理，得到推理结果
23.	aclmdlDataset* inferenceOutput = nullptr;
24.	ret = detect.Inference(inferenceOutput);
25.	if ((ret != SUCCESS) || (inferenceOutput == nullptr)) {
26.		ERROR_LOG("Inference model inference output data failed");
27.		return FAILED;
28.	}
29.	//解析推理输出，并将推理类、位置、置信度和图像发送到Presenter服务器进行显示
30.	ret = detect.Postprocess(frame, inferenceOutput);
31.	if (ret != SUCCESS) {
32.		ERROR_LOG("Process model inference output data failed");
33.		return FAILED;
34.	}
35.}
36.
```

### 步骤4构建模型输入数据，进行模型推理

构建模型的输入数据，本样例中的YOLOV3模型有两路输入，第一路输入是描述设备侧包含有图像数据的内存空间，第二路输入是描述模型输入图像数据宽高要求。

 **构建模型输入数据的功能函数是：** 

```
1.Result ModelProcess::CreateInput(void *input1, size_t input1size, void* input2, size_t input2size)
```

参数说明 —— 

input1 [in]: 设备侧包含图像数据的内存空间地址

input1size [in] : 描述设备侧包含图像数据的内存空间所占字节大小

input2 [in]: 设备侧用于描述模型输入图像数据宽高要求的内存空间地址

input2size [in] : 描述设备侧用于描述模型输入图像数据宽高要求的内存空间所占字节的大小

 

 **CreateInput函数定义及相关源码注释如下所示：** 

```
2.Result ModelProcess::CreateInput(void *input1, size_t input1size, 
3.                                 void* input2, size_t input2size)
4.{
5.	   // 创建aclmdlDataset类型的数据
6.	   // 用于描述模型每个输入数据的内存地址和内存大小
7.    input_ = aclmdlCreateDataset();
8.    if (input_ == nullptr) {
9.        ERROR_LOG("can't create dataset, create input failed");
10.        return FAILED;
11.    }
12.
13.	   // 创建aclDataBuffer类型的数据用于描述在设备上申请的内存空间地址以及相应的大小
14.    aclDataBuffer* inputData = aclCreateDataBuffer(input1, input1size);
15.    if (inputData == nullptr) {
16.        ERROR_LOG("can't create data buffer, create input failed");
17.        return FAILED;
18.    }
19.
20.	   // 向input_中添加outputData
21.	   // 即将描述模型第一路输入的数据信息添加到input_中
22.    aclError ret = aclmdlAddDatasetBuffer(input_, inputData);
23.    if (inputData == nullptr) {
24.        ERROR_LOG("can't add data buffer, create input failed");
25.        aclDestroyDataBuffer(inputData);
26.        inputData = nullptr;
27.        return FAILED;
28.    }
29.	   // 同理：接下来将描述模型第二路输入的数据信息添加到input_中
30.    aclDataBuffer* inputData2 = aclCreateDataBuffer(input2, input2size);
31.    if (inputData == nullptr) {
32.        ERROR_LOG("can't create data buffer, create input failed");
33.        return FAILED;
34.    }
35.
36.    ret = aclmdlAddDatasetBuffer(input_, inputData2);
37.    if (inputData == nullptr) {
38.        ERROR_LOG("can't add data buffer, create input failed");
39.        aclDestroyDataBuffer(inputData2);
40.        inputData = nullptr;
41.        return FAILED;
42.    }
43.
44.    return SUCCESS;
45.}
```

根据已经加载到内存中，要进行推理的模型ID、构建好的模型推理输入数据，调用ACL库中模型推理接口进行模型推理。

 **相应的功能函数原型为：** 

```
1.Result ModelProcess::Execute()
```

Execute函数定义及相关源码注释如下所示：

```
1.Result ModelProcess::Execute()
2.{
3.    // 执行模型推理，直到返回推理结果
4.    aclError ret = aclmdlExecute(modelId_, input_, output_);
5.    if (ret != ACL_ERROR_NONE) {
6.        ERROR_LOG("execute model failed, modelId is %u", modelId_);
7.        return FAILED;
8.    }
9.    INFO_LOG("model execute success");
10.    return SUCCESS;
11.}
```

ACL库中模型推理接口：aclmdlExecute 说明：

函数功能：执行模型推理，直到返回推理结果，同步接口。

 **函数原型：** 

```
1.aclError aclmdlExecute(uint32_t modelId, const aclmdlDataset *input, aclmdlDataset *output)
```

参数说明 —— 

modelId [in]:  指定需要执行推理的模型的ID

input [in] :   模型推理的输入数据

output [out] : 模型推理的输出数据

### 步骤5 分析样例模型推理的输出格式并解析模型推理结果

本实验将模型推理的结果解析后，通过在Ai1s服务器上部署的Presenter Server进程将检测结果可视化，利用Presenter Agent提供的API向Presenter Server推送媒体消息，Presenter Server接收Presenter Agent发过来的媒体数据，通过浏览器进行结果展示。

 **Presenter Agent 的使用方法基本如下：** 

		首先创建并打开一个连接Presenter Server的通道。
	
		发送一个包含一帧图像信息的结构体对象到presenter server。

 **1）打开通道的函数原型为：** 

```
1.PresenterErrorCode OpenChannel(Channel *&channel, const OpenChannelParam &param);
```

参数说明 —— 

	channel [out] ：指向Channel的指针
	
	param [in] : 通道参数，包含：IP、端口、通道名称、数据类型

 **OpenChannelParam的定义如下：** 

```
1.struct OpenChannelParam {
2.  std::string host_ip;
3.  std::uint16_t port;
4.  std::string channel_name;
5.  ContentType content_type;
6.};
```

 **ContentType 媒体类型定义如下：** 

```
1.enumclass ContentType {
2.// Image
3.kImage = 0,
4.// Video
5.kVideo = 1,
6.};
```

 **2）发送一帧图像信息到presenter server的函数原型为：** 

```
1.PresenterErrorCode PresentImage(Channel *channel, const ImageFrame &image);
```

参数说明 —— 

		channel [in] ：指向Channel的指针
	
		param [in] : 包含图片信息的结构体对象

 **图像信息结构体ImageFrame的定义如下所示：** 

```
1.struct ImageFrame {
2.  ImageFormat format;
3.  std::uint32_t width;
4.  std::uint32_t height;
5.  std::uint32_t size;
6.  unsignedchar *data;
7.  std::vector<DetectionResult> detection_results;
8.};  
```

 **检测出的目标位置信息的定义DetectionResult 如下：** 

```
1.struct DetectionResult {
2.	//The coordinate of left top point
3.    Point lt;   
4.	//The coordinate of the right bottom point
5.    Point rb;   
6.	// object_name:xx%
7.    std::string result_text;  
8.};
```

 **在本工程中打开通道的源码为：** 

```
2.Result ObjectDetect::OpenPresenterChannel() {
3.    OpenChannelParam param;
4.	   // Presenter Server的IP地址
5.    param.host_ip = "192.168.1.234";  
6.	   //presenter server 的端口号
7.    param.port = 7006;  
8.    param.channel_name = "video";
9.    param.content_type = ContentType::kVideo;  
10.    INFO_LOG("OpenChannel start");
11.	   // 打开presenter agent与 presenter server进行通信的通道
12.    PresenterErrorCode errorCode = OpenChannel(channel_, param);
13.    INFO_LOG("OpenChannel param");
14.    if (errorCode != PresenterErrorCode::kNone) {
15.        ERROR_LOG("OpenChannel failed %d", static_cast<int>(errorCode));
16.        return FAILED;
17.    }
18.
19.    return SUCCESS;
20.}
21.
```

 **在本工程文件中模型的推理结果解析函数原型为：
** 
```
1.Result ObjectDetect::Postprocess(cv::Mat& frame, aclmdlDataset* modelOutput)
```

在此函数中模型推理的第一路结果保存在浮点型型指针detectData中，模型推理的第二路结果保存在整形指针boxNum中。

我们将模型输出数据，格式化输出看下到底是什么，在模型推理结果解析函数中添加如下代码，将模型输出的第一路结果强转为float型数组，模型输出的第二路结果强转为int型数据，遍历数组格式化输出。

 **添加如下代码：** 

```
1.
2.#include <iomanip>
3.cout << "result ************************ "<< endl;
4.cout << "totalBox = " << totalBox << endl;
5.cout <<setiosflags(ios::fixed)<<setprecision(3)<<setiosflags(ios::left);
6.for (int i = 0; i < 6; i++) {
7.	for (int j = 0; j < totalBox; j++) {
8.		cout << setw(9) << detectData [i*totalBox + j] ;
9.	}
10.	cout << endl;
11.}
12.
```

 **代码添加后如下图所示：** 

![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/173749_9537879c_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)18583.png")

重新编译运行后，在终端打印出推理结果，如下图所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0113/173801_ab1694cc_7380811.png "C75基于Ai1s弹性云服务的实验_视频目标检测应用案例实战 (C++)18611.png")



结合这个输出打印结果以及对检测网络的认知，可以知道：

模型的第二路输出表示的是在当前视频帧中检测出来的目标个数；

模型的第一路输出表示的是所有检测框的信息；

如上图所示，当视频帧中检测的物体个数为n时，第i个（i从零开始）目标检测框的信息为：

目标检测框左上角X的坐标值(相对于模型输入图片的宽度)，位置偏移量为:【n*0+i】；

目标检测框左上角Y的坐标值(相对于模型输入图片的高度)，位置偏移量为:【n*1+i】：

目标检测框右下角X的坐标值(相对于模型输入图片的宽度)，位置偏移量为:【n*2+i】：

目标检测框右下角Y的坐标值(相对于模型输入图片的高度)，位置偏移量为:【n*3+i】：

目标检测框中检测出的物体相似度，位置偏移量为:【n*4+i】：

目标检测框中检测出物体的类别索引，位置偏移量为:【n*5+i】.

 **例如：对于视频帧中检测出的第二个目标框的信息为：** 

目标检测框左上角X的坐标值(相对于模型输入图片的宽度)【3*0+1】：295.000

目标检测框左上角Y的坐标值(相对于模型输入图片的高度)【3*1+1】：46.719

目标检测框右下角X的坐标值(相对于模型输入图片的宽度)【3*2+1】：389.750

目标检测框右下角Y的坐标值(相对于模型输入图片的高度)【3*3+1】：352.250

目标检测框中检测出的物体相似度【3*4+1】：0.984

目标检测框中检测出物体的类别索引【3*5+1】：14



 **Postprocess函数定义及相关源码注释如下所示：** 

```
1.
2.Result ObjectDetect::Postprocess(cv::Mat& frame, aclmdlDataset* modelOutput) {
3.
4.    uint32_t dataSize = 0;
5.	
6.	   // 获取模型的第一路输出数据
7.    float* detectData = (float*)GetInferenceOutputItem(dataSize, modelOutput,
8.                                                       kBBoxDataBufId);
9.    if (detectData == nullptr) return FAILED;
10.	
11.    // 获取模型的第二路输出数据
12.    uint32_t* boxNum = (uint32_t*)GetInferenceOutputItem(dataSize, modelOutput,
13.                                                         kBoxNumDataBufId);
14.    if (boxNum == nullptr) return FAILED;
15.
16.    // 当前检测到的框的个数
17.    uint32_t totalBox = boxNum[0];
18.
19.    float widthScale = (float)(frame.cols) / modelWidth_;
20.    float heightScale = (float)(frame.rows) / modelHeight_;
21.
22.    vector<DetectionResult> detectResults;
23.	   // 循环个数为单张图像中检测出的目标框的个数
24.    for (uint32_t i = 0; i < totalBox; i++) {
25.        DetectionResult oneResult;
26.        Point point_lt, point_rb;
27.        uint32_t score = uint32_t(detectData[totalBox * SCORE + i] * 100);
28.		   // 设置置信度阈值，相似度小于0.75的目标框过滤
29.        if (score < 75) continue;
30.		
31.		   // 基于原始图像目标框左上角坐标
32.        oneResult.lt.x = detectData[totalBox * TOPLEFTX + i] * widthScale;
33.        oneResult.lt.y = detectData[totalBox * TOPLEFTY + i] * heightScale;
34.		
35.		   // 基于原始图像目标框右下角坐标
36.        oneResult.rb.x = detectData[totalBox * BOTTOMRIGHTX + i] * widthScale;
37.        oneResult.rb.y = detectData[totalBox * BOTTOMRIGHTY + i] * heightScale;
38.		
39.		   // 目标检测框内物体的类别索引值
40.        uint32_t objIndex = (uint32_t)detectData[totalBox * LABEL + i];
41.		   // 描述检测物体类别和相似度的字符串
42.        oneResult.result_text = yolov3Label[objIndex] + std::to_string(score) + "\%";
43.
44.        detectResults.emplace_back(oneResult);
45.    }
46.
47.    if (runMode_ == ACL_HOST) {
48.        delete[]((uint8_t*)detectData);
49.        delete[]((uint8_t*)boxNum);
50.    }
51.
52.    // 将推理结果和图像发送到presenter服务器以进行显示
53.    SendImage(detectResults, frame);
54.
55.    return SUCCESS;
56.}
57.
58.
59.Result ObjectDetect::SendImage(vector<DetectionResult>& detectionResults,
60.                                  cv::Mat& origImg) {
61.    
62.	   vector<uint8_t> encodeImg;
63.	   // 每一帧画面是BGR数据，编码为jpg数据后为后续发送给presenter server做好准备
64.    EncodeImage(encodeImg, origImg);
65.
66.    ImageFrame imageParam;
67.    imageParam.format = ImageFormat::kJpeg;
68.    imageParam.width = origImg.cols;
69.    imageParam.height = origImg.rows;
70.    imageParam.size = encodeImg.size();
71.    imageParam.data = reinterpret_cast<uint8_t*>(encodeImg.data());
72.    imageParam.detection_results = detectionResults;
73.	   // 将检测到的对象帧信息和帧图像发送到演示服务器以显示
74.    PresenterErrorCode errorCode = PresentImage(channel_, imageParam);
75.    if (errorCode != PresenterErrorCode::kNone) {
76.        ERROR_LOG("PresentImage failed %d", static_cast<int>(errorCode));
77.        return FAILED;
78.    }
79.
80.    return SUCCESS;
81.}
82.
83.
84.void ObjectDetect::EncodeImage(vector<uint8_t>& encodeImg,
85.                                  cv::Mat& origImg) {
86.    vector<int> param = vector<int>(2);
87.    param[0] = CV_IMWRITE_JPEG_QUALITY;
88.    param[1] = 95;
89.    //将BGR图片编码为jpg图片数据 
90.    cv::imencode(".jpg", origImg, encodeImg, param);
91.}
92.
```

### 步骤6资源释放

资源释放分别在以下函数中实现，具体函数定义可以参考源码：

```
1.void ObjectDetect::DestroyResource(); 
2.void ModelProcess::Unload();
3.void ModelProcess::DestroyDesc();
4.void ModelProcess::DestroyInput();
5.void ModelProcess::DestroyOutput();
```