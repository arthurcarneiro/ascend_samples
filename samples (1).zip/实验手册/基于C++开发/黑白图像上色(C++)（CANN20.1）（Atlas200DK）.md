<!-- GFM-TOC -->

* [1 实验介绍](#1-实验介绍)
* [2 实验原理](#2-实验原理)
* [3 实验环境](#3-实验环境)
* [4 快速体验](#4-快速体验)
* [5 黑白图像上色原理](#5-黑白图像上色原理)
* [6 开发步骤和关键代码分析](#6-开发步骤和关键代码分析)
  <!-- GFM-TOC -->
# 1 实验介绍

本实验是基于Atlas 200DK的黑白图像上色项目，使用colorization模型进行推理。该示例代码部署在Atlas 200DK上 ，通过读取本地黑白图像数据作为输入，将原始黑白图像转换为彩色图片，通过OpenCV将转换的结果展示出来。
# 2 实验原理
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/164054_a06fa108_7380811.png "屏幕截图.png")

 **1)运行管理资源申请：** 用于初始化系统内部资源，固定的调用流程。

 **2)加载模型文件并构建输出内存：** 从文件加载离线模型数据，需要由用户自行管理模型运行的内存，根据内存中加载的模型获取模型的基本信息包含模型输入、输出数据的数据buffer大小；由模型的基本信息构建模型输出内存，为接下来的模型推理做好准备。

 **3)获取本地图像并进行预处理：** 从本地存放有图像数据的目录中使用OpenCV循环读取图像数据，对读入的图像数据进行预处理，然后构建模型的输入数据。

 **4)模型推理：** 根据构建好的模型输入数据进行模型推理。

 **5)解析推理结果：** 根据模型输出，解析模型的推理结果。使用OpenCV将转换后的彩色图像数据保存成图片文件。

# 3 实验环境

实验前需要制作SD卡并在连接Atlas 200DK的Ubuntu服务器上准备好软件环境，请参考文档：《环境搭建指导_Atlas 200DK场景（C75）.docx》
# 4 快速体验

### 步骤 1在Ubuntu18.04服务器上获取黑白图像上色应用源码包
1)切换至普通用户（如ascend），执行如下命令：
`su ascend`
2)执行如下命令在ascend用户下创建工程存放目录，并进入该目录：

```
mkdir -p $HOME/AscendProjects
cd $HOME/AscendProjects
```

3)执行如下命令获取黑白图像上色工程：

`wget https://c7xcode.obs.cn-north-4.myhuaweicloud.com/code_Ascend/colorization.zip`

如果使用wget下载失败，可使用如下命令下载代码。

`curl -OL https://c7xcode.obs.cn-north-4.myhuaweicloud.com/200dk/colorization.zip`

如果curl也下载失败，可复制下载链接到浏览器，手动上传至服务器。

4)解压工程文件压缩包：

`unzip colorization.zip`

工程文件目录如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/164229_fb7dba57_7380811.png "屏幕截图.png")
工程目录说明如下表所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/164648_e6903443_7380811.png "图片3.png")

### 步骤 2模型转换

在本项目中，原始网络模型是Caffe模型，因此需要将其转换为昇腾AI处理器支持的Davinci模型文件，这里我们选择使用命令行方式对模型进行转换。

1)切换到ubuntu服务器的任意目录

```
mkdir -p $HOME/models/colorization
cd $HOME/models/colorization
```

2)下载原始网络模型和权重文件

```
wget https://obs-model-ascend.obs.cn-east-2.myhuaweicloud.com/colorization/colorization.caffemodel --no-check-certificate
wget https://obs-model-ascend.obs.cn-east-2.myhuaweicloud.com/colorization/colorization.prototxt --no-check-certificate
```

如下图所示，模型下载完毕：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/164742_e794d34f_7380811.png "屏幕截图.png")
3)将原始网络模型转换为昇腾AI处理器支持的Davinci模型
使用如下命令打开Mind Studio工具：

```
cd ~/MindStudio-ubuntu/bin
./MindStudio.sh &
```

在Mind Studio操作界面的顶部菜单栏中选择Ascend > Model Converter，进入模型转换界面，在弹出的Model Conversion操作界面中进行模型转换配置，参照以下图片进行参数配置：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/164931_27f8c20b_7380811.png "屏幕截图.png")
点击Next进入下一步
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/164935_833fe1f9_7380811.png "屏幕截图.png")
点击Next进入下一步
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/164941_607e53bc_7380811.png "屏幕截图.png")
点击Finish执行转换，转换成功后会提示“Model converted successfully”，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/164945_9fb36651_7380811.png "屏幕截图.png")
模型转换成功后，存放在~/modelzoo目录下：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165003_99e051a7_7380811.png "屏幕截图.png")
执行如下命令，将转换成功的模型放到工程目录的model文件夹下：
`cp ~/modelzoo/colorization/device/colorization.om ~/AscendProjects/colorization/model`
如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165016_9b17663f_7380811.png "屏幕截图.png")


### 步骤 3在Mind Studio中打开工程文件

1)打开对应的工程
使用安装Mind Studio的用户（如ascend），进入“MindStudio-ubuntu/bin”目录，如：$HOME/MindStudio-ubuntu/bin。执行如下命令启动Mind Studio：

`./MindStudio.sh &`
启动成功后，打开colorization工程如下图所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165242_24cf9006_7380811.png "屏幕截图.png")

### 步骤 4编译工程文件

1)在Mind Studio的工具栏中依次点击Build > Edit Build Configuration，“Target OS” 择为“Linux” ，然后“Build”。如下图所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165308_f2409467_7380811.png "屏幕截图.png")
2)Build之后如下图所示，会在目录下生成build和out文件夹：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165313_70283d29_7380811.png "屏幕截图.png")

### 步骤 5运行工程

1)运行工程文件之前，需要登录开发板重启ada进程，操作步骤如下：

从Ubuntu服务器登录至Atlas200 DK开发板（假设开发板地址192.168.1.2）：
`ssh HwHiAiUser@192.168.1.2		—— 默认登录密码：Mind@123`
查看ada进程号并杀死该进程：

```
ps –ef | grep ada
kill <进程号> 			—— 该进程号为上一步查询到的进程号
```

操作命令参考如下图：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165411_a6eebc25_7380811.png "屏幕截图.png")

在开发板侧进入 /var 目录下，开启ada服务：

```
cd /var
./ada &
```
操作命令参考如下图：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165423_b1123fc9_7380811.png "屏幕截图.png")

2)在Mind Studio的工具栏找到Run按钮，单击 Run > Edit Configurations，在Target Host Ip中添加开发板ip，用于连接开发板，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165448_851a8526_7380811.png "屏幕截图.png")
单击右侧“+”按钮后弹出Device Manager 界面，如下图所示操作，添加开发板：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165452_5ae18689_7380811.png "屏幕截图.png")
设备添加成功，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165502_9f229b1f_7380811.png "屏幕截图.png")

在Command Arguments 中添加运行参数“../data”，之后分别点击Apply、OK。如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165510_b4cec280_7380811.png "屏幕截图.png")

3)单击 Run > Run 'colorization'，可执行程序在开发板执行，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165520_0f7c8211_7380811.png "屏幕截图.png")

4)在Mind Studio中查看推理结果，结果保存在工程目录 out/outputs 目录下，如图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165530_036abc7f_7380811.png "屏幕截图.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165535_cd601f80_7380811.png "屏幕截图.png") --> ![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165541_59b72cfc_7380811.png "屏幕截图.png")

# 5 黑白图像上色原理

黑白图像上色代码流程图如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/165752_d256ff27_7380811.png "图片4.png")
详细开发步骤及代码逻辑分析参见下述说明。

# 6 开发步骤和关键代码分析

将模型部署到Atlas 200DK的步骤一般是这样的：

- 首先，模型转换，得到在昇腾AI处理器上能够跑起来的离线模型，经过上面的实验准备环节，已经得到了om模型。
- 然后，基于ACL接口进行应用开发。

代码的开发过程大致分为以下步骤：

- 1)运行管理资源申请；
- 2)加载模型文件，构建模型输出内存；
- 3)数据获取并进行预处理，获取要进行推理的原始图像，根据模型的输入要求，对输入图像进行预处理；
- 4)模型推理，将数据输入到模型进行推理；
- 5)解析模型推理结果，将经过解析的模型推理结果展示出来；
- 6)释放资源。

### 步骤 1运行管理资源申请

运行管理资源申请的功能封装在了函数ColorizeProcess::InitResource()中。
 **函数源码如下所示，ACL相关功能接口的调用已在函数中进行了说明：** 

```
1.Result ColorizeProcess::InitResource()
2.{   
3.    // 配置文件相对路径
4.    const char *aclConfigPath = "../src/acl.json";
5.    // ACL初始化接口
6.    aclError ret = aclInit(aclConfigPath);
7.    if (ret != ACL_ERROR_NONE) {
8.        ERROR_LOG("acl init failed");
9.        return FAILED;
10.    }
11.    INFO_LOG("acl init success");
12.
13.    // 指定运算的设备ID
14.    ret = aclrtSetDevice(deviceId_);
15.    if (ret != ACL_ERROR_NONE) {
16.        ERROR_LOG("acl open device %d failed", deviceId_);
17.        return FAILED;
18.    }
19.    INFO_LOG("open device %d success", deviceId_);
20.
21.    return SUCCESS;
22.}
```

### 步骤 2加载模型文件，构建模型输出内存

1)加载本地om模型文件到内存中，对应的功能函数原型为：
`1.Result ModelProcess:: LoadModelFromFileWithMem (const char *modelPath)`

参数说明 —— modelPath：描述本地模型文件的存放路径
 **函数定义及相关源码注释如下所示：** 

```
1.// 加载本地模型文件
2.Result ModelProcess::LoadModelFromFile(const char *modelPath)
3.{
4.    // 标志位，判断当前是否已经加载了模型文件
5.    if (loadFlag_) {
6.        ERROR_LOG("has already loaded a model");
7.        return FAILED;
8.    }
9.
10.    aclError ret = aclmdlQuerySize(modelPath, &modelMemSize_, &modelWeightSize_);
11.    if (ret != ACL_ERROR_NONE) {
12.        ERROR_LOG("query model failed, model file is %s", modelPath);
13.        return FAILED;
14.    }
15.    
16.    
17.    ret = aclrtMalloc(&modelMemPtr_, modelMemSize_, ACL_MEM_MALLOC_HUGE_FIRST);
18.    if (ret != ACL_ERROR_NONE) {
19.        ERROR_LOG("malloc buffer for mem failed, require size is %zu", modelMemSize_);
20.        return FAILED;
21.    }
22.
23.    ret = aclrtMalloc(&modelWeightPtr_, modelWeightSize_, ACL_MEM_MALLOC_HUGE_FIRST);
24.    if (ret != ACL_ERROR_NONE) {
25.        ERROR_LOG("malloc buffer for weight failed, require size is %zu", modelWeightSize_);
26.        return FAILED;
27.    }
28.
29.
30.    // 从文件加载离线模型数据，通过modelId_获取：系统完成模型加载后生成的模型ID
31.    aclError ret = aclmdlLoadFromFileWithMem(modelPath, &modelId_，modelMemPtr_,
32.        modelMemSize_, modelWeightPtr_, modelWeightSize_);
33.    if (ret != ACL_ERROR_NONE) {
34.        ERROR_LOG("load model from file failed, model file is %s", modelPath);
35.        return FAILED;
36.    }
37.
38.    // 设置模型加载成功的标志位
39.    loadFlag_ = true;
40.    INFO_LOG("load model %s success", modelPath);
41.    return SUCCESS;
42.}
```

2)根据加载的模型ID，获取模型的描述信息，对应的功能函数原型为：
`1.Result ModelProcess::CreateDesc()`
 **函数定义及相关源码注释如下所示：** 

```
1.// 根据加载成功的模型的ID，获取该模型的描述信息
2.Result ModelProcess::CreateDesc()
3.{
4.    // 为模型描述信息创建空间，返回模型信息描述对象指针
5.    modelDesc_ = aclmdlCreateDesc();
6.    if (modelDesc_ == nullptr) {
7.        ERROR_LOG("create model description failed");
8.        return FAILED;
9.    }
10.
11.    // 根据加载的模型ID获取该模型的描述信息，记录在modelDesc_中。
12.    aclError ret = aclmdlGetDesc(modelDesc_, modelId_);
13.    if (ret != ACL_ERROR_NONE) {
14.        ERROR_LOG("get model description failed");
15.        return FAILED;
16.    }
17.    INFO_LOG("create model description success");
18.    return SUCCESS;
19.}
```

3)根据模型的描述信息，获取模型的输出个数，以及每路输出在设备上所需的空间大小
 **对应的功能函数原型为：** 
`1.Result ModelProcess::CreateOutput()`

ACL库内置数据类型说明：aclmdlDataset主要用于描述模型推理时的输入数据或输出数据，模型可能存在多个输入、多个输出，每个输入或输出的内存地址、内存大小用aclDataBuffer类型的数据来描述。
 **CreateOutput函数定义及相关源码注释如下所示：** 

```
1.// 为模型的输出在设备上申请好空间
2.Result ModelProcess::CreateOutput()
3.{
4.    // 当模型描述信息为空时返回
5.    if (modelDesc_ == nullptr) {
6.        ERROR_LOG("no model description, create ouput failed");
7.        return FAILED;
8.    }
9.
10.    // 获取aclmdlDataset类型的数据
11.    output_ = aclmdlCreateDataset();
12.    if (output_ == nullptr) {
13.        ERROR_LOG("can't create dataset, create output failed");
14.        return FAILED;
15.    }
16.
17.    // 根据模型描述信息，获取模型的输出有几路数据
18.    size_t outputSize = aclmdlGetNumOutputs(modelDesc_);
19.    for (size_t i = 0; i < outputSize; ++i) {
20.        // 根据模型描述信息以及输出数据的下标(即为第几路输出数据)，获取指定输出的大小
21.        // 输出大小作为返回值记录在buffer_size中
22.        size_t buffer_size = aclmdlGetOutputSizeByIndex(modelDesc_, i);
23.        void *outputBuffer = nullptr;
24.        // 使用ACL接口aclrtMalloc在设备上申请大小为buffer_size的空间,地址记录在outputBuffer中
25.        aclError ret = aclrtMalloc(&outputBuffer, buffer_size, ACL_MEM_MALLOC_NORMAL_ONLY);
26.        if (ret != ACL_ERROR_NONE) {
27.            ERROR_LOG("can't malloc buffer, size is %zu, create output failed", buffer_size);
28.            return FAILED;
29.        }
30.
31.        // 创建aclDataBuffer类型的数据用于描述在设备上申请的内存空间地址以及相应的大小
32.        aclDataBuffer* outputData = aclCreateDataBuffer(outputBuffer, buffer_size);
33.        if (aclDataBuffer == nullptr) {
34.            ERROR_LOG("can't create data buffer, create output failed");
35.            // aclDataBuffer类型数据创建失败，则释放在设备上申请的空间
36.            aclrtFree(outputBuffer);
37.            return FAILED;
38.        }
39.
40.      
41.        // 向output_中添加outputData
42.        ret = aclmdlAddDatasetBuffer(output_, outputData);
43.        if (ret != ACL_ERROR_NONE) {
44.            ERROR_LOG("can't add data buffer, create output failed");
45.            // 向aclmdlDataset的地址中添加失败时，释放在设备上申请的空间
46.            aclrtFree(outputBuffer);
47.            // 释放aclDataBuffer类型数据空间
48.            aclDestroyDataBuffer(outputData);
49.            return FAILED;
50.        }
51.    }
52.
53.    INFO_LOG("create model output success");
54.    return SUCCESS;
55.}

```

### 步骤 3读取本地图像数据并进行预处理

该模型输入图像减均值后的L通道数据，输出预测的ab通道数据；模型推理前，程序需要对图片进行预处理，这里是用OpenCV读取图片，读取出来的为BGR格式，需要把BGR格式转为Lab格式，并分离出L通道数据，做为模型推理的输入数据，预处理的过程如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/170818_63a59ff2_7380811.png "屏幕截图.png")
然后，将读取到的图像数据拷贝至设备侧申请的内存空间中，为接下来构建模型输入数据做好准备。

 **上述功能函数原型为：** 
`1.Result ColorizeProcess::Preprocess(const string& imageFile)`

参数说明 ——
image_path [out]: 记录图像数据的结构体对象
path [in] : 本地图像数据的路径
 **Preprocess函数定义及相关源码注释如下所示：** 


```
1.Result ColorizeProcess::Preprocess(const string& imageFile) {
2.    // read image using OPENCV
3.    cv::Mat mat = cv::imread(imageFile, CV_LOAD_IMAGE_COLOR);
4.    //resize
5.    cv::Mat reiszeMat;
6.    cv::resize(mat, reiszeMat, cv::Size(224, 224));
7.
8.    // deal image
9.    reiszeMat.convertTo(reiszeMat, CV_32FC3);
10.    reiszeMat = 1.0 * reiszeMat / 255;
11.    cv::cvtColor(reiszeMat, reiszeMat, CV_BGR2Lab);
12.
13.    // pull out L channel and subtract 50 for mean-centering
14.    std::vector<cv::Mat> channels;
15.    cv::split(reiszeMat, channels);
16.    cv::Mat reiszeMatL = channels[0] - 50;
17.
18.    if (mat.empty()) {
19.        return FAILED;
20.    }
21.
22.    if (runMode_ == ACL_HOST) {
23.        //AI1上运行时,需要将图片数据拷贝到device侧   
24.        aclError ret = aclrtMemcpy(inputBuf_, inputDataSize_,
25.                                   reiszeMatL.ptr<uint8_t>(), inputDataSize_,
26.                                   ACL_MEMCPY_HOST_TO_DEVICE);
27.        if (ret != ACL_ERROR_NONE) {
28.            ERROR_LOG("Copy resized image data to device failed.");
29.            return FAILED;
30.        }
31.    } else {
32.        //Atals200DK上运行时,数据拷贝到本地即可.
33.        //reiszeMat是局部变量,数据无法传出函数,需要拷贝一份
34.        memcpy(inputBuf_, reiszeMatL.ptr<uint8_t>(), inputDataSize_);
35.    }
36.
37.    return SUCCESS;
38.}

```
### 步骤 4构建模型输入数据，进行模型推理

构建模型的输入数据，本样例中的colorization模型有一路输入，第一路输入是描述设备侧包含有图像数据的内存空间。 
 **构建模型输入数据的功能函数是：** 
`1.Result ModelProcess::CreateInput(void *inputDataBuffer, size_t bufferSize)`
参数说明 —— 
inputDataBuffer [in]: 设备侧包含图像数据的内存空间地址
bufferSize [in] : 描述设备侧包含图像数据的内存空间所占字节大小
 **CreateInput函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::CreateInput(void *inputDataBuffer, size_t bufferSize)
2.{
3.    // 创建aclmdlDataset类型的数据
4.    // 用于描述模型每个输入数据的内存地址和内存大小
5.    input_ = aclmdlCreateDataset();
6.    if (input_ == nullptr) {
7.        ERROR_LOG("can't create dataset, create input failed");
8.        return FAILED;
9.    }
10.
11.    // 创建aclDataBuffer类型的数据用于描述在设备上申请的内存空间地址以及相应的大小
12.    aclDataBuffer* inputData = aclCreateDataBuffer(inputDataBuffer, bufferSize);
13.    if (inputData == nullptr) {
14.        ERROR_LOG("can't create data buffer, create input failed");
15.        return FAILED;
16.    }
17.
18.    // 向input_中添加outputData
19.    // 即将描述模型第一路输入的数据信息添加到input_中
20.    aclError ret = aclmdlAddDatasetBuffer(input_, inputData);
21.    if (ret != ACL_ERROR_NONE) {
22.        ERROR_LOG("can't add data buffer, create input failed");
23.        // 添加失败时释放aclDataBuffer类型数据
24.        aclDestroyDataBuffer(inputData);
25.        inputData = nullptr;
26.        return FAILED;
27.    }
28.
29.    
30.    return SUCCESS;
31.}
```

根据已经加载到内存中，要进行推理的模型ID、构建好的模型推理输入数据，调用ACL库中模型推理接口进行模型推理。
 **相应的功能函数原型为：** 
`1.Result ModelProcess::Execute()`
 **Execute函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::Execute()
2.{
3.    // 执行模型推理，直到返回推理结果
4.    aclError ret = aclmdlExecute(modelId_, input_, output_);
5.    if (ret != ACL_ERROR_NONE) {
6.        ERROR_LOG("execute model failed, modelId is %u", modelId_);
7.        return FAILED;
8.    }
9.    INFO_LOG("model execute success");
10.    return SUCCESS;
11.}
```

ACL库中模型推理接口：aclmdlExecute 说明：
函数功能：执行模型推理，直到返回推理结果，同步接口。

 **函数原型：** 
`1.aclError aclmdlExecute(uint32_t modelId, const aclmdlDataset *input, aclmdlDataset *output)`

参数说明 ——
modelId [in]:   指定需要执行推理的模型的ID
input [in] :    模型推理的输入数据
output [out] :  模型推理的输出数据

### 步骤 5解析模型推理结果

 **模型的推理结果解析函数原型为：** 
`1.Result ColorizeProcess::Postprocess(const string & path, aclmdlDataset * modelOutput)`

在此函数中模型推理的结果是预测的a和b通道数据，要将a和b通道数据resize至原图片大小，并与原图片L通道数据合并，获取完整Lab数据，再转换为BGR格式的图像数据，处理过程如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/171858_0d11b157_7380811.png "屏幕截图.png")
然后，将图像数据通过OpenCV写入到本地

 **Postprocess函数定义及相关源码注释如下所示：** 


```
1.Result ColorizeProcess::Postprocess(const string& imageFile, aclmdlDataset* modelOutput)
2.{
3.    uint32_t dataSize = 0;
4.    void* data = GetInferenceOutputItem(dataSize, modelOutput);
5.    if (data == nullptr) return FAILED;
6.
7.    uint32_t size = static_cast<uint32_t>(dataSize) / sizeof(float);
8.
9.    // get a channel and b channel result data
10.    cv::Mat mat_a(56, 56, CV_32FC1, const_cast<float*>((float*)data));
11.    cv::Mat mat_b(56, 56, CV_32FC1, const_cast<float*>((float*)data + size / 2));
12.
13.    // pull out L channel in original image
14.    cv::Mat mat = cv::imread(imageFile, CV_LOAD_IMAGE_COLOR);
15.    mat.convertTo(mat, CV_32FC3);
16.    mat = 1.0 * mat / 255;
17.    cv::cvtColor(mat, mat, CV_BGR2Lab);
18.    std::vector<cv::Mat> channels;
19.    cv::split(mat, channels);
20.
21.    // resize to match size of original image L
22.    int r = mat.rows;
23.    int c = mat.cols;
24.    cv::Mat mat_a_up(r, c, CV_32FC1);
25.    cv::Mat mat_b_up(r, c, CV_32FC1);
26.    cv::resize(mat_a, mat_a_up, cv::Size(c, r));
27.    cv::resize(mat_b, mat_b_up, cv::Size(c, r));
28.
29.    // result Lab image
30.    cv::Mat newChannels[3] = { channels[0], mat_a_up, mat_b_up };
31.    cv::Mat resultImage;
32.    cv::merge(newChannels, 3, resultImage);
33.
34.    //convert back to rgb
35.    cv::cvtColor(resultImage, resultImage, CV_Lab2BGR);
36.    resultImage = resultImage * 255;
37.    SaveImage(imageFile, resultImage);
38.
39.    return SUCCESS;
40.}
```

### 步骤 6资源释放

 **资源释放分别在以下函数中实现：** 

```
1.void ColorizeProcess::DestroyResource(); 
2.void ModelProcess::Unload();
3.void ModelProcess::DestroyDesc();
4.void ModelProcess::DestroyInput();
5.void ModelProcess::DestroyOutput();
```
