<!-- GFM-TOC -->

* [1 实验介绍](#1-实验介绍)
* [2 实验原理](#2-实验原理)
* [3 实验环境](#3-实验环境)
* [4 快速体验](#4-快速体验)
* [5 AI风景画原理](#5-AI风景画原理)
* [6 开发步骤和关键代码分析](#6-开发步骤和关键代码分析)
  <!-- GFM-TOC -->

# 1 实验介绍

本实验是基于Atlas 200DK的AI风景画项目，基于CGAN（Conditional GAN）的交互式图像生成方法编写的示例代码，该示例代码部署在Atlas 200DK上 ，只需要在前端页面的画布上选择多个类别的物体，并做相应的大小和位置拖动，通过部署在华为Atlas 200DK上的模型，就能生成相应的自然风景图。
# 2 实验原理
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/164715_4a76eb0d_7380811.png "屏幕截图.png")


 **1)运行管理资源申请：** 用于初始化系统内部资源，固定的调用流程。

 **2)加载模型文件并构建输出内存：** 从文件加载离线模型AIPainting.om数据，需要由用户自行管理模型运行的内存，根据内存中加载的模型获取模型的基本信息包含模型输入、输出数据的数据buffer大小；由模型的基本信息构建模型输出内存，为接下来的模型推理做好准备。

 **3)数据预处理：** 对输入数据进行预处理，然后构建模型的输入数据。

 **4)模型推理：** 根据构建好的模型输入数据进行模型推理。

 **5)解析推理结果：** 根据模型输出，解析模型的推理结果。使用OpenCV处理推理后的图像数据。

# 3 实验环境

实验前需要制作SD卡，连接Atlas 200DK的Ubuntu服务器上准备好软件环境，并且在开发板上安装好环境，参考文档链接：
https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0003.html

# 4 快速体验

### 步骤 1 在Ubuntu18.04服务器上获取AI风景画源码包

1)切换至普通用户（如ascend），执行如下命令：
`su - ascend`
2)执行如下命令在ascend用户下创建工程存放目录，并进入该目录：

```
mkdir -p ~/AscendProjects
cd ~/AscendProjects
```

3)执行如下命令获取AI风景画工程：
`wget https://c7xcode.obs.cn-north-4.myhuaweicloud.com/samples_0113/AI_painting.zip`
如果服务器上没有wget命令，使用以下命令进行安装：
`sudo apt-get install wget`
如果使用wget下载工程失败，可使用如下命令下载代码。
`curl -OL https://c7xcode.obs.cn-north-4.myhuaweicloud.com/samples_0113/AI_painting.zip`
如果curl也下载失败，可复制下载链接到浏览器，手动下载压缩包，并上传至服务器。
如果服务器上没有curl命令，使用以下命令进行安装：
`sudo apt-get install curl`
4)解压工程文件压缩包：
`unzip AI_painting.zip`
如果服务器上没有curl命令，使用以下命令进行安装：
`sudo apt-get install unzip`
工程文件目录如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/165929_bfde98d5_7380811.png "屏幕截图.png")
工程目录说明如下表所示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/170026_659f94af_7380811.png "屏幕截图.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/170032_a3a98631_7380811.png "屏幕截图.png")

### 步骤 2 模型转换（命令行方式）

我们选择AIPainting_v2的Pb模型，需要将其转换为昇腾AI处理器支持的Davinci模型文件，这里我们使用命令行方式对模型进行转换。
1)执行如下命令在ascend用户下创建模型存放目录并进入该目录

```
mkdir -p ~/models/AIpainting
cd ~/models/AIpainting
```

2)下载原始网络模型
`wget https://modelzoo-train-atc.obs.cn-north-4.myhuaweicloud.com/003_Atc_Models/AE/ATC%20Model/painting/AIPainting_v2.pb`
3)将原始网络模型转换为昇腾AI处理器支持的Davinci模型
1、设置环境变量
命令行中输入以下命令设置环境变量

```
export install_path=$HOME/Ascend/ascend-toolkit/latest
export PATH=/usr/local/python3.7.5/bin:${install_path}/atc/ccec_compiler/bin:${install_path}/atc/bin:$PATH
export PYTHONPATH=${install_path}/atc/python/site-packages:${install_path}/atc/python/site-packages/auto_tune.egg/auto_tune:${install_path}/atc/python/site-packages/schedule_search.egg:$PYTHONPATH
export LD_LIBRARY_PATH=${install_path}/atc/lib64:$LD_LIBRARY_PATH
export ASCEND_OPP_PATH=${install_path}/opp
```

2、使用ATC模型转换工具进行模型转换时可以参考如下指令，具体操作详情和参数设置可以参考 ATC工具使用指导(https://support.huaweicloud.com/tg-
```
A200dk_3000_c75/atlasatc_16_0002.html)
atc --output_type=FP32 --input_shape="objs:9;coarse_layout:1,256,256,17" --input_format=NHWC --output="AIPainting_v2" --soc_version=Ascend310 --framework=3 --model="./AIPainting_v2.pb"
```

模型转换成功后的截图如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/170942_a18dd8f6_7380811.png "屏幕截图.png")

4)将转换好的模型拷贝至工程对应的目录下

```
cp ~/models/AIPainting_v2/AIPainting_v2.om ~/AscendProjects/AI_painting/model/

```
### 步骤 3 在Mind Studio中打开工程文件

1)打开对应的工程
切换至安装Mind Studio的用户（如ascend），并进入“MindStudio-ubuntu/bin”目录，如：$HOME/MindStudio-ubuntu/bin。执行如下命令启动Mind Studio：
`./MindStudio.sh &`
启动成功后，打开AI_painting工程如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171210_2f8a7986_7380811.png "屏幕截图.png")
工程打开后如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171215_e67dacaa_7380811.png "屏幕截图.png")

### 步骤 4 编译工程文件

1)修改Presenter Server的IP。
将样例目录下scripts/param.conf中的 presenter_server_ip、presenter_view_ip 修改为开发环境中可以ping通运行环境的ip地址，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171302_c8bd5195_7380811.png "屏幕截图.png")
 **说明：200DK连接的服务器的虚拟网卡ip地址请通过ifconfig命令查看，如下图所示：** 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171318_ed0b4ffa_7380811.png "屏幕截图.png")

2)编译配置。
由于样例在仓库上是命令行编译执行的，CMakeLists.txt中的文件路径和这里我们在MindStudio中编译时的不太一样，在进行编译前，需要对CMakeLists.txt文件进行修改，如下图，将src/CMakeLists.txt中的69行里面的路径改成 
`../../scripts/param.conf ../../out/param.conf`
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171337_ee2d535f_7380811.png "屏幕截图.png")

由于MindStudio的需要，我们还要手动创建一个data目录，如图，在AI_painting目录上右键->New->Directory重命名为data
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171350_ffd421d9_7380811.png "屏幕截图.png")

在Mind Studio工具栏中依次点击Build > Edit Build Configuration，“Target OS” 选择为“Linux” ，”Target Architecture”选择为 “aarch64”, 然后“Build”。如下图所示： 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171356_a3fda234_7380811.png "屏幕截图.png")
3)然后再依次点击Build > Build > Build Configuration，如下图所示，会在目录下生成build和out文件夹
4)如图所示，表示编译成功：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171406_56772ed6_7380811.png "屏幕截图.png")

5)启动Presenter Server
打开Mind Studio工具的Terminal，在应用代码存放路径下，执行如下命令在后台启动AI_painting应用的Presenter Server主程序。
`bash scripts/run_presenter_server.sh &`
如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171414_20f33973_7380811.png "屏幕截图.png")

Presenter Server 启动后如下图所示，返回登录Presenter Server网站的URL
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171420_9ba9eae2_7380811.png "屏幕截图.png")

### 步骤 5 运行工程

1)在Mind Studio的工具栏中找到Run按钮，单击 Run > Edit Configurations，在Target Host Ip中添加开发板ip，用于连接开发板，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171520_7b7fe566_7380811.png "屏幕截图.png")
单击右侧“+”按钮后弹出Device Manager 界面，如下图所示操作，添加开发板：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171526_bea25b50_7380811.png "屏幕截图.png")
设备添加成功，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171530_a5b75861_7380811.png "屏幕截图.png")
2)单击 Run > Run 'AI_painting'，可执行程序在开发板执行，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171535_63f5c7e7_7380811.png "屏幕截图.png")
3)使用启动Presenter Server服务时提示的URL登录 Presenter Server 网站，查看运行结果
等待Presenter Agent传输数据给服务端，单击“Refresh“刷新，当有数据时相应的Channel 的Status变成绿色，如下图所示
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171540_892d3fb5_7380811.png "屏幕截图.png")
单击右侧对应的View Name链接，比如上图的“video”，查看结果。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171544_a69d6e4a_7380811.png "屏幕截图.png")

# 5 AI风景画原理

AI风景画代码流程图如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/171627_4fe29676_7380811.png "221.png")
详细开发步骤及代码逻辑分析参见下述说明。

# 6 开发步骤和关键代码分析

将模型部署到Atlas 200DK的步骤一般是这样的：

- 首先，模型转换，得到在昇腾AI处理器上能够跑起来的离线模型，经过上面的实验准备环节，已经得到了om模型。
- 然后，基于ACL接口进行应用开发。

代码的开发过程大致分为以下步骤：
1)运行管理资源申请；
2)加载模型文件，构建模型输出内存；
3)数据获取，并对图像数据进行预处理；
4)构建模型输入数据； 
5)模型推理，将数据输入到模型进行推理；
6)解析模型推理结果。
7)释放资源，包括卸载模型，释放模型推理时在设备上申请的内存空间以及运行管理资源释放。

### 步骤 1 运行管理资源申请

运行管理资源申请的功能封装在了函数PaintingProcess::InitResource()中，对应的文件为src/painting_process.cpp
 **函数源码如下所示，ACL相关功能接口的调用已在函数中进行了说明：** 

```
1.Result PaintingProcess::InitResource() {
2.    // 配置文件相对路径
3.    const char *aclConfigPath = "../src/acl.json";
4.    // ACL初始化接口
5.    aclError ret = aclInit(aclConfigPath);
6.    if (ret != ACL_ERROR_NONE) {
7.        ERROR_LOG("Acl init failed");
8.        return FAILED;
9.    }
10.    INFO_LOG("Acl init success");
11.
12.    // 指定运算设备ID
13.    ret = aclrtSetDevice(deviceId_);
14.    if (ret != ACL_ERROR_NONE) {
15.        ERROR_LOG("Acl open device %d failed", deviceId_);
16.        return FAILED;
17.    }
18.    INFO_LOG("Open device %d success", deviceId_);
19.
20.    ret = aclrtGetRunMode(&runMode_);
21.    if (ret != ACL_ERROR_NONE) {
22.        ERROR_LOG("acl get run mode failed");
23.        return FAILED;
24.    }
25.
26.    if(runMode_ == ACL_DEVICE){
27.        INFO_LOG("run mode : device");
28.        g_isDevice = true;
29.    }else{
30.        INFO_LOG("run mode : host");
31.    }
32.    INFO_LOG("get run mode success");
33.    return SUCCESS;
34.}

```
### 步骤 2 加载模型文件，构建模型输出内存

1)加载本地om模型文件到内存中，创建并获取模型的描述信息，此函数功能封装在ModelProcess::LoadModelFromFileWithMem（），对应的文件为src/model_process.cpp
 **函数定义及相关源码注释如下所示：** 

```
1.// 加载本地模型文件
2.Result ModelProcess::LoadModelFromFileWithMem(const char *modelPath) {
3.    // 标志位，判断当前是否已经加载了模型文件
4.    if (loadFlag_) {
5.        ERROR_LOG("has already loaded a model");
6.        return FAILED;
7.    }
8.    // 获取模型执行时所需的工作内存大小、权值内存大小
9.    aclError ret = aclmdlQuerySize(modelPath, &modelMemSize_, &modelWeightSize_);
10.    if (ret != ACL_ERROR_NONE) {
11.        ERROR_LOG("query model failed, model file is %s", modelPath);
12.        return FAILED;
13.    }
14.
15.    ret = aclrtMalloc(&modelMemPtr_, modelMemSize_, ACL_MEM_MALLOC_HUGE_FIRST);
16.    if (ret != ACL_ERROR_NONE) {
17.        ERROR_LOG("malloc buffer for mem failed, require size is %zu", modelMemSize_);
18.        return FAILED;
19.    }
20.
21.    ret = aclrtMalloc(&modelWeightPtr_, modelWeightSize_, ACL_MEM_MALLOC_HUGE_FIRST);
22.    if (ret != ACL_ERROR_NONE) {
23.        ERROR_LOG("malloc buffer for weight failed, require size is %zu", modelWeightSize_);
24.        return FAILED;
25.    }
26.    // 从文件加载离线模型数据（适配昇腾AI处理器的离线模型），由用户自行管理模型运行的内存
27.    ret = aclmdlLoadFromFileWithMem(modelPath, &modelId_, modelMemPtr_,
28.        modelMemSize_, modelWeightPtr_, modelWeightSize_);
29.    if (ret != ACL_ERROR_NONE) {
30.        ERROR_LOG("load model from file failed, model file is %s", modelPath);
31.        return FAILED;
32.    }
33.
34.    loadFlag_ = true;
35.    INFO_LOG("load model %s success", modelPath);
36.    return SUCCESS;
37.}
38.
```

2)根据加载的模型ID，获取模型的描述信息，对应的功能函数原型为：
ModelProcess::CreateDesc()，对应的文件为src/model_process.cpp
 **函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::CreateDesc() {
2.    // 为模型描述信息创建空间，返回模型信息描述对象指针
3.    modelDesc_ = aclmdlCreateDesc();
4.    if (modelDesc_ == nullptr) {
5.        ERROR_LOG("create model description failed");
6.        return FAILED;
7.    }
8.    // 根据加载的模型ID获取模型的描述信息，记录在modelDesc_中
9.    aclError ret = aclmdlGetDesc(modelDesc_, modelId_);
10.    if (ret != ACL_ERROR_NONE) {
11.        ERROR_LOG("get model description failed");
12.        return FAILED;
13.    }
14.
15.    INFO_LOG("create model description success");
16.    return SUCCESS;
17.}
```

3)根据模型的描述信息，获取模型的输出个数，以及每路输出在设备上所需的空间大小
对应的功能函数原型为：
ModelProcess::CreateOutput()，对应的文件为src/model_process.cpp
ACL库内置数据类型说明：aclmdlCreateDataset主要用于描述模型推理时的输入数据或输出数据，模型可能存在多个输入、多个输出，每个输入或输出的内存地址、内存大小用aclDataBuffer类型的数据来描述。
 **函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::CreateOutput() {
2.    if (modelDesc_ == nullptr) {
3.        ERROR_LOG("no model description, create ouput failed");
4.        return FAILED;
5.    }
6.    // 获取aclmdlDataset类型的数据
7.    output_ = aclmdlCreateDataset();
8.    if (output_ == nullptr) {
9.        ERROR_LOG("can't create dataset, create output failed");
10.        return FAILED;
11.    }
12.    // 根据模型描述信息，获取模型的输出有几路数据
13.    size_t outputSize = aclmdlGetNumOutputs(modelDesc_);
14.    for (size_t i = 0; i < outputSize; ++i) {
15.    // 根据模型描述信息以及输出数据的下标(即为第几路输出数据)，获取指定输出的大小
16.    // 输出大小作为返回值记录在buffer_size中
17.        size_t buffer_size = aclmdlGetOutputSizeByIndex(modelDesc_, i);
18.
19.        void *outputBuffer = nullptr;
20.    // 使用ACL接口aclrtMalloc在设备上申请大小为buffer_size的空间
21.    // 地址记录在outputBuffer中
22.        aclError ret = aclrtMalloc(&outputBuffer, buffer_size, ACL_MEM_MALLOC_NORMAL_ONLY);
23.        if (ret != ACL_ERROR_NONE) {
24.            ERROR_LOG("can't malloc buffer, size is %zu, create output failed", buffer_size);
25.            return FAILED;
26.        }
27.        // 创建aclDataBuffer类型的数据用于描述在设备上申请的内存空间地址以及相应的大小
28.        aclDataBuffer* outputData = aclCreateDataBuffer(outputBuffer, buffer_size);
29.        if (ret != ACL_ERROR_NONE) {
30.            ERROR_LOG("can't create data buffer, create output failed");
31.        // aclDataBuffer类型数据创建失败，则释放在设备上申请的空间
32.            aclrtFree(outputBuffer);
33.            return FAILED;
34.        }
35.
36.        // 向output_中添加outputData
37.        ret = aclmdlAddDatasetBuffer(output_, outputData);
38.        if (ret != ACL_ERROR_NONE) {
39.            ERROR_LOG("can't add data buffer, create output failed");
40.        // 向aclmdlDataset的地址中添加失败时，释放在设备上申请的空间
41.            aclrtFree(outputBuffer);
42.        // 释放aclDataBuffer类型数据空间
43.            aclDestroyDataBuffer(outputData);
44.            return FAILED;
45.        }
46.    }
47.
48.    INFO_LOG("create model output success");
49.    return SUCCESS;
50.}

```
### 步骤 3 获取从前端传回的数据

通过在本机部署的Presenter Server进程，利用Presenter Agent提供的API向Presenter Server推送消息，Presenter Server接收Presenter Agent发过来的数据，保存到设备侧进行模型输入数据的准备。
 **功能函数是：** 
Result DataReceiver::DoReceiverProcess(void* objectData, void* layoutData)
对应的文件为src/data_receiver.cpp

```
1.Result DataReceiver::DoReceiverProcess(void* objectData, void* layoutData) {
2.    // 获取presenter agent 的channel
3.    ascend::presenter::Channel *agent_channel = PresenterChannels::GetInstance().GetChannel();
4.    if (agent_channel == nullptr) {
5.        ERROR_LOG("get agent channel to send failed.");
6.        return FAILED;
7.    }
8.
9.    // 构造请求信息并读取信息
10.    unique_ptr<google::protobuf::Message> data_rec;
11.    ascend::presenter::PresenterErrorCode agent_ret = agent_channel->ReceiveMessage(data_rec);
12.    if (agent_ret == ascend::presenter::PresenterErrorCode::kNone) {
13.
14.        PaintingMessage::DataPackage *model_input_data_package = (PaintingMessage::DataPackage * )(data_rec.get());
15.
16.        if(model_input_data_package == nullptr){
17.            INFO_LOG("Receive data is null");
18.            return FAILED;
19.        }
20.
21.        PaintingMessage::ModelInputData object_input = model_input_data_package->objectdata();
22.        std::string object_input_name = object_input.name();
23.        std::string object_input_data = object_input.data();
24.        INFO_LOG("object_input_name: %s", object_input_name.c_str());
25.        INFO_LOG("object_input_data size: %ld", object_input_data.size());
26.
27.
28.        PaintingMessage::ModelInputData layout_input = model_input_data_package->layoutdata();
29.        std::string layout_input_name = layout_input.name();
30.        std::string layout_input_data = layout_input.data();
31.        INFO_LOG("layout_input_name: %s", layout_input_name.c_str());
32.        INFO_LOG("layout_input_data size: %ld", layout_input_data.size());
33.
34.	aclrtRunMode runMode;
35.        aclrtGetRunMode (& runMode);
36.        aclrtMemcpyKind policy = (runMode == ACL_HOST) ?
37.        ACL_MEMCPY_HOST_TO_DEVICE : ACL_MEMCPY_DEVICE_TO_DEVICE;
38.
39.        aclError ret = aclrtMemcpy(objectData, object_input_data.size(),
40.        object_input_data.c_str(), object_input_data.size(), policy);
41.        ret = aclrtMemcpy(layoutData, layout_input_data.size(),
42.        layout_input_data.c_str(), layout_input_data.size(), policy);
43.        if (ret != ACL_ERROR_NONE) {
44.            ERROR_LOG("Copy resized image data to device failed.");
45.            return FAILED;
46.        }
47.
48.        return SUCCESS;
49.
50.    } else {
51.        return FAILED;
```
### 步骤 4 构建模型输入数据，进行模型推理

构建模型的输入数据，本样例中的AI_painting模型有两路输入，第一路输入是一个vector向量（记录选择的类目），第二路输入是一个四维tensor：[1,256,256,17]，其中256表示空间维度，17表示类目个数（17个类目分别为"sky": 1, "sand": 2, "sea": 3, "mountain": 4, "rock": 5, "earth": 6, "tree": 7, "water": 8, "land": 9, "grass": 10, "path": 11, "dirt": 12, "river": 13, "hill": 14, "field": 15, "lake": 16, '__image__': 0）。
 
**构建模型输入数据的功能函数是：** 
ModelProcess::CreateInput(void *input1, size_t input1size, void* input2, size_t input2size)
对应的文件为src/model_process.cpp
参数说明 —— 

- input1 [in]: 设备侧包含记录选择类目的内存空间地址
- input1size [in] : 描述设备侧包含记录选择类目的内存空间所占字节大小
- input2 [in]: 设备侧一个四维tensor的内存空间地址
- input2size [in] : 描述设备侧一个四维tensor的内存空间所占字节的大小


 **函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::CreateInput(void *input1, size_t input1size, void* input2, size_t input2size)
2.{
3.    // 创建aclmdlDataset类型的数据
4.    // 用于描述模型每个输入数据的内存地址和内存大小
5.    input_ = aclmdlCreateDataset();
6.    if (input_ == nullptr) {
7.        ERROR_LOG("can't create dataset, create input failed");
8.        return FAILED;
9.    }
10.    // 创建aclDataBuffer类型的数据用于描述在设备上申请的内存空间地址以及相应的大小
11.    aclDataBuffer* inputData = aclCreateDataBuffer(input1, input1size);
12.    if (inputData == nullptr) {
13.        ERROR_LOG("can't create data buffer, create input failed");
14.        return FAILED;
15.    }
16.    // 向input_中添加inputData
17.    // 即将描述模型第一路输入的数据信息添加到input_中
18.    aclError ret = aclmdlAddDatasetBuffer(input_, inputData);
19.    if (inputData == nullptr) {
20.        ERROR_LOG("can't add data buffer, create input failed");
21.        aclDestroyDataBuffer(inputData);
22.        inputData = nullptr;
23.        return FAILED;
24.    }
25.    // 同理：接下来将描述模型第二路输入的数据信息添加到input_中
26.    aclDataBuffer* inputData2 = aclCreateDataBuffer(input2, input2size);
27.    if (inputData == nullptr) {
28.        ERROR_LOG("can't create data buffer, create input failed");
29.        return FAILED;
30.    }
31.
32.    ret = aclmdlAddDatasetBuffer(input_, inputData2);
33.    if (inputData == nullptr) {
34.        ERROR_LOG("can't add data buffer, create input failed");
35.        aclDestroyDataBuffer(inputData2);
36.        inputData = nullptr;
37.        return FAILED;
38.    }
39.
40.    return SUCCESS;
41.}
```
### 步骤 5 模型推理

根据已经加载到内存中，要进行推理的模型ID、构建好的模型推理输入数据，调用ACL库中模型推理接口进行模型推理。
模型推理功能函数封装在了ModelProcess::Execute()中，对应的文件为src/model_process.cpp

 **函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::Execute() {
2.    aclError ret = aclmdlExecute(modelId_, input_, output_);
3.    if (ret != ACL_ERROR_NONE) {
4.        ERROR_LOG("execute model failed, modelId is %u", modelId_);
5.        return FAILED;
6.    }
7.
8.    INFO_LOG("model execute success");
9.    return SUCCESS;
10.}
```

ACL库中模型推理接口：aclmdlExecute 说明：
函数功能：执行模型推理，直到返回推理结果，同步接口。
 **函数原型：** 
`1.aclError aclmdlExecute(uint32_t modelId, const aclmdlDataset *input, aclmdlDataset *output)`
对应的文件为src/model_process.cpp
参数说明 —— 	
modelId [in]:   指定需要执行推理的模型的ID
input [in] :       模型推理的输入数据
output [out] :  模型推理的输出数据


### 步骤 6 分析样例模型推理的输出格式并解析模型推理结果

我们将模型输出数据，格式化输出看下到底是什么。
本实验将模型推理的结果解析后，通过在本机部署的Presenter Server进程将检测结果可视化，利用Presenter Agent提供的API向Presenter Server推送媒体消息，Presenter Server接收Presenter Agent发过来的媒体数据，通过浏览器进行结果展示。
 **Presenter Agent 的使用方法基本如下：** 

- 首先创建并打开一个连接Presenter Server的通道。
- 发送一个包含一帧图像信息的结构体对象到Presenter Server。

 **1）打开通道的函数原型为：** 
`1.PresenterErrorCode OpenChannelByConfig(channel_, "./param.conf");`
对应的文件为src/painting_process.cpp
参数说明 —— 

- channel [out] ：指向Channel的指针
- "./param.conf": 通道参数配置文件，包含：IP、端口、通道名称、数据类型

 **PresenterServerParams的定义如下：** 
对应的文件为inc/presenter_channels.h

```
1.struct PresenterServerParams {
2.  // ip of Presenter Server
3.  std::string host_ip;
4.  // port of Presenter Server
5.  std::uint16_t port;
6.  // name of registered app
7.  std::string app_id;
8.  // type of registered app
9.  std::string app_type;
10.};
```

 **ChannelContentType 媒体类型定义如下：** 
对应的文件为presenterserver/common/presenter_socket_server.py

```
1.enum ChannelContentType {
2.    kChannelContentTypeImage = 0;
3.    kChannelContentTypeVideo = 1;
4.}
```

 **2）发送一帧图像信息到Presenter Server的函数原型为：** 
`1.PresenterErrorCode PresentImage(Channel *channel, const ImageFrame &image);`
对应文件为src/painting_process.cpp
参数说明 —— 

- channel [in] ：指向Channel的指针
- param [in] : 包含图片信息的结构体对象

 **图像信息结构体ImageFrame的定义如下所示：** 

```
1.struct ImageFrame {
2.  ImageFormat format;
3.  std::uint32_t width;
4.  std::uint32_t height;
5.  std::uint32_t size;
6.  unsignedchar *data;
7.  std::vector<DetectionResult> detection_results;
8.};  
```

 **在本工程中打开通道的源码为：** 
对应文件为src/painting_process.cpp

```
1.Result PaintingProcess::OpenPresenterChannel() {
2.    INFO_LOG("OpenChannel start");
3.    // 加载Presenter Server的相关参数的配置文件
4.    PresenterErrorCode errorCode = OpenChannelByConfig(channel_, "./param.conf");
5.    INFO_LOG("OpenChannel param");
6.    if (errorCode != PresenterErrorCode::kNone) {
7.        ERROR_LOG("OpenChannel failed %d", static_cast<int>(errorCode));
8.    }
9.    return SUCCESS;
10.}
```

 **在本工程文件中模型的推理结果解析函数原型为：** 
对应文件为src/painting_process.cpp
`1.Result PaintingProcess::Postprocess(aclmdlDataset* modelOutput)`
我们由原始pb模型得知，AI_painting模型的推理结果有两路输出，一路是生成的中间布局图像，一路是最终生成的图像。由此，我们后处理主要是将两路图像从RGB格式转换为BGR格式图像，并将最终生成的图像反归一化到0~255。
 **函数定义及相关源码注释如下所示：** 

```
1.Result PaintingProcess::Postprocess(aclmdlDataset* modelOutput){
2.    // 获取模型输出的个数
3.    for (size_t index = 0; index < aclmdlGetDatasetNumBuffers(modelOutput); ++index) {
4.        // 获取模型输出中的第index个aclDataBuffer
5.        aclDataBuffer* dataBuffer = aclmdlGetDatasetBuffer(modelOutput, index);
6.        void* data = aclGetDataBufferAddr(dataBuffer);
7.        uint32_t len = aclGetDataBufferSize(dataBuffer);
8.
9.        void *outHostData = NULL;
10.        aclError ret = ACL_ERROR_NONE;
11.        float *outData = NULL;
12.        // 区分产品形态，判断是否需要拷贝数据到host侧
13.        if (!g_isDevice) {
14.            aclError ret = aclrtMallocHost(&outHostData, len);
15.            if (ret != ACL_ERROR_NONE) {
16.                ERROR_LOG("aclrtMallocHost failed, ret[%d]", ret);
17.                return FAILED;
18.            }
19.
20.            ret = aclrtMemcpy(outHostData, len, data, len, ACL_MEMCPY_DEVICE_TO_HOST);
21.            if (ret != ACL_ERROR_NONE) {
22.                ERROR_LOG("aclrtMemcpy failed, ret[%d]", ret);
23.                return FAILED;
24.            }
25.
26.            outData = reinterpret_cast<float*>(outHostData);
27.        } else {
28.            outData = reinterpret_cast<float*>(data);
29.        }
30.        // 对于第一路输出，将图像从RGB转为BGR格式
31.        if(layoutMap == index){
32.            uint32_t size = static_cast<uint32_t>(len) / sizeof(float);
33.            INFO_LOG("The size of layoutMap: %d", size);
34.            cv::Mat layoutMap(256, 256, CV_32FC3, const_cast<float_t*>((float_t*)outData));
35.            cv::cvtColor(layoutMap, layoutMap, CV_RGB2BGR);
36.            // 发送中间布局图像到Presenter Server
37.            SendImage(layoutMap);
38.            INFO_LOG("Sending layoutMap...");
39.        }
40.        // 对于第一路输出，将图像从RGB转为BGR格式，并反归一化到0~255
41.        if(resultImg == index){
42.            uint32_t size = static_cast<uint32_t>(len) / sizeof(float);
43.            INFO_LOG("The size of resultImg: %d", size);
44.            cv::Mat resultImg(448, 448, CV_32FC3, const_cast<float*>((float*)outData));
45.            cv::cvtColor(resultImg, resultImg, CV_RGB2BGR);
46.            resultImg = (resultImg * 0.5 + 0.5) * 255;
47.            // 发送最终图像到Presenter Server
48.            SendImage(resultImg);
49.            INFO_LOG("Sending resultImg...");
50.        }
51.
52.        if (!g_isDevice) {
53.            ret = aclrtFreeHost(outHostData);
54.            if (ret != ACL_ERROR_NONE) {
55.                ERROR_LOG("aclrtFreeHost failed, ret[%d]", ret);
56.                return FAILED;
57.            }
58.        }
59.    }
60.
61.    INFO_LOG("output data success");
62.    INFO_LOG("---------------------------------");
63.    return SUCCESS;
64.}
```
### 步骤 7 资源释放

程序结束后要卸载模型，并释放与模型推理相关的资源、运行管理资源释放等，此功能函数封装在void PaintingProcess::DestroyResource()，对应文件为src/painting_process.cpp
 **函数定义及相关源码注释如下所示：** 

```
1.void PaintingProcess::DestroyResource()
2.{   
3.    // 释放Device上的模型输入信息的内存
4.    aclrtFree(layoutDataBuffer_);
5.    aclrtFree(objectInfoBuffer_);
6.    layoutDataBuffer_ = nullptr;
7.    objectInfoBuffer_ = nullptr;
8.    // 销毁 channel_
9.    delete channel_;
10.    // 释放模型输入输出描述信息等相关资源
11.    model_.DestroyResource();
12.
13.    aclError ret;
14.    // 销毁Stream
15.    if (stream_ != nullptr) {
16.        ret = aclrtDestroyStream(stream_);
17.        if (ret != ACL_ERROR_NONE) {
18.            ERROR_LOG("destroy stream failed");
19.        }
20.        stream_ = nullptr;
21.    }
22.    INFO_LOG("end to destroy stream");
23.    // 销毁 context
24.    if (context_ != nullptr) {
25.        ret = aclrtDestroyContext(context_);
26.        if (ret != ACL_ERROR_NONE) {
27.            ERROR_LOG("destroy context failed");
28.        }
29.        context_ = nullptr;
30.    }
31.    INFO_LOG("end to destroy context");
32.    // 复位当前运算的Device，释放Device上的资源
33.    ret = aclrtResetDevice(deviceId_);
34.    if (ret != ACL_ERROR_NONE) {
35.        ERROR_LOG("reset device failed");
36.    }
37.    INFO_LOG("end to reset device is %d", deviceId_);
38.    // 应用的进程退出前，显式调用该接口实现AscendCL去初始化
39.    ret = aclFinalize();
40.    if (ret != ACL_ERROR_NONE) {
41.        ERROR_LOG("finalize acl failed");
42.    }
43.    INFO_LOG("end to finalize acl");
44.}
```

模型的相关资源卸载函数封装在void ModelProcess::DestroyResource()中，
对应文件为src/model_process.cpp
 **函数定义及相关源码注释如下所示：** 

```
1. void ModelProcess::DestroyResource() {
2.    if (isReleased_)
3.        return;
4.    // 系统完成模型推理后，可调用该接口传入模型ID卸载模型
5.    Unload();
6.     // 销毁模型描述信息(aclmdlDesc类型的数据)
7.    DestroyDesc();
8.    // 释放模型的输入输出数据描述
9.    DestroyInput();
10.   DestroyOutput();
11.   // 判断资源是否释放的标识位
12.   isReleased_ = true;
13.}

```





