<!-- GFM-TOC -->

* [1 实验介绍](#1-实验介绍)
* [2 实验原理](#2-实验原理)
* [3 实验环境](#3-实验环境)
* [4 快速体验](#4-快速体验)
* [5 图像分类原理](#5-图像分类原理)
* [6 开发步骤和关键代码分析](#6-开发步骤和关键代码分析)
  <!-- GFM-TOC -->

# 1 实验介绍

本实验是基于Atlas 200DK的图像分类项目，基于googlenet分类网络编写的示例代码，该示例代码部署在Atlas 200DK上 ，通过读取本地图像数据作为输入，对图像中的物体进行识别分类，并将分类的结果展示出来。
# 2 实验原理

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/172418_bb44048b_7380811.png "屏幕截图.png")


 **1)运行管理资源申请：** 用于初始化系统内部资源，固定的调用流程。

 **2)加载模型文件并构建输出内存：** 从文件加载离线模型数据，需要由用户自行管理模型运行的内存，根据内存中加载的模型获取模型的基本信息包含模型输入、输出数据的数据
buffer大小；由模型的基本信息构建模型输出内存，为接下来的模型推理做好准备。

 **3)获取本地图像并进行预处理：** 从本地存放有图像数据的目录中使用opencv循环读取图像数据，将图像数据缩放至模型要求的宽高比例；然后构建模型的输入数据。

 **4)模型推理：** 根据构建好的模型输入数据进行模型推理。

 **5)解析推理结果：** 根据模型输出，解析图片分类的结果，获取当前图像中识别出的物体类别以及对应的置信度，将分类结果通过opencv标注在图片上进行展示。

# 3 实验环境

实验前需要制作SD卡并在连接Atlas 200DK的Ubuntu服务器上准备好软件环境，请参考文档：《环境搭建指导_Atlas 200DK场景（C75）.docx》
# 4 快速体验

### 步骤 1在Ubuntu18.04服务器上获取图片分类源码包

1)切换至普通用户（如ascend），执行如下命令：
`su - ascend`

2)执行如下命令在ascend用户下创建工程存放目录，并进入该目录：

```
mkdir -p $HOME/AscendProjects
cd $HOME/AscendProjects
```

3)执行如下命令获取图片分类工程：
`wget https://obs-book.obs.cn-east-2.myhuaweicloud.com/liuyuan/20.1samples/classification.zip `
如果使用wget下载失败，可使用如下命令下载代码。
`curl -OL https://obs-book.obs.cn-east-2.myhuaweicloud.com/liuyuan/20.1samples/classification.zip`
如果curl也下载失败，可复制下载链接到浏览器，手动上传至服务器。

4)解压工程文件压缩包：
`unzip classification.zip`
工程文件目录如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/172610_ca017c2d_7380811.png "屏幕截图.png")
工程目录说明如下表所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/172730_21d7309b_7380811.png "图片5.png")

### 步骤 2模型转换

我们选择caffe的googlenet模型，需要将其转换为昇腾AI处理器支持的Davinci模型文件，这里我们选择使用命令行方式对模型进行转换。

1)切换到ubuntu服务器的任意目录

```
mkdir -p $HOME/models/googlenet
cd $HOME/models/googlenet
```

2)下载原始网络模型和权重文件

```
wget https://obs-model-ascend.obs.cn-east-2.myhuaweicloud.com/googlenet/googlenet.caffemodel --no-check-certificate
wget https://obs-model-ascend.obs.cn-east-2.myhuaweicloud.com/googlenet/googlenet.prototxt --no-check-certificate
```

如下图所示，模型下载完毕：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/172841_c9f58b6c_7380811.png "屏幕截图.png")
3)将原始网络模型转换为昇腾AI处理器支持的Davinci模型
使用如下命令打开Mind Studio工具：

```
cd ~/MindStudio-ubuntu/bin
./MindStudio.sh &
```

在Mind Studio操作界面的顶部菜单栏中选择Ascend > Model Converter，进入模型转换界面，在弹出的Model Conversion操作界面中进行模型转换配置，参照以下图片进行参数配置：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/172855_2a935b41_7380811.png "屏幕截图.png")


- Model File选择步骤2）中下载的模型文件，此时会自动匹配到权重文件并填写在Weight File中；
- Type修改为Uint8

点击Next继续配置，如下图：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/172912_9dd6ccbc_7380811.png "屏幕截图.png")
Input Image Format选择BGR 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/172940_061f7159_7380811.png "屏幕截图.png")

点击Finish执行转换，转换成功后会提示“Model converted successfully”，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/172947_b9983b8f_7380811.png "屏幕截图.png")

4)将转换好的模型拷贝至工程对应的目录下
`cp ~/modelzoo/googlenet/device/googlenet.om ~/AscendProjects/classification/model/`
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173002_b8f7c992_7380811.png "屏幕截图.png")

### 步骤 3在Mind Studio中打开工程文件

使用安装Mind Studio的用户（如ascend），进入“MindStudio-ubuntu/bin”目录，如：$HOME/MindStudio-ubuntu/bin。执行如下命令启动Mind Studio：
`./MindStudio.sh &`
启动成功后，打开classification工程如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173021_c5d52035_7380811.png "屏幕截图.png")

### 步骤 4编译工程文件

1)在Mind Studio的工具栏中依次点击Build > Edit Build Configuration，“Target OS” 选择为“Linux” ，然后“Build”。如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173244_1784c5c3_7380811.png "屏幕截图.png")

2)Build之后如下图所示，会在目录下生成build和out文件夹：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173249_7d10d9f0_7380811.png "屏幕截图.png")

### 步骤 5运行工程

1)运行工程文件之前，需要登录开发板重启ada进程，操作步骤如下：
从Ubuntu服务器登录至开发板（假设开发板地址192.168.1.2）：
`ssh HwHiAiUser@192.168.1.2		—— 默认登录密码：Mind@123`
查看ada进程号并杀死该进程：

```
ps –ef | grep ada
kill <进程号> 			—— 该进程号为上一步查询到的进程号
```

操作命令参考如下图：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173544_6b90bf4e_7380811.png "屏幕截图.png")
在开发板侧进入 /var 目录下，开启ada服务：

```
cd /var
./ada &
```

操作命令参考如下图：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173554_bcbb2621_7380811.png "屏幕截图.png")

2)在Mind Studio的工具栏找到Run按钮，单击 Run > Edit Configurations，在Target Host Ip中添加开发板ip，用于连接开发板，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173603_64306b1d_7380811.png "屏幕截图.png")
单击右侧“+”按钮后弹出Device Manager 界面，如下图所示操作，添加开发板：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173607_b04b6c7a_7380811.png "屏幕截图.png")
设备添加成功，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173610_a08e7ddf_7380811.png "屏幕截图.png")
在Command Arguments 中添加运行参数“../data”，之后分别点击Apply、OK。如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173613_a33f0c93_7380811.png "屏幕截图.png")
3)单击 Run > Run 'classification'，可执行程序在开发板执行，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173617_b8d6424e_7380811.png "屏幕截图.png")
4)在Mind Studio中查看推理结果，结果保存在工程目录 out/outputs 目录下，如图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173619_c70c5e7f_7380811.png "屏幕截图.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173623_1fc310e7_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173626_47c80e78_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/173629_a0d1bef9_7380811.png "屏幕截图.png")


# 5 图像分类原理

图片分类代码流程图如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0114/183252_00f008ea_7380811.png "屏幕截图.png")
详细开发步骤及代码逻辑分析参见下述说明。

# 6 开发步骤和关键代码分析

将模型部署到Atlas 200DK的步骤一般是这样的：

- 首先，模型转换，得到在昇腾AI处理器上能够跑起来的离线模型，经过上面的实验准备环节，已经得到了om模型。
- 然后，基于ACL接口进行应用开发。

代码的开发过程大致分为以下步骤：

 1)运行管理资源申请；
 2)加载模型文件，构建模型输出内存；
 3)数据获取，获取要进行推理的原始图像；
 4)数据预处理，模型的输入图像进行预处理；
 5)模型推理，将数据输入到模型进行推理；
 6)解析模型推理结果，将推理结果标注在图像上。

### 步骤 1运行管理资源申请

运行管理资源申请的功能封装在了函数ClassifyProcess::InitResource()中。
 **函数源码如下所示，ACL相关功能接口的调用已在函数中进行了说明：** 

```
1.Result ClassifyProcess::InitResource()
2.{   
3.    // 配置文件相对路径
4.    const char *aclConfigPath = "../src/acl.json";
5.    // ACL初始化接口
6.    aclError ret = aclInit(aclConfigPath);
7.    if (ret != ACL_ERROR_NONE) {
8.        ERROR_LOG("acl init failed");
9.        return FAILED;
10.    }
11.    INFO_LOG("acl init success");
12.
13.    // 指定运算的设备ID
14.    ret = aclrtSetDevice(deviceId_);
15.    if (ret != ACL_ERROR_NONE) {
16.        ERROR_LOG("acl open device %d failed", deviceId_);
17.        return FAILED;
18.    }
19.    INFO_LOG("open device %d success", deviceId_);
20.
21.
22.    return SUCCESS;
23.}
```

### 步骤 2加载模型文件，构建模型输出内存

1)加载本地om模型文件到内存中，对应的功能函数原型为：
`1.Result ModelProcess:: LoadModelFromFileWithMem(const char *modelPath)`
参数说明 —— modelPath：描述本地模型文件的存放路径

 **函数定义及相关源码注释如下所示：** 

```
1.// 加载本地模型文件
2.Result ModelProcess:: LoadModelFromFileWithMem(const char *modelPath)
3.{
4.    // 标志位，判断当前是否已经加载了模型文件
5.    if (loadFlag_) {
6.        ERROR_LOG("has already loaded a model");
7.        return FAILED;
8.    }
9.
10.    aclError ret = aclmdlQuerySize(modelPath, &modelMemSize_, &modelWeightSize_);
11.    if (ret != ACL_ERROR_NONE) {
12.        ERROR_LOG("query model failed, model file is %s", modelPath);
13.        return FAILED;
14.    }
15.    
16.    
17.    ret = aclrtMalloc(&modelMemPtr_, modelMemSize_, ACL_MEM_MALLOC_HUGE_FIRST);
18.    if (ret != ACL_ERROR_NONE) {
19.        ERROR_LOG("malloc buffer for mem failed, require size is %zu", modelMemSize_);
20.        return FAILED;
21.    }
22.
23.    ret = aclrtMalloc(&modelWeightPtr_, modelWeightSize_, ACL_MEM_MALLOC_HUGE_FIRST);
24.    if (ret != ACL_ERROR_NONE) {
25.        ERROR_LOG("malloc buffer for weight failed, require size is %zu", modelWeightSize_);
26.        return FAILED;
27.    }
28.
29.
30.    // 从文件加载离线模型数据，通过modelId_获取：系统完成模型加载后生成的模型ID
31.    aclError ret = aclmdlLoadFromFileWithMem(modelPath, &modelId_，modelMemPtr_,
32.        modelMemSize_, modelWeightPtr_, modelWeightSize_);
33.    if (ret != ACL_ERROR_NONE) {
34.        ERROR_LOG("load model from file failed, model file is %s", modelPath);
35.        return FAILED;
36.    }
37.
38.    // 设置模型加载成功的标志位
39.    loadFlag_ = true;
40.    INFO_LOG("load model %s success", modelPath);
41.    return SUCCESS;
42.}
```

2)根据加载的模型ID，获取模型的描述信息，对应的功能函数原型为：
`1.Result ModelProcess::CreateDesc()`
 **函数定义及相关源码注释如下所示：** 

```
1.// 根据加载成功的模型的ID，获取该模型的描述信息
2.Result ModelProcess::CreateDesc()
3.{
4.    // 为模型描述信息创建空间，返回模型信息描述对象指针
5.    modelDesc_ = aclmdlCreateDesc();
6.    if (modelDesc_ == nullptr) {
7.        ERROR_LOG("create model description failed");
8.        return FAILED;
9.    }
10.
11.    // 根据加载的模型ID获取该模型的描述信息，记录在modelDesc_中。
12.    aclError ret = aclmdlGetDesc(modelDesc_, modelId_);
13.    if (ret != ACL_ERROR_NONE) {
14.        ERROR_LOG("get model description failed");
15.        return FAILED;
16.    }
17.    INFO_LOG("create model description success");
18.    return SUCCESS;
19.}
```

3)根据模型的描述信息，获取模型的输出个数，以及每路输出在设备上所需的空间大小
 **对应的功能函数原型为：** 
`1.Result ModelProcess::CreateOutput()`
ACL库内置数据类型说明：aclmdlDataset主要用于描述模型推理时的输入数据或输出数据，模型可能存在多个输入、多个输出，每个输入或输出的内存地址、内存大小用aclDataBuffer类型的数据来描述。
 **CreateOutput函数定义及相关源码注释如下所示：** 

```
1.// 为模型的输出在设备上申请好空间
2.Result ModelProcess::CreateOutput()
3.{
4.    // 当模型描述信息为空时返回
5.    if (modelDesc_ == nullptr) {
6.        ERROR_LOG("no model description, create ouput failed");
7.        return FAILED;
8.    }
9.
10.    // 获取aclmdlDataset类型的数据
11.    output_ = aclmdlCreateDataset();
12.    if (output_ == nullptr) {
13.        ERROR_LOG("can't create dataset, create output failed");
14.        return FAILED;
15.    }
16.
17.    // 根据模型描述信息，获取模型的输出有几路数据
18.    size_t outputSize = aclmdlGetNumOutputs(modelDesc_);
19.    for (size_t i = 0; i < outputSize; ++i) {
20.        // 根据模型描述信息以及输出数据的下标(即为第几路输出数据)，获取指定输出的大小
21.        // 输出大小作为返回值记录在buffer_size中
22.        size_t buffer_size = aclmdlGetOutputSizeByIndex(modelDesc_, i);
23.        void *outputBuffer = nullptr;
24.        // 使用ACL接口aclrtMalloc在设备上申请大小为buffer_size的空间,地址记录在outputBuffer中
25.        aclError ret = aclrtMalloc(&outputBuffer, buffer_size, ACL_MEM_MALLOC_NORMAL_ONLY);
26.        if (ret != ACL_ERROR_NONE) {
27.            ERROR_LOG("can't malloc buffer, size is %zu, create output failed", buffer_size);
28.            return FAILED;
29.        }
30.
31.        // 创建aclDataBuffer类型的数据用于描述在设备上申请的内存空间地址以及相应的大小
32.        aclDataBuffer* outputData = aclCreateDataBuffer(outputBuffer, buffer_size);
33.        if (aclDataBuffer == nullptr) {
34.            ERROR_LOG("can't create data buffer, create output failed");
35.            // aclDataBuffer类型数据创建失败，则释放在设备上申请的空间
36.            aclrtFree(outputBuffer);
37.            return FAILED;
38.        }
39.
40.      
41.        // 向output_中添加outputData
42.        ret = aclmdlAddDatasetBuffer(output_, outputData);
43.        if (ret != ACL_ERROR_NONE) {
44.            ERROR_LOG("can't add data buffer, create output failed");
45.            // 向aclmdlDataset的地址中添加失败时，释放在设备上申请的空间
46.            aclrtFree(outputBuffer);
47.            // 释放aclDataBuffer类型数据空间
48.            aclDestroyDataBuffer(outputData);
49.            return FAILED;
50.        }
51.    }
52.
53.    INFO_LOG("create model output success");
54.    return SUCCESS;
55.}
```

### 步骤 3读取本地图像数据并进行预处理

使用opencv读取本地图像数据，将图像数据进行大小缩放，缩放至模型要求输入图像的宽高，本例中模型要求的输入图像宽高为224和224；将读取到的图像数据拷贝至设备侧申请的内存空间中，为接下来构建模型输入数据做好准备。
 **上述功能函数原型为：** 
`1.Result ClassifyProcess::Preprocess(const string &imageFile)`
参数说明 ——
imageFile [in] : 本地图像数据的路径
`Preprocess函数定义及相关源码注释如下所示：`

```
1.Result ClassifyProcess::Preprocess(const string& imageFile) {
2.    // read image using OPENCV
3.    INFO_LOG("Read image %s", imageFile.c_str());
4.    cv::Mat origMat = cv::imread(imageFile, CV_LOAD_IMAGE_COLOR);
5.    if (origMat.empty()) {
6.        ERROR_LOG("Read image failed");
7.        return FAILED;
8.    }
9.
10.    INFO_LOG("Resize image %s", imageFile.c_str());
11.    //resize
12.    cv::Mat reiszeMat;
13.    cv::resize(origMat, reiszeMat, cv::Size(modelWidth_, modelHeight_));
14.    if (reiszeMat.empty()) {
15.        ERROR_LOG("Resize image failed");
16.        return FAILED;
17.    }
18.    
19.    if (runMode_ == ACL_HOST) {     
20.        //AI1上运行时,需要将图片数据拷贝到device侧   
21.        aclError ret = aclrtMemcpy(inputBuf_, inputDataSize_, 
22.                                   reiszeMat.ptr<uint8_t>(), inputDataSize_,
23.                                   ACL_MEMCPY_HOST_TO_DEVICE);
24.        if (ret != ACL_ERROR_NONE) {
25.            ERROR_LOG("Copy resized image data to device failed.");
26.            return FAILED;
27.        }
28.    } else {
29.        //Atals200DK上运行时,数据拷贝到本地即可.
30.        //reiszeMat是局部变量,数据无法传出函数,需要拷贝一份
31.        memcpy(inputBuf_, reiszeMat.ptr<void>(), inputDataSize_);
32.    }
33.
34.    return SUCCESS;
35.}
```

### 步骤 4构建模型输入数据，进行模型推理

构建模型的输入数据，本样例中的googlenet模型有一路输入，第一路输入是描述设备侧包含有图像数据的内存空间。 
 **构建模型输入数据的功能函数是：** 
`1.Result ModelProcess::CreateInput(void *inputDataBuffer, size_t bufferSize)`
参数说明 —— 
inputDataBuffer [in]: 设备侧包含图像数据的内存空间地址
bufferSize [in] : 描述设备侧包含图像数据的内存空间所占字节大小

 **CreateInput函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::CreateInput(void *inputDataBuffer, size_t bufferSize)
2.{
3.    // 创建aclmdlDataset类型的数据
4.    // 用于描述模型每个输入数据的内存地址和内存大小
5.    input_ = aclmdlCreateDataset();
6.    if (input_ == nullptr) {
7.        ERROR_LOG("can't create dataset, create input failed");
8.        return FAILED;
9.    }
10.
11.    // 创建aclDataBuffer类型的数据用于描述在设备上申请的内存空间地址以及相应的大小
12.    aclDataBuffer* inputData = aclCreateDataBuffer(inputDataBuffer, bufferSize);
13.    if (inputData == nullptr) {
14.        ERROR_LOG("can't create data buffer, create input failed");
15.        return FAILED;
16.    }
17.
18.    // 向input_中添加outputData
19.    // 即将描述模型第一路输入的数据信息添加到input_中
20.    aclError ret = aclmdlAddDatasetBuffer(input_, inputData);
21.    if (ret != ACL_ERROR_NONE) {
22.        ERROR_LOG("can't add data buffer, create input failed");
23.        // 添加失败时释放aclDataBuffer类型数据
24.        aclDestroyDataBuffer(inputData);
25.        inputData = nullptr;
26.        return FAILED;
27.    }
28.
29.    return SUCCESS;
30.}
```

根据已经加载到内存中，要进行推理的模型ID、构建好的模型推理输入数据，调用ACL库中模型推理接口进行模型推理。
 **相应的功能函数原型为：** 
`1.Result ModelProcess::Execute()`
 **Execute函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::Execute()
2.{
3.    // 执行模型推理，直到返回推理结果
4.    aclError ret = aclmdlExecute(modelId_, input_, output_);
5.    if (ret != ACL_ERROR_NONE) {
6.        ERROR_LOG("execute model failed, modelId is %u", modelId_);
7.        return FAILED;
8.    }
9.    INFO_LOG("model execute success");
10.    return SUCCESS;
11.}
```

ACL库中模型推理接口：aclmdlExecute 说明：
函数功能：执行模型推理，直到返回推理结果，同步接口。

 **函数原型：** 
`1.aclError aclmdlExecute(uint32_t modelId, const aclmdlDataset *input, aclmdlDataset *output)`
参数说明 ——
modelId [in]:   指定需要执行推理的模型的ID
input [in] :       模型推理的输入数据
output [out] :  模型推理的输出数据
### 步骤 5分析样例模型推理的输出格式并解析模型推理结果

 **模型的推理结果解析函数原型为：** 
`1.Result ClassifyProcess:: Postprocess(const string & origImageFile, aclmdlDataset * modelOutput)`
模型的输出为1000个float型数据，1000个float型数据代表1000中物体类别，每个float型数据为归一化数据范围0 ~ 1。代表该类物体识别的置信度，选取其中置信度最高的类别，作为图像的分类结果。

 **Postprocess函数定义及相关源码注释如下所示：** 

```
1.Result ClassifyProcess::Postprocess(const string& origImageFile, 
2.                                    aclmdlDataset* modelOutput){
3.    uint32_t dataSize = 0;
4.	
12.	    // 获取模型的第一路输出结果
5.    void* data = GetInferenceOutputItem(dataSize, modelOutput);
6.    if (data == nullptr) return FAILED;
7.
8.    float* outData = NULL;
9.    outData = reinterpret_cast<float*>(data);
10.
13.	    // 对float型数据进行从大到小排序
11.    map<float, unsigned int, greater<float> > resultMap;
12.    for (uint32_t j = 0; j < dataSize / sizeof(float); ++j) {
13.        resultMap[*outData] = j;
14.        outData++;
15.    }
16.
17.    int cnt = 0;
18.    auto it = resultMap.begin();
19.    int maxScoreCls = it->second;
20.
14.		   // 将相似度前5的推理结果记录到日志中
21.    for (auto it = resultMap.begin(); it != resultMap.end(); ++it) {
22.        // print top 5
23.        if (++cnt > kTopNConfidenceLevels) {
24.            break;
25.        }
26.        INFO_LOG("top %d: index[%d] value[%lf]", cnt, it->second, it->first);
27.    }
28.	
15.	   // 将识别到的相似度最高的物体类别通过opencv写入到本地图片中
29.    LabelClassToImage(maxScoreCls, origImageFile);
30.    if (runMode_ == ACL_HOST) {
31.        aclrtFree(data);
32.        data = nullptr;
33.    }
34.
35.    return SUCCESS;
36.}
```

### 步骤 6资源释放

 **资源释放分别在以下函数中实现：** 

```
1.void ClassifyProcess::DestroyResource(); 
2.void ModelProcess::Unload();
3.void ModelProcess::DestroyDesc();
4.void ModelProcess::DestroyInput();
5.void ModelProcess::DestroyOutput();
```
