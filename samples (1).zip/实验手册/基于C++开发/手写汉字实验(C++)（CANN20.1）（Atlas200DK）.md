<!-- GFM-TOC -->

* [1 实验介绍](#1-实验介绍)
* [2 实验原理](#2-实验原理)
* [3 实验环境](#3-实验环境)
* [4 快速体验](#4-快速体验)
* [5 手写汉字识别原理](#5-手写汉字识别原理)
* [6 开发步骤和关键代码分析](#6-开发步骤和关键代码分析)
  <!-- GFM-TOC -->
# 1 实验介绍

本文档主要介绍手写汉字代码开发并部署在Atlas 200 DK开发板上执行的方法。通过Atlas 200 DK开发板来实现手写汉字识别推理实验，使用Atlas 200 DK外接的摄像头获取的视频数据作为输入，实时检测视频画面中的汉字，并将检测后的结果展示出来。用户可以通过手写汉字拍照识别项目对Atlas 200 DK开发板在AI方面的应用有全面的认识。

# 2 实验原理

![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/112631_044c75ad_7380811.png "屏幕截图.png")

 **1)运行管理资源申请：** 用于初始化系统内部资源，固定的调用流程。

 **2)加载模型文件并构建输出内存：** 从文件加载离线模型数据，根据内存中加载的模型获取模型的基本信息包含模型输入、输出数据的数据buffer大小；由模型的基本信息构建模型输出内存，为接下来的模型推理做好准备。

 **3)从摄像头读取图片并进行预处理：** 根据camera channel id打开摄像头，循环读取每一帧图像数据，首先进行文字检测然后将文字区域图像数据进行预处理，将其缩放至模型要求的宽高比例。

 **4)模型推理：** 根据构建好的模型输入数据，调用模型推理接口进行模型推理。推理模块接收预处理之后的数据，依次对每个汉字子图像通过模型进行推理，得到输出向量的结果集合；另一方面还需将每帧图像转换JPG格式，以便于查看摄像头图像。将JPG格式的每帧图像集合和每帧识别结果集合作为输入传给后处理模块模块。

 **5)解析推理结果：** 后处理模块接收推理结果与摄像头JPG图像，将矩形框集合添加到Presenter Server记录检测目标位置信息的数据结构DetectionResult中，作为摄像头图像的检测结果，通过调用Presenter Agent的API发送到UI Host上部署的Presenter Server服务进程。Presenter Server根据接收到的推理结果，求出汉字最大预测概率值所对应的索引，在索引表中查找对应汉字，在JPG图像上进行汉字矩形框位置及汉字识别结果的标记，并将图像信息发送给Web UI。

# 3 实验环境

实验前需要制作SD卡并在连接Atlas 200DK的Ubuntu服务器上准备好软件环境，请参考https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0003.html
# 4 快速体验
### 步骤 1 在环境搭建好的Ubuntu18.04环境上获取手写汉字实验源码包

1)切换至普通用户（如ascend），并行如下命令：
`su ascend`
2)执行如下命令在ascend用户下创建工程存放目录，并进入该目录：

```
mkdir -p $HOME/AscendProjects
cd $HOME/AscendProjects
```

3)执行如下命令获取手写汉字识别工程：
`wget https://obs-book.obs.cn-east-2.myhuaweicloud.com/liuyuan/20.1samples/HandWrite.zip`
如果服务器上没有wget命令，使用以下命令进行安装：
`sudo apt-get install wget`
如果使用wget下载失败，可使用如下命令下载代码。
`curl -OL  https://obs-book.obs.cn-east-2.myhuaweicloud.com/liuyuan/20.1samples/HandWrite.zip`
如果服务器上没有curl命令，使用以下命令进行安装：
`sudo apt-get install curl`
如果curl也下载失败，可复制下载链接到浏览器，手动上传至服务器。
4)解压工程文件压缩包：
`unzip HandWrite.zip`
如果服务器上没有unzip命令，使用以下命令进行安装：
`sudo apt-get install unzip`
工程目录如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/113057_fcedf3b0_7380811.png "屏幕截图.png")

工程文件说明如下表所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/113202_97c8afe7_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/113209_f6dee373_7380811.png "屏幕截图.png")
### 步骤 2 模型转换（命令行方式）

我们选择caffe的resnet模型，需要将其转换为昇腾AI处理器支持的Davinci模型文件，这里我们选择使用命令行方式对模型进行转换。
1)获取此应用中所需要的原始网络模型，下载原始网络模型和权重文件至ubuntu服务器任意目录，如:$HOME/models/HandWrite

```
mkdir -p $HOME/models/HandWrite
cd  $HOME/models/HandWrite
wget  -P  $HOME/models/HandWrite https://modelzoo-train-atc.obs.cn-north-4.myhuaweicloud.com/003_Atc_Models/AE/ATC%20Model/handwrite/resnet.caffemodel
wget  -P  $HOME/models/HandWrite https://modelzoo-train-atc.obs.cn-north-4.myhuaweicloud.com/003_Atc_Models/AE/ATC%20Model/handwrite/resnet.prototxt
wget https://modelzoo-train-atc.obs.cn-north-4.myhuaweicloud.com/003_Atc_Models/AE/ATC%20Model/handwrite/insert_op.cfg
```

如下图所示，模型下载完毕：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/113406_cf233dea_7380811.png "屏幕截图.png")
2)将原始网络模型转换为昇腾AI处理器支持的Davinci模型
执行如下命令，进入目录下：
`cd  $HOME/models/HandWrite`
执行如下命令设置环境变量：

```
export install_path=$HOME/Ascend/ascend-toolkit/latest
export PATH=/usr/local/python3.7.5/bin:${install_path}/atc/ccec_compiler/bin:${install_path}/atc/bin:$PATH
export PYTHONPATH=${install_path}/atc/python/site-packages:${install_path}/atc/python/site-packages/auto_tune.egg/auto_tune:${install_path}/atc/python/site-packages/schedule_search.egg:$PYTHONPATH
export LD_LIBRARY_PATH=${install_path}/atc/lib64:$LD_LIBRARY_PATH
export ASCEND_OPP_PATH=${install_path}/opp
```

在普通用户下使用atc命令进行模型转换：
`atc --model=./resnet.prototxt --weight=./resnet.caffemodel --framework=0 --output=resnet --soc_version=Ascend310 --insert_op_conf=./insert_op.cfg --input_shape="data:1,3,112,112" --input_format=NCHW`
模型转换成功后，存放在当前的目录下：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/113442_e03e8259_7380811.png "屏幕截图.png")
执行如下命令，将转换成功的模型放到工程目录的model文件夹下：
`cp resnet.om $HOME/AscendProjects/HandWrite/model/`
转换成功的模型在工程目录的model文件夹下：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/113500_9a655d6f_7380811.png "屏幕截图.png")
### 步骤 3 在Mind Studio中打开工程文件

1)打开对应的工程
切换至安装Mind Studio的用户（如ascend），并进入“MindStudio-ubuntu/bin”目录，如：$HOME/MindStudio-ubuntu/bin。执行如下命令启动Mind Studio：
`./MindStudio.sh &`
启动成功后，打开HandWrite工程如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/113532_29216f4e_7380811.png "屏幕截图.png")
### 步骤 4 编译工程文件

1)修改Presenter Server的ip。
将script/param.conf中的presenter_server_ip、presenter_view_ip、presenter_agent_ip 修改为Mind Studio所在Ubuntu服务器的虚拟网卡的ip地址，比如 虚拟网卡的ip地址 为 192.168.1.223如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/113823_82a0b0c7_7380811.png "屏幕截图.png")

 **说明：虚拟网卡的ip地址请通过ifconfig命令查看，如下图所示：** 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/113840_13a56eb2_7380811.png "屏幕截图.png")

2)编译配置，在Mind Studio工具栏中依次点击Build > Edit Build Configuration，“Target OS” 选择为“Linux” ，”Target Architecture”选择为 “aarch64”, 然后“Build”。如下图所示： 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/113859_b0baf2f8_7380811.png "屏幕截图.png")

3)然后再依次点击Build > Build > Build Configuration，如下图所示，会在目录下生成build和out文件夹
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/113921_5e8aaff1_7380811.png "屏幕截图.png")
注：在用MindStudio编译时需修改CMakeLists。
Mindstudio中打开src/CMakeLists.txt文件。
将最后一行：execute_process(COMMAND ${CMAKE_COMMAND} -E copy ../../../scripts/param.conf ../../../out/param.conf)
修改为：execute_process(COMMAND ${CMAKE_COMMAND} -E copy ../../scripts/param.conf ../../out/param.conf)

4)启动Presenter Server
打开Mind Studio工具的Terminal，在应用代码存放路径下，执行如下命令在后台启动objectdetection_video应用的Presenter Server主程序。
`bash scripts/run_presenter_server.sh &`
如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/113958_fb372571_7380811.png "屏幕截图.png")
Presenter Server 启动后如下图所示，返回登录Presenter Server网站的URL
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/114002_da6d57be_7380811.png "屏幕截图.png")
### 步骤 5 运行工程

1)在Mind Studio的工具栏中找到Run按钮，单击 Run > Edit Configurations，在Target Host Ip中添加开发板ip，用于连接开发板，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/114049_e4d1ed15_7380811.png "屏幕截图.png")

单击右侧“+”按钮后弹出Device Manager 界面，如下图所示操作，添加开发板：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/114116_f3ac77aa_7380811.png "屏幕截图.png")

设备添加成功，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/114131_598946c3_7380811.png "屏幕截图.png")

之后分别点击Apply、OK。如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/114145_013ea5fc_7380811.png "屏幕截图.png")


2)单击 Run > Run 'HandWrite'，可执行程序在开发板执行，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/114344_cec57564_7380811.png "屏幕截图.png")



3)使用启动Presenter Server服务时提示的URL登录 Presenter Server 网站，查看运行结果
等待Presenter Agent传输数据给服务端，单击“Refresh“刷新，当有数据时相应的Channel 的Status变成绿色，如下图所示
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/114408_a8b05a8c_7380811.png "屏幕截图.png")

单击右侧对应的View Name链接，比如上图的“handpose”，查看结果。

# 5 手写汉字识别原理

手写汉字识别代码流程如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0201/114548_455a172d_7380811.png "445.png")
详细开发步骤及代码逻辑分析参见下述说明。


# 6 开发步骤和关键代码分析

将模型部署到Atlas 200DK的步骤一般是这样的：

- 首先，模型转换，得到在昇腾AI处理器上能够跑起来的离线模型，经过上面的实验准备环节，已经得到了om模型。
- 然后，基于ACL接口进行应用开发。

代码的开发过程大致分为以下步骤：
1)运行管理资源申请；
2)加载模型文件，构建模型输出内存；
3)数据获取，从摄像头读取图片；
4)文字检测模块，检测图片中的文字；
5)数据预处理，对裁剪出的文字图像进行预处理；
6)模型推理，将预处理之后的数据输入到模型进行推理；
7)解析模型推理结果，将推理结果通过调用Presenter Agent的API发送到主机端UI host上部署的Presenter Server服务进程，通过浏览器访问Presenter Server，实时查看摄像头检测到的汉字。
本实验项目是利用Presenter Server实现手写体汉字检测结果的显示，读者也可根据实际情况，自定义汉字检测结果的显示方式，例如直接将检测数据结果打印在终端里显示，或者将检测数据结果保存在文件中。

### 步骤 1 运行管理资源申请

运行管理资源申请的功能封装在了函数SampleProcess:：InitResource()中。
在文件object_detect.cpp中
 **函数源码如下所示，ACL相关功能接口的调用已在函数中进行了说明：** 

```
1.Result ObjectDetect::InitResource() {  
2.    // ACL init  
3.    const char *aclConfigPath = "../src/acl.json";  
4.    aclError ret = aclInit(aclConfigPath);  
5.    if (ret != ACL_ERROR_NONE) {  
6.        ERROR_LOG("acl init failed\n");  
7.        return FAILED;  
8.    }  
9.    INFO_LOG("acl init success\n");  
10.  
11.    // open device  
12.    ret = aclrtSetDevice(deviceId_);  
13.    if (ret != ACL_ERROR_NONE) {  
14.        ERROR_LOG("acl open device %d failed\n", deviceId_);  
15.        return FAILED;  
16.    }  
17.    INFO_LOG("open device %d success\n", deviceId_);  
18.  
19.    // create context (set current)  
20.    ret = aclrtCreateContext(&context_, deviceId_);  
21.    if (ret != ACL_ERROR_NONE) {  
22.        ERROR_LOG("acl create context failed\n");  
23.        return FAILED;  
24.    }  
25.    INFO_LOG("create context success");  
26.  
27.    // create stream  
28.    ret = aclrtCreateStream(&stream_);  
29.    if (ret != ACL_ERROR_NONE) {  
30.        ERROR_LOG("acl create stream failed\n");  
31.        return FAILED;  
32.    }  
33.    INFO_LOG("create stream success");  
34.  
35.    ret = aclrtGetRunMode(&runMode_);  
36.    if (ret != ACL_ERROR_NONE) {  
37.        ERROR_LOG("acl get run mode failed\n");  
38.        return FAILED;  
39.    }  
40.  
41.    return SUCCESS;  
42.} 
```

### 步骤 2 加载模型文件，构建模型输出内存

1)加载本地om模型文件到内存中，对应的功能函数原型为：
`1.Result ModelProcess::LoadModelFromFile(const char *modelPath)`
参数说明 —— modelPath：描述本地模型文件的存放路径
在文件object_detect.cpp中
 **函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::LoadModelFromFileWithMem(const char *modelPath)  
2.{  
3.    if (loadFlag_) {  
4.        ERROR_LOG("has already loaded a model");  
5.        return FAILED;  
6.    }  
7.  
8.    aclError ret = aclmdlQuerySize(modelPath, &modelMemSize_, &modelWeightSize_);  
9.    if (ret != ACL_ERROR_NONE) {  
10.        ERROR_LOG("query model failed, model file is %s\n", modelPath);  
11.        return FAILED;  
12.    }  
13.  
14.    ret = aclrtMalloc(&modelMemPtr_, modelMemSize_, ACL_MEM_MALLOC_HUGE_FIRST);  
15.    if (ret != ACL_ERROR_NONE) {  
16.        ERROR_LOG("malloc buffer for mem failed, require size is %zu\n", modelMemSize_);  
17.        return FAILED;  
18.    }  
19.  
20.    ret = aclrtMalloc(&modelWeightPtr_, modelWeightSize_, ACL_MEM_MALLOC_HUGE_FIRST);  
21.    if (ret != ACL_ERROR_NONE) {  
22.        ERROR_LOG("malloc buffer for weight failed, require size is %zu\n", modelWeightSize_);  
23.        return FAILED;  
24.    }  
25.  
26.    ret = aclmdlLoadFromFileWithMem(modelPath, &modelId_, modelMemPtr_,  
27.        modelMemSize_, modelWeightPtr_, modelWeightSize_);  
28.    if (ret != ACL_ERROR_NONE) {  
29.        ERROR_LOG("load model from file failed, model file is %s\n", modelPath);  
30.        return FAILED;  
31.    }  
32.  
33.    loadFlag_ = true;  
34.    INFO_LOG("load model %s success\n", modelPath);  
35.    return SUCCESS;  
36.}  
```

2)根据加载的模型ID，获取模型的描述信息，对应的功能函数原型为：
`1.Result ModelProcess::CreateDesc()`
在文件object_detect.cpp中
 **函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::CreateDesc()  
2.{  
3.    modelDesc_ = aclmdlCreateDesc();  
4.    if (modelDesc_ == nullptr) {  
5.        ERROR_LOG("create model description failed\n");  
6.        return FAILED;  
7.    }  
8.  
9.    aclError ret = aclmdlGetDesc(modelDesc_, modelId_);  
10.    if (ret != ACL_ERROR_NONE) {  
11.        ERROR_LOG("get model description failed\n");  
12.        return FAILED;  
13.    }  
14.  
15.    INFO_LOG("create model description success\n");  
16.    return SUCCESS;  
17.}  
```

3)根据模型的描述信息，获取模型的输出个数，以及每路输出在设备上所需的空间大小
 **对应的功能函数原型为：** 
`1.Result ModelProcess::CreateOutput()`
ACL库内置数据类型说明：aclmdlDataset主要用于描述模型推理时的输入数据或输出数据，模型可能存在多个输入、多个输出，每个输入或输出的内存地址、内存大小用aclDataBuffer类型的数据来描述。
在文件object_detect.cpp中
 **CreateOutput函数定义及相关源码注释如下所示：** 

```
1. Result ModelProcess::CreateOutput()  
2.{  
3.    if (modelDesc_ == nullptr) {  
4.        ERROR_LOG("no model description, create ouput failed\n");  
5.        return FAILED;  
6.    }  
7.  
8.    output_ = aclmdlCreateDataset();  
9.    if (output_ == nullptr) {  
10.        ERROR_LOG("can't create dataset, create output failed\n");  
11.        return FAILED;  
12.    }  
13.  
14.    size_t outputSize = aclmdlGetNumOutputs(modelDesc_);  
15.    for (size_t i = 0; i < outputSize; ++i) {  
16.        size_t buffer_size = aclmdlGetOutputSizeByIndex(modelDesc_, i);  
17.  
18.        void *outputBuffer = nullptr;  
19.        aclError ret = aclrtMalloc(&outputBuffer, buffer_size, ACL_MEM_MALLOC_NORMAL_ONLY);  
20.        if (ret != ACL_ERROR_NONE) {  
21.            ERROR_LOG("can't malloc buffer, size is %zu, create output failed\n", buffer_size);  
22.            return FAILED;  
23.        }  
24.  
25.        aclDataBuffer* outputData = aclCreateDataBuffer(outputBuffer, buffer_size);  
26.        if (ret != ACL_ERROR_NONE) {  
27.            ERROR_LOG("can't create data buffer, create output failed\n");  
28.            aclrtFree(outputBuffer);  
29.            return FAILED;  
30.        }  
31.  
32.        ret = aclmdlAddDatasetBuffer(output_, outputData);  
33.        if (ret != ACL_ERROR_NONE) {  
34.            ERROR_LOG("can't add data buffer, create output failed\n");  
35.            aclrtFree(outputBuffer);  
36.            aclDestroyDataBuffer(outputData);  
37.            return FAILED;  
38.        }  
39.    }  
40.  
41.    INFO_LOG("create model output success\n");  
42.    return SUCCESS;  
43.}  
```

### 步骤 3 文字检测模块

文字检测模块将摄像头输入YUV420sp格式图像转变为RGB格式，通过使用OpenCV的轮廓检测、合并和轮廓腐蚀、膨胀操作，检测出文字框，在原图中裁剪出文字区域交给图像预处理，经由图像预处理后输入模型进行推理。
 **文字检测函数在ObjectDetect::detect中实现：** 
在文件object_detect.cpp中

```
1.std::vector<cv::Rect> ObjectDetect::detect(cv::Mat img)  
2.{  
3.  img.convertTo(img,CV_8UC3);  
4.  std::vector<cv::Rect> result_rects;  
5.  float benchmark_len = img.rows;  
6.  float bench_area = img.rows*img.cols;  
7.  
8.  //从图像中提取红色区域轮廓
9.  cv::Mat hsv;  
10. cv::cvtColor(img.clone(), hsv, cv::COLOR_BGR2HSV);  
11. cv::Mat mask;  
12. cv::inRange(hsv, cv::Scalar(170, 100, 100), cv::Scalar(180, 255, 255), mask);  
13. cv::Mat element1 = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(15, 15));  
14. cv::Mat dilate1;  
15. cv::dilate(mask, dilate1, element1);  
16. std::vector<cv::Rect> rects;  
17. std::vector<std::vector<cv::Point> > contours;  
18. std::vector<cv::Vec4i> hierarchy;  
19. std::vector <cv::Point> center_point;  
20. cv::findContours(dilate1, contours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);  
21. if (contours.size() == 0)  
22. {  
23.     return result_rects;  
24. }  
25.  
26. // 得到这个轮廓的水平外矩形框
27. for (int i = 0; i < contours.size(); i++)  
28. {  
29.     cv::Rect rect = cv::boundingRect(contours[i]);  
30.     rects.push_back(rect);  
31. }  
32.  
33. // 计算所有矩形盒子的中心距离
34. //设置一个阈值，如果相对距离小于该阈值，则认为属于同一区域 
35. std::vector<std::vector<int> > dist_list(rects.size());  
36. for (int i = 0; i < rects.size(); i++)  
37. {  
38.     dist_list[i].push_back(i);  
39.     for (int j = i + 1; j < rects.size(); j++)  
40.     {  
41.         float two_dist = pow((rects[i].x + 0.5*rects[i].width) - (rects[j].x + 0.5*rects[j].width), 2)  
42.             + pow((rects[i].y + 0.5*rects[i].height) - (rects[j].y + 0.5*rects[j].height), 2);  
43.         float w_scale = two_dist / benchmark_len;  
44.         if (w_scale < 1.5)  
45.         {  
46.             dist_list[i].push_back(j);  
47.         }  
48.     }  
49. }  
50.  
51. // 使用并集查找方法合并属于同一区域的矩形 
52. std::vector <int> dist_result(dist_list.size(), -1);  
53. std::vector<int> dist;  
54. for (int m = 0; m < dist_list.size(); m++)  
55. {  
56.     dist = dist_list[m];  
57.     for (int j = 0; j < dist.size(); j++)  
58.     {  
59.         if (dist_result[m] == -1)  
60.         {  
61.             dist_result[m] = dist[j];  
62.         }  
63.         else  
64.         {  
65.             dist_result[dist[j]] = dist_result[m];  
66.         }  
67.     }  
68. }  
69.  
70. std::vector<std::vector<int> > un_list(dist_result.size());  
71. std::vector<int> un_dist;  
72. std::vector<cv::Rect> inte_area;  
73.  
74. for (int i = 0; i < dist_result.size(); i++)  
75. {  
76.     un_list[dist_result[i]].push_back(i);  
77. }  
78.  
79. //获取文本区域的外部矩形框
80. for (int m = 0; m < un_list.size(); m++)  
81. {  
82.     if (un_list[m].empty())  
83.     {  
84.         continue;  
85.     }  
86.     un_dist = un_list[m];  
87.     int xmin = rects[un_dist[0]].x;  
88.     int ymin = rects[un_dist[0]].y;  
89.     int xmax = rects[un_dist[0]].x + rects[un_dist[0]].width;  
90.     int ymax = rects[un_dist[0]].y + rects[un_dist[0]].height;  
91.     for (int j = 1; j < un_dist.size(); j++)  
92.     {  
93.         if (xmin > rects[un_dist[j]].x)  
94.         {  
95.             xmin = rects[un_dist[j]].x;  
96.         }  
97.         if (ymin > rects[un_dist[j]].y)  
98.         {  
99.             ymin = rects[un_dist[j]].y;  
100.            }  
101.            if (xmax < rects[un_dist[j]].x + rects[un_dist[j]].width)  
102.            {  
103.                xmax = rects[un_dist[j]].x + rects[un_dist[j]].width;  
104.            }  
105.            if (ymax < rects[un_dist[j]].y + rects[un_dist[j]].height)  
106.            {  
107.                ymax = rects[un_dist[j]].y + rects[un_dist[j]].height;  
108.            }  
109.        }  
110.  
111.        // 计算相对面积,设置一个阈值，如果相对区域大于阈值，则增加阈值，否则忽略
112.        
113.        double area = (xmax - xmin)*(ymax - ymin) / bench_area;  
114.        if (area>0.0015 && area<0.03)  
115.        {  
116.            cv::Rect roi = cv::Rect(xmin, ymin, xmax - xmin, ymax - ymin);  
117.            result_rects.push_back(roi);  
118.        }  
119.    }  
120.    return result_rects;  
121.}  
122.  
```

### 步骤 4 读取摄像头数据并进行图像预处理

对文字检测模块得到的文字区域图片进行预处理，将图像数据进行大小缩放，缩放至模型要求输入图像的宽高，本例中模型要求的输入图像宽高为112*112。
在文件object_detect.cpp中
 **预处理函数在ObjectDetect::Preprocess 中实现：** 
1.Result ObjectDetect::Preprocess(cv::Mat& frame)
 **Main函数中实现了总的代码调用流程，这里仅将功能调用的源码列举出来：** 

```
1.if(bSetChannelId)  
2.    {  
3.        string channelName = string(argv[1]);  
4.        Utils::GetChannelID(channelName, channelId);  
5.        if(0xFF == channelId){  
6.            INFO_LOG("channelId = %d  ERROR \n", channelId);  
7.            return FAILED;  
8.        }  
9.    }  
10.  
11.    Camera  cameraDevice(channelId);  
12.    if(false == cameraDevice.IsOpened(channelId))  
13.    {  
14.        if (cameraDevice.Open(channelId)) {  
15.            ERROR_LOG("Failed to open channelId =%d.\n", channelId);  
16.            return FAILED;  
17.        }  
18.    }  
19.  
20.    void * buffer = nullptr;  
21.    int size = cameraDevice.GetCameraDataSize(channelId);  
22.  
23.    aclError aclRet = acldvppMalloc(&buffer, size);  
24.    g_imagedata->data.reset((uint8_t*)buffer, [](uint8_t* p) { acldvppFree((void *)p); });  
25.  
26.    ImageData resizedImage;  
27.    ImageResults inferenceOutput;  
28.  
29.  
30.    // 读取字库
31.    std::ifstream in("./lexicon3755.txt");  
32.    std::string name;  
33.    vector<string> dict;  
34.    if(in)  
35.    {  
36.        int i=0;  
37.        while (getline (in, name))  
38.        {  
39.            dict.push_back(name);  
40.        }  
41.    }  
42.  
43.  
44.    bool istwo = true;  
45.    while(1)  
46.    {  
47.        if(istwo)  
48.        {  
49.            istwo=false;  
50.            continue;  
51.        }  
52.        istwo=true;  
53.        //逐张图片推理  
54.        cameraDevice.Read(channelId, *(g_imagedata.get()));  
55.        if (g_imagedata->data == nullptr) {  
56.            ERROR_LOG("Read image %d failed\n", channelId);  
57.            return FAILED;  
58.        }  
59.  
60.        inferenceOutput = detect.Inference(*(g_imagedata.get()), dict);  
61.  
62.        if ((ret != SUCCESS)) {  
63.  
64.            ERROR_LOG("Inference model inference output data failed\n");  
65.            return FAILED;  
66.        }  
67.  
68.        ret = detect.Postprocess(*(g_imagedata.get()), inferenceOutput);  
69.        if (ret != SUCCESS) {  
70.            ERROR_LOG("Process model inference output data failed\n");  
71.            return FAILED;  
72.        }  
73.    }  
74.  
```

### 步骤 5 构建模型输入数据，进行模型推理

 **构建模型输入数据的功能函数是：** 
`1.Result ModelProcess::CreateInput(void *input1, size_t input1size)`
参数说明 —— 
input1 [in]: 设备侧包含图像数据的内存空间地址
input1size [in] : 描述设备侧包含图像数据的内存空间所占字节大小
在文件model_process.cpp中
 **CreateInput函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::CreateInput(void *input1, size_t input1size)  
2.{  
3.     // 创建aclmdlDataset类型的数据  
4.     // 用于描述模型每个输入数据的内存地址和内存大小  
5.    input_ = aclmdlCreateDataset();  
6.    if (input_ == nullptr) {  
7.        ERROR_LOG("can't create dataset, create input failed");  
8.        return FAILED;  
9.    }  
10.  
11.    // 创建aclDataBuffer类型的数据用于描述在设备上申请的内存空间地址以及相应的大小  
12.    aclDataBuffer* inputData = aclCreateDataBuffer(input1, input1size);  
13.    if (inputData == nullptr) {  
14.        ERROR_LOG("can't create data buffer, create input failed");  
15.        return FAILED;  
16.    }  
17.  
18.    // 向input_中添加outputData  
19.    // 即将描述模型第一路输入的数据信息添加到input_中  
20.    aclError ret = aclmdlAddDatasetBuffer(input_, inputData);  
21.    if (inputData == nullptr) {  
22.        ERROR_LOG("can't add data buffer, create input failed");  
23.        aclDestroyDataBuffer(inputData);  
24.        inputData = nullptr;  
25.        return FAILED;  
26.    }  
27.  
28.    return SUCCESS;  
29.}  
```

根据已经加载到内存中，要进行推理的模型ID、构建好的模型推理输入数据，调用ACL库中模型推理接口进行模型推理。检测出汉字的矩形框集合，接下来依次对每个汉字子图像通过模型进行推理，得到输出向量的结果集合；另一方面还需将每帧图像转换JPG格式，以便于查看摄像头图像。将JPG格式的每帧图像集合和每帧识别结果集合作为输入传给后处理模块模块。
在文件model_process.cpp中
 **相应的功能函数原型为：** 
`1.Result ModelProcess::Execute()`
Execute函数定义及相关源码注释如下所示：

```
1.Result ModelProcess::Execute()  
2.{  
3.    // 执行模型推理，直到返回推理结果  
4.    aclError ret = aclmdlExecute(modelId_, input_, output_);  
5.    if (ret != ACL_ERROR_NONE) {  
6.        ERROR_LOG("execute model failed, modelId is %u", modelId_);  
7.        return FAILED;  
8.    }  
9.    INFO_LOG("model execute success");  
10.    return SUCCESS;  
11.}  
```

ACL库中模型推理接口：aclmdlExecute 说明：
函数功能：执行模型推理，直到返回推理结果，同步接口。
 **函数原型：** 
`1.aclError aclmdlExecute(uint32_t modelId, const aclmdlDataset *input, aclmdlDataset *output)`
参数说明 —— 
modelId [in]:   指定需要执行推理的模型的ID
input [in] :       模型推理的输入数据
output [out] :  模型推理的输出数据
### 步骤 6 分析解析模型推理结果

本实验将模型推理的结果解析后，通过在本机部署的Presenter Server进程将检测结果可视化，利用Presenter Agent提供的API向Presenter Server推送媒体消息，Presenter Server接收Presenter Agent发过来的媒体数据，通过浏览器进行结果展示。
 **Presenter Agent 的使用方法基本如下：** 

- 首先创建并打开一个连接Presenter Server的通道。
- 发送一个包含一帧图像信息的结构体对象到presenter server。

 **在本工程中打开通道的源码为：** 

```
1.ObjectDetect::ObjectDetect(const char* modelPath,  
2.                           uint32_t modelWidth,  
3.                           uint32_t modelHeight)  
4.:deviceId_(0), context_(nullptr), stream_(nullptr), modelWidth_(modelWidth),  
5. modelHeight_(modelHeight), isInited_(false){  
6.    imageInfoSize_ = 0;  
7.    imageInfoBuf_ = nullptr;  
8.    modelPath_ = modelPath;  
9.    Channel* chan = nullptr;  	
10.    PresenterErrorCode openChannelret = OpenChannelByConfig(chan, "./param.conf");  
11.    if (openChannelret != PresenterErrorCode::kNone) {  
12.        ERROR_LOG("Open channel failed, error %d\n", (int)openChannelret);  
13.    }  
14.    chan_.reset(chan);  
15.  
16.}  
```

    后处理模块接收上一个模块的推理结果与摄像头JPG图像，将矩形框集合添加到Presenter Server记录检测目标位置信息的数据结构DetectionResult中，作为摄像头图像的检测结果，通过调用Presenter Agent的API发送到UI Host上部署的Presenter Server服务进程。Presenter Server根据接收到的推理结果，求出汉字最大预测概率值所对应的索引，在索引表中查找对应汉字，在JPG图像上进行汉字矩形框位置及汉字识别结果的标记，并将图像信息发送给Web UI。其中索引表为一个记录汉字与其对应索引值的表lexicon3755.txt，在Ubuntu系统下以UTF-8的格式存储，其中每一行对应一个汉字。
 **在本工程文件中模型的推理结果解析函数原型为：** 
`1.Result ObjectDetect::Postprocess(ImageData& image, ImageResults& modelOutput)`
在文件model_process.cpp中
 **Postprocess函数定义及相关源码注释如下所示：** 

```
1.Result ObjectDetect::Postprocess(ImageData& image, ImageResults& modelOutput) {  
2.  
3.  uint32_t num = modelOutput.num;  
4.  vector<DetectionResult> detectResults;  
5.  for(uint32_t i=0;i<num;i++)  
6.  {  
7.      myoutput out2 = modelOutput.output_datas[i];  
8.      DetectionResult one_result;  
9.      Point point_lt, point_rb;  
10.     point_lt.x = out2.lx;  
11.     point_lt.y = out2.ly;  
12.     point_rb.x = out2.rx;  
13.     point_rb.y = out2.ry;  
14.  
15.  
16.     one_result.lt = point_lt;  
17.     one_result.rb = point_rb;  
18.     //从索引表中获取相应的中文字符
19.     one_result.result_text=out2.name;  
20.     detectResults.push_back(one_result);  
21.  
22.  
23. }  
24. ImageData jpgImage;  
25.  
26. //Result ret = dvpp_.CvtYuv420spToJpeg(jpgImage, image);  
27. //------------------------------后加--------------------------------------  
28. //1.ImageData类型图像转成Mat(yuv格式)  
29. int img_height = image.height;  
30. int img_width = image.width;  
31. cv::Mat jpegSrc(img_height * 3 / 2, img_width, CV_8UC1);  
32. int copy_size = img_width * img_height * 3 / 2;  
33. int destination_size = jpegSrc.cols * jpegSrc.rows * jpegSrc.elemSize();  
34. memcpy(jpegSrc.data, image.data.get(), copy_size);  
35. //2.src转dst_temp(yuv类型转RGB)  
36. cv::Mat jpegDst;  
37. cvtColor(jpegSrc, jpegDst, cv::COLOR_YUV420sp2RGB);  
38. Result ret = SendImage(chan_.get(), jpegDst, detectResults);  
39. return ret;  
40.  
41.}  
```

### 步骤 7 资源释放

资源释放分别在以下函数中实现，具体函数定义可以参考源码：

```
1.void ObjectDetect::DestroyResource();   
2.void ModelProcess::Unload();  
3.void ModelProcess::DestroyDesc();  
4.void ModelProcess::DestroyInput();  
5.void ModelProcess::DestroyOutput();  
```







