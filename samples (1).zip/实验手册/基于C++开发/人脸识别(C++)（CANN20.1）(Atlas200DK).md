<!-- GFM-TOC -->

* [1 实验介绍](#1-实验介绍)
* [2 实验原理](#2-实验原理)
* [3 实验环境](#3-实验环境)
* [4 快速体验](#4-快速体验)
* [5 人脸识别原理](#5-人脸识别原理)
* [6 开发步骤和关键代码分析](#6-开发步骤和关键代码分析)
  <!-- GFM-TOC -->
# 1 实验介绍

本实验是基于Atlas 200DK开发板开发的人脸识别案例，开发者可以将本Application部署至Atlas 200 DK上实现人脸注册并通过摄像头对人脸进行识别，与已注册的人脸进行比对，预测出最可能的用户。通过人脸检测，关键点检测，特征向量提取三个模型的推理之后即可完成人脸识别，推理结果经过后处理解析后，会调用Presenter Agent的接口向Presenter Server发送数据，Presenter Server接收到Presenter Agent发送的数据后，进行画框和ID展示，用户通过浏览器访问Presenter Server查看人脸识别的结果。
# 2 实验原理
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/142247_b1649c8d_7380811.png "屏幕截图.png")
 **1)人脸注册：** 在人脸注册输入时，在界面按照要求上传人脸图片，输入图片username。

 **2)摄像头输入：** 进行人脸识别时经由摄像头输入图片。

 **3)人脸检测：** 人脸检测模型接收到输入的图片之后，检测该图片中是否含有人脸，如果含有人脸则给出人脸的坐标信息，将这些信息传入到关键点检测模块进行推理。人脸检测模型推理模块可以分为三个部分，预处理、模型推理和后处理。

 **4)关键点提取：** 关键点检测模型，通过关键点提取模型推理检测出人脸的左眼、右眼、鼻子、左嘴角、右嘴角五个关键点位置信息，获得这五个关键点的作用是用来对图片中侧着的人脸进行对齐。   

 **5)特征点提取：** 特征向量提取模块利用关键点检测模型推理得到的五个关键点坐标对裁剪后的人脸图片进行对齐处理，最后将对齐的人脸和水平垂直翻转得到的人脸送入到特征向量提取模型推理，得到人脸特征向量，然后将该向量传入数据整理模块。

 **6)后处理：** 分别对摄像头输入和人脸注册输入后经过三个模型推理之后得到的数据进行整理。
# 3 实验环境

实验前需要制作SD卡并在连接Atlas 200DK的Ubuntu服务器上准备好软件环境，安装步骤请参考文档链接：
https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0003.html
# 4 快速体验

### 步骤 1 在Ubuntu18.04服务器上获取人脸识别源码包

1)切换至普通用户（如ascend），执行如下命令：
`su ascend`
2)执行如下命令在ascend用户下创建工程存放目录，并进入该目录：

```
mkdir -p $HOME/AscendProjects
cd $HOME/AscendProjects
```

3)执行如下命令获取人脸识别工程：
`wget https://obs-book.obs.cn-east-2.myhuaweicloud.com/liuyuan/20.1samples/face_recognition_camera.zip`
如果服务器上没有wget命令，使用以下命令进行安装：
`sudo apt-get install wget`
如果使用wget下载失败，可使用如下命令下载代码。
`curl -OL https://obs-book.obs.cn-east-2.myhuaweicloud.com/liuyuan/20.1samples/face_recognition_camera.zip`
如果服务器上没有curl命令，使用以下命令进行安装：
`sudo apt-get install curl`
如果curl也下载失败，可复制下载链接到浏览器，手动上传至服务器。
4)解压工程文件压缩包：
`unzip face_recognition_camera.zip`
如果服务器上没有unzip命令，使用以下命令进行安装：
`sudo apt-get install unzip`
工程文件目录如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/142534_918d57dc_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/142542_a6654641_7380811.png "屏幕截图.png")
工程目录说明如下表所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/143135_ce92fa5b_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/143144_8ad2e852_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/143151_dc7d484b_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/143157_55be2c9f_7380811.png "屏幕截图.png")
### 步骤 2 模型转换（命令行方式）

我们选择caffe的人脸检测模型，关键点提取模型和特征向量提取模型，需要将其转换为昇腾AI处理器支持的Davinci模型文件，这里我们选择使用命令行方式对模型进行转换。
1)获取此应用中所需要的原始网络模型，下载原始网络模型和权重文件至ubuntu服务器任意目录，如:$HOME/models/face_recognition_camera

```
mkdir -p $HOME/models/face_recognition_camera
cd  models/face_recognition_camera/
```

获得人脸检测模型和配置文件

```
wget  https://modelzoo-train-atc.obs.cn-north-4.myhuaweicloud.com/003_Atc_Models/AE/ATC%20Model/facedection/face_detection_fp32.caffemodel
wget  https://modelzoo-train-atc.obs.cn-north-4.myhuaweicloud.com/003_Atc_Models/AE/ATC%20Model/facedection/face_detection.prototxt
wget  https://c7xcode.obs.cn-north-4.myhuaweicloud.com/models/face_recognition_camera/face_detection_insert_op.cfg
```

如下图所示，模型下载完毕：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/143320_783ce3ea_7380811.png "屏幕截图.png")
获得关键点提取模型

```
wget https://modelzoo-train-atc.obs.cn-north-4.myhuaweicloud.com/003_Atc_Models/AE/ATC%20Model/vanillacnn/vanillacnn.caffemodel
wget https://modelzoo-train-atc.obs.cn-north-4.myhuaweicloud.com/003_Atc_Models/AE/ATC%20Model/vanillacnn/vanilla_deploy.prototxt
```

如下图所示，模型下载完毕：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/143400_b0b406b9_7380811.png "屏幕截图.png")
获取特征向量提取模型和配置文件

```
wget  https://modelzoo-train-atc.obs.cn-north-4.myhuaweicloud.com/003_Atc_Models/AE/ATC%20Model/sphereface/sphereface.caffemodel
wget https://modelzoo-train-atc.obs.cn-north-4.myhuaweicloud.com/003_Atc_Models/AE/ATC%20Model/sphereface/sphereface.prototxt
wget https://c7xcode.obs.cn-north-4.myhuaweicloud.com/models/face_recognition_camera/sphereface_insert_op.cfg
```

如下所示，模型下载完毕
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/143420_d0e339b2_7380811.png "屏幕截图.png")
2)将原始网络模型转换为昇腾AI处理器支持的Davinci模型
执行如下命令，进入目录下：
`cd $HOME/models/face_recognition_camera`
执行如下命令设置环境变量

```
export install_path=$HOME/Ascend/ascend-toolkit/latest
export PATH=/usr/local/python3.7.5/bin:${install_path}/atc/ccec_compiler/bin:${install_path}/atc/bin:$PATH
export PYTHONPATH=${install_path}/atc/python/site-packages:${install_path}/atc/python/site-packages/auto_tune.egg/auto_tune:${install_path}/atc/python/site-packages/schedule_search.egg:$PYTHONPATH
export LD_LIBRARY_PATH=${install_path}/atc/lib64:$LD_LIBRARY_PATH
export ASCEND_OPP_PATH=${install_path}/opp
```

在普通用户下使用atc命令进行模型转换：
1.转换人脸检测模型
`atc --input_shape="data:1,3,300,300" --weight="./face_detection_fp32.caffemodel" --input_format=NCHW --output="./face_detection" --soc_version=Ascend310 --insert_op_conf=./face_detection_insert_op.cfg --framework=0 --model="./face_detection.prototxt"`
模型转换成功后，存放在当前目录下：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/143517_21ed9a89_7380811.png "屏幕截图.png")
执行如下命令，将转换成功的模型放到工程目录的model文件夹下：
`cp face_detection.om $HOME/AscendProjects/face_recognition_camera/model/`
如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/143527_695428be_7380811.png "屏幕截图.png")
2.转换关键点提取模型
在当前目录下执行如下ATC命令转换
`atc --input_shape="data:4,3,40,40" --weight="./vanillacnn.caffemodel" --input_format=NCHW --output="./vanillacnn" --soc_version=Ascend310 --framework=0 --model="./vanilla_deploy.prototxt"`

执行如下命令，将转换成功的模型放到工程目录的model文件夹下：
`cp vanillacnn.om  $HOME/AscendProjects/face_recognition_camera/model`
3.转换特征向量获取模型
在当前目录下执行如下ATC命令转换
`atc --input_shape="data:8,3,112,96" --weight="./sphereface.caffemodel" --input_format=NCHW --output="./sphereface" --soc_version=Ascend310 --insert_op_conf=./sphereface_insert_op.cfg --framework=0 --model="./sphereface.prototxt"`


执行如下命令，将转换成功的模型放到工程目录的model文件夹下：
`cp sphereface.om  $HOME/AscendProjects/face_recognition_camera/model`
如下所示，将三个转换好的模型复制到如下路径
`/home/ascend/AscendProjects/face_recognition_camera/model`
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/143644_37039c7c_7380811.png "屏幕截图.png")

### 步骤 3  在Mind Studio中打开工程文件

1)打开对应的工程
切换至安装Mind Studio的用户（如ascend），并进入“MindStudio-ubuntu/bin”目录，如：$HOME/MindStudio-ubuntu/bin。执行如下命令启动Mind Studio：
`./MindStudio.sh &`
启动成功后，打开face_recognition_camera工程如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144023_c7d6b50b_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144028_3346749a_7380811.png "屏幕截图.png")

### 步骤 4 编译工程文件

1)修改Presenter Server的ip。
将script/param.conf中的presenter_server_ip、presenter_view_ip修改为Mind Studio所在Ubuntu服务器的虚拟网卡的ip地址，比如 虚拟网卡的ip地址 为 192.168.1.223 如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144051_00dc8c83_7380811.png "屏幕截图.png")
 **说明：虚拟网卡的ip地址请通过ifconfig命令查看，如下图所示：** 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144109_7b24f4fc_7380811.png "屏幕截图.png")
2)在Mind Studio的工具栏中依次点击Build > Edit Build Configuration，“Target OS” 选择为“Linux” ，”Target Architecture”选择为 “aarch64”, 然后“Build”。如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144124_5c5c369e_7380811.png "屏幕截图.png")
3)然后再依次点击Build > Build > Build Configuration，如下图所示，会在目录下生成build和out文件夹：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144153_000688fd_7380811.png "屏幕截图.png")

4)启动Presenter Server
打开Mind Studio工具的Terminal，在应用代码存放路径下，执行如下命令： bash script/run_presenter_server.sh 
在后台启动face_recognition_camera应用的Presenter Server主程序。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144212_b5811557_7380811.png "屏幕截图.png")
注：红框中的绝对路径是为了保存人脸注册输入后经过人脸检测，关键点提取和特征向量获取之后的到的数据，为了和摄像头输入之后得到的数据进行对比完成人脸识别。

### 步骤 5 运行工程

1)在Mind Studio的工具栏找到Run按钮，单击 Run > Edit
 Configurations，在Target Host Ip中添加开发板ip，用于连接开发板，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144257_c0d0f9bc_7380811.png "屏幕截图.png")
单击右侧“+”按钮后弹出Device Manager 界面，如下图所示操作，添加开发板：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144308_5b763191_7380811.png "屏幕截图.png")
设备添加成功，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144322_62ae09dc_7380811.png "屏幕截图.png")
之后分别点击Apply、OK。如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144332_132b5476_7380811.png "屏幕截图.png")
2)单击 Run > Run ‘face_recognition_camera’ ，可执行程序在开发板执行，如下图所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144347_ece5d59b_7380811.png "屏幕截图.png")
3)在presentersever界面注册图片和进行人脸识别，查看推理结果，如图所示：
注册输入username和上传图片
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144400_09eed172_7380811.png "屏幕截图.png")
摄像头输入图片识别得到
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144421_e26d0bf5_7380811.png "屏幕截图.png")![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144426_2a156a38_7380811.png "屏幕截图.png")![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144430_78d34f94_7380811.png "屏幕截图.png")

# 5 人脸识别原理

图像目标检测代码流程图如下所示：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/144558_bfdd4262_7380811.png "123.png")
详细开发步骤及代码逻辑分析参见下述说明。

# 6 开发步骤和关键代码分析

将模型部署到Atlas 200DK的步骤一般是这样的：

- 首先，模型转换，得到在昇腾AI处理器上能够跑起来的离线模型，经过上面的实验准备环节，已经得到了om模型。
- 然后，基于ACL接口进行应用开发。

代码的开发过程大致分为以下步骤：

1）.运行管理资源申请；
2）.加载模型文件，构建模型输出内存；
3）.数据获取，获取要进行推理的原始图像；
4）.人脸检测，获得人脸的坐标位置
5）.关键点提取，获得面部关键点坐标
6）.特征点提取，得到面部特征向量
7）.解析模型推理结果，将推理结果通过调用Presenter Agent的API发送到主机端UI host上部署的Presenter Server服务进程，通过浏览器访问Presenter Server，查看人脸识别结果。
8）.释放资源。

本实验项目是利用Presenter Server实现人脸识别结果的显示，先将人脸注册后的到的数据保存到文件中，在人脸识别时将由摄像头输入的照片的到的数据与之对比，在界面上将识别结果显示出来，从而达到人脸识别的目的。

### 步骤 1 运行管理资源申请

运行管理资源申请的功能封装在了函数ResourceLoad::InitResource()中。函数所在的文件是src/resource_load.cpp
关于ACL的相关介绍可以查询如下链接：
https://support.huaweicloud.com/asdevg-c-A200dk_3000_c75/atlasapi_07_0244.html
函数源码如下所示，ACL相关功能接口的调用已在函数中进行了说明：


```
1.Result ResourceLoad::InitResource() {  
2.    // ACL init  
3.    //const char *aclConfigPath = "../src/acl.json";  
4.    char aclConfigPath[32] = {'\0'};  
5.    aclError ret = aclInit(aclConfigPath);  
6.    if (ret != ACL_ERROR_NONE) {  
7.        ERROR_LOG("acl init failed\n");  
8.        return FAILED;  
9.    }  
10.  
11.    // open device  
12.    ret = aclrtSetDevice(deviceId_);  
13.    if (ret != ACL_ERROR_NONE) {  
14.        ERROR_LOG("acl open device %d failed\n", deviceId_);  
15.        return FAILED;  
16.    }  
17.  
18.    // create context (set current)  
19.    ret = aclrtCreateContext(&context_, deviceId_);  
20.    if (ret != ACL_ERROR_NONE) {  
21.        ERROR_LOG("acl create context failed\n");  
22.        return FAILED;  
23.    }  
24.  
25.    // create stream  
26.    ret = aclrtCreateStream(&stream_);  
27.    if (ret != ACL_ERROR_NONE) {  
28.        ERROR_LOG("acl create stream failed\n");  
29.        return FAILED;  
30.    }  
31.  
32.    ret = aclrtGetRunMode(&runMode_);  
33.    if (ret != ACL_ERROR_NONE) {  
34.        ERROR_LOG("acl get run mode failed\n");  
35.        return FAILED;  
36.    }  
37.  
38.    return SUCCESS;  
39.}  
```
### 步骤 2 加载模型文件，构建模型输出内存

1)加载本地om模型文件到内存中，对应的功能函数原型为：
`1.Result ModelProcess:: LoadModelFromFileWithMem (const char *modelPath)`
参数说明 —— modelPath：描述本地模型文件的存放路径
函数所在的文件是src/model_process.cpp
 **函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::LoadModelFromFileWithMem(const char *modelPath)    
2.{    
3.    if (loadFlag_) {    
4.        ERROR_LOG("has already loaded a model");    
5.        return FAILED;    
6.    }    
7.    
8.    aclError ret = aclmdlQuerySize(modelPath, &modelMemSize_, &modelWeightSize_);    
9.    if (ret != ACL_ERROR_NONE) {    
10.        ERROR_LOG("query model failed, model file is %s\n", modelPath);    
11.        return FAILED;    
12.    }    
13.    
14.    ret = aclrtMalloc(&modelMemPtr_, modelMemSize_, ACL_MEM_MALLOC_HUGE_FIRST);    
15.    if (ret != ACL_ERROR_NONE) {    
16.        ERROR_LOG("malloc buffer for mem failed, require size is %zu\n", modelMemSize_);    
17.        return FAILED;    
18.    }    
19.    
20.    ret = aclrtMalloc(&modelWeightPtr_, modelWeightSize_, ACL_MEM_MALLOC_HUGE_FIRST);    
21.    if (ret != ACL_ERROR_NONE) {    
22.        ERROR_LOG("malloc buffer for weight failed, require size is %zu\n", modelWeightSize_);    
23.        return FAILED;    
24.    }    
25.    
26.    ret = aclmdlLoadFromFileWithMem(modelPath, &modelId_, modelMemPtr_,    
27.        modelMemSize_, modelWeightPtr_, modelWeightSize_);    
28.    if (ret != ACL_ERROR_NONE) {    
29.        ERROR_LOG("load model from file failed, model file is %s\n", modelPath);    
30.        return FAILED;    
31.    }    
32.    
33.    loadFlag_ = true;    
34.    return SUCCESS;    
}    
```
2)根据加载的模型ID，获取模型的描述信息，对应的功能函数原型为：
`1.Result ModelProcess::CreateDesc()`
对应的文件是src/model_process.cpp
 **函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::CreateDesc()    
2.{    
3.    modelDesc_ = aclmdlCreateDesc();    
4.    if (modelDesc_ == nullptr) {    
5.        ERROR_LOG("create model description failed\n");    
6.        return FAILED;    
7.    }    
8.    
9.    aclError ret = aclmdlGetDesc(modelDesc_, modelId_);    
10.    if (ret != ACL_ERROR_NONE) {    
11.        ERROR_LOG("get model description failed\n");    
12.        return FAILED;    
13.    }    
14.    
15.    return SUCCESS;    
16.}    

```
3)根据模型的描述信息，获取模型的输出个数，以及每路输出在设备上所需的空间大小
 **对应的功能函数原型为：** 
`1.Result ModelProcess::CreateOutput()`
ACL库内置数据类型说明：aclmdlDataset主要用于描述模型推理时的输入数据或输出数据，模型可能存在多个输入、多个输出，每个输入或输出的内存地址、内存大小用aclDataBuffer类型的数据来描述。
对应的文件是src/model_process.cpp
 **CreateOutput函数定义及相关源码注释如下所示：** 

```
1.Result ModelProcess::CreateOutput()    
2.{    
3.    if (modelDesc_ == nullptr) {    
4.        ERROR_LOG("no model description, create ouput failed\n");    
5.        return FAILED;    
6.    }    
7.    
8.    output_ = aclmdlCreateDataset();    
9.    if (output_ == nullptr) {    
10.        ERROR_LOG("can't create dataset, create output failed\n");    
11.        return FAILED;    
12.    }    
13.    
14.    size_t outputSize = aclmdlGetNumOutputs(modelDesc_);    
15.    for (size_t i = 0; i < outputSize; ++i) {    
16.        size_t buffer_size = aclmdlGetOutputSizeByIndex(modelDesc_, i);    
17.    
18.        void *outputBuffer = nullptr;    
19.        aclError ret = aclrtMalloc(&outputBuffer, buffer_size, ACL_MEM_MALLOC_NORMAL_ONLY);    
20.        if (ret != ACL_ERROR_NONE) {    
21.            ERROR_LOG("can't malloc buffer, size is %zu, create output failed\n", buffer_size);    
22.            return FAILED;    
23.        }    
24.    
25.        aclDataBuffer* outputData = aclCreateDataBuffer(outputBuffer, buffer_size);    
26.        if (ret != ACL_ERROR_NONE) {    
27.            ERROR_LOG("can't create data buffer, create output failed\n");    
28.            aclrtFree(outputBuffer);    
29.            return FAILED;    
30.        }    
31.    
32.        ret = aclmdlAddDatasetBuffer(output_, outputData);    
33.        if (ret != ACL_ERROR_NONE) {    
34.            ERROR_LOG("can't add data buffer, create output failed\n");    
35.            aclrtFree(outputBuffer);    
36.            aclDestroyDataBuffer(outputData);    
37.            return FAILED;    
38.        }    
39.    }    
40.    
41.    return SUCCESS;    
42.}    
```
### 步骤 3 人脸注册

在人脸注册输入时，在界面上上传人脸图片，输入图片username，通过Presenter Server发送到presenter agnt传入到板侧进行推理，通过三个模型推理之后得到人脸坐标，以及特征向量，将这些数据发送回Presenter Server侧再保存到文件中。
人脸注册时界面如下：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/151019_96c9c55d_7380811.png "屏幕截图.png")
 **上述功能函数原型为：** 
bool FaceRegister::DoRegisterProcess()
函数所在的文件是src/face_register.cpp
 **DoRegisterProcess函数定义及相关源码注释如下所示：** 

```
1.bool FaceRegister::DoRegisterProcess() {    
2.    // get agent channel    
3.    Channel* agent_channel = PresenterChannels::GetInstance().GetChannel();    
4.    if (agent_channel == nullptr) {    
5.        ERROR_LOG("get agent channel to send failed.");    
6.        return false;    
7.    }    
8.    
9.    bool ret = true;    
10.    while (1) {    
11.        // construct registered request Message and read message    
12.        unique_ptr < google::protobuf::Message > response_rec;    
13.        PresenterErrorCode agent_ret = agent_channel->ReceiveMessage(response_rec);    
14.        if (agent_ret == PresenterErrorCode::kNone) {    
15.            FaceInfo* face_register_req = (FaceInfo*) (response_rec.get());    
16.            if (face_register_req == nullptr) {    
17.                ERROR_LOG("[DoRegisterProcess]face_register_req is nullptr");    
18.                continue;    
19.            }    
20.            clock_gettime(CLOCK_REALTIME, &time1);    
21.            // get face id and image    
22.            uint32_t face_image_size = face_register_req->image().size();    
23.            const char* face_image_buff = face_register_req->image().c_str();    
24.            int face_id_size = face_register_req->id().size();    
25.            INFO_LOG("face_id = %s,face_image_size = %d,face_id_size = %d",    
26.                      face_register_req->id().c_str(), face_image_size,    
27.                      face_id_size);    
28.    
29.            // ready to send registered info to next component    
30.            shared_ptr < FaceRecognitionInfo > pobj =    
31.                make_shared<FaceRecognitionInfo>();    
32.    
33.            // judge size of face id    
34.            if (face_id_size > kMaxFaceIdLength) {    
35.                ERROR_LOG("[DoRegisterProcess]length of face_id beyond range");    
36.                pobj->err_info.err_code = AppErrorCode::kRegister;    
37.                pobj->err_info.err_msg = "length of face_id beyond range";    
38.                // send description information to next engine    
39.                ResourceLoad::GetInstance().SendNextModelProcess("FaceRegister", pobj);    
40.    
41.                continue;    
42.            }    
43.    
44.            // use dvpp convert jpg image to yuv    
45.            ImageData jpgImage;    
46.            int32_t ch = 0;    
47.            void * buffer = nullptr;    
48.   
49.            acldvppJpegGetImageInfo(face_image_buff, face_image_size,    
50.                 &(jpgImage.width), &(jpgImage.height), &ch);    
51.            aclError aclRet = acldvppMalloc(&buffer, face_image_size*2);    
52.            jpgImage.data.reset((uint8_t*)buffer, [](uint8_t* p) { acldvppFree((void *)p); });    
53.            jpgImage.size = face_image_size;    
54.    
55.            aclrtMemcpy(jpgImage.data.get(), face_image_size, face_image_buff, face_image_size, ACL_MEMCPY_DEVICE_TO_DEVICE);    
56.    
57.            //INFO_LOG("[DoRegisterProcess]jpgImage.width %d, jpgImage.height %d jpgImage.size %d", jpgImage.width, jpgImage.height, jpgImage.size);    
58.    
59.            ret = ResourceLoad::GetInstance().GetDvpp().CvtJpegToYuv420sp(pobj->org_img, jpgImage);    
60.            // failed, no need to send to presenter    
61.            if(ret == FAILED)    
62.            {    
63.                ERROR_LOG("[DoRegisterProcess]fail to convert jpg to yuv");    
64.                pobj->err_info.err_code = AppErrorCode::kRegister;    
65.                pobj->err_info.err_msg = "fail to convert jpg to yuv";    
66.                // send description information to next component    
67.                ResourceLoad::GetInstance().SendNextModelProcess("FaceRegister", pobj);    
68.                continue;    
69.            }    
70.            
71.            // 1 indicate the image from register    
72.            pobj->frame.image_source = 1;    
73.            pobj->frame.face_id = face_register_req->id();    
74.            pobj->frame.org_img_format = PIXEL_FORMAT_YUV_SEMIPLANAR_420;    
75.            // true indicate the image is aligned    
76.            pobj->frame.img_aligned = true;    
77.    
78.            pobj->err_info.err_code = AppErrorCode::kNone;    
79.    
80.            INFO_LOG("[DoRegisterProcess]jpgImage.width %d, jpgImage.height %d yuvImage_.alignWidth %d yuvImage_.alignHeight %d",    
81.            pobj->org_img.width, pobj->org_img.height, pobj->org_img.alignWidth, pobj->org_img.alignHeight);    
82.    
83.            ResourceLoad::GetInstance().SendNextModelProcess("FaceRegister", pobj);    
84.            clock_gettime(CLOCK_REALTIME, &time2);    
85.            cout << "FaceRegister::DoRegisterProcess costtime is: " << (time2.tv_sec - time1.tv_sec)*1000 + (time2.tv_nsec - time1.tv_nsec)/1000000 << "ms" << endl;    
86.        } else {    
87.            usleep(kSleepInterval);    
88.        }    
89.    }    
90.}    
```
### 步骤 4 摄像头输入

摄像头输入是在进行人脸识别时的输入，直接将摄像头获取的图片传入人脸检测模块进行推理，该图片经过三个模型推理之后得到人脸坐标和特征向量，之后将人脸坐标、原始图片以及特征向量发送到presenter sever进行展示，将特征向量与注册时保存的特征向量进行对比，从而实现人脸识别的功能。摄像头输入时界面如下：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0125/152233_7fb93975_7380811.png "屏幕截图.png")
 **上述功能函数原型为：** 
bool MindCamera::DoCapProcess()
函数所在的文件是src/mind_camera.cpp
 **DoCapProcess函数定义及相关源码注释如下所示：** 

```
1.bool MindCamera::DoCapProcess() {    
2.    CameraOperationCode ret_code = PreCapProcess();    
3.    if (ret_code == kCameraSetPropertyFailed) {    
4.        CloseCamera(config_->channel_id);    
5.    
6.        ERROR_LOG("[CameraDatasets] DoCapProcess.PreCapProcess failed");    
7.        return false;    
8.    } else if((ret_code == kCameraOpenFailed) || (ret_code == kCameraNotClosed)) {    
9.    
10.        ERROR_LOG("[CameraDatasets] DoCapProcess.PreCapProcess failed");    
11.        return false;    
12.    }     
13.    
14.    // set procedure is running.    
15.    SetExitFlag(CAMERADATASETS_RUN);    
16.    
17.    bool ret = true;    
18.    int read_ret = 0;    
19.    int read_size = 0;    
20.    bool read_flag = false;    
21.    void * buffer = nullptr;    
22.    int size = config_->resolution_width * config_->resolution_height    
23.    * 3 / 2;    
24.    int numcount = 100;    
25.    while (GetExitFlag() == CAMERADATASETS_RUN) {    
26.        clock_gettime(CLOCK_REALTIME, &time1);    
27.        //    
28.        shared_ptr<FaceRecognitionInfo> p_obj = CreateBatchImageParaObj();    
29.        uint8_t* p_data = p_obj->org_img.data.get();    
30.        read_size = (int) p_obj->org_img.size;    
31.    
32.        // do read frame from camera, readSize maybe changed when called    
33.        read_ret = ReadFrameFromCamera(config_->channel_id, (void*) p_data, &read_size);    
34.    
35.        // indicates failure when readRet is 1    
36.        read_flag = ((read_ret == 1) && (read_size == (int) p_obj->org_img.size));    
37.    
38.        if (!read_flag) {    
39.            ERROR_LOG("[CameraDatasets] readFrameFromCamera failed "    
40.            "{camera:%d, ret:%d, size:%d, expectsize:%d} ",    
41.            config_->channel_id, read_ret, read_size,    
42.            (int )p_obj->org_img.size);    
43.            break;    
44.        }    
45.    
46.        //INFO_LOG("MindCamera DoCapProcess  width %d, height %d, al w %d h %d size %d\n", p_obj->org_img.width, p_obj->org_img.height, p_obj->org_img.alignWidth, p_obj->org_img.alignHeight, p_obj->org_img.size);    
47.        ResourceLoad::GetInstance().SendNextModelProcess("MindCamera", p_obj);    
48.        clock_gettime(CLOCK_REALTIME, &time2);    
49.    
50.        numcount --;    
51.    }    
52.    
53.    // close camera    
54.    CloseCamera(config_->channel_id);    
55.    
56.    if (ret != true) {    
57.        return false;    
58.    }    
59.    
60.    return true;    
61.}    
```
### 步骤 5 人脸检测模块

人脸检测模型接收到输入的图片之后，检测该图片中是否含有人脸，如果含有人脸则给出人脸的坐标信息，将这些信息传入到关键点检测模块进行推理。人脸检测模型推理模块可以分为三个部分，预处理，模型推理和后处理。
1. 人脸检测预处理，主要调用DVPP的resize接口将图片resize到模型推理需要的大小。由于人脸检测模型使用了AIPP功能，所以可以直接将resize出来的YUV图片输入到人脸检测模型。
 **预处理函数在FaceDetection::PreProcess中实现** 
Result FaceDetection::PreProcess
函数在src/face_detection.cpp文件中
 **PreProcess函数定义及相关源码注释如下所示：** 

```
1.Result FaceDetection::PreProcess(    
2.    const shared_ptr<FaceRecognitionInfo> &image_handle,    
3.    ImageData &resized_image) {    
4.    // input size is less than zero, return failed    
5.    int32_t img_size = image_handle->org_img.size;    
6.    if (img_size <= 0) {    
7.        ERROR_LOG("original image size less than or equal zero, size=%d",    
8.                    img_size);    
9.        return FAILED;    
10.    }    
11.    
12.    // call ez_dvpp to resize image    
13.    Result ret = ResourceLoad::GetInstance().GetDvpp().Resize(resized_image, image_handle->org_img, kResizeWidth, kResizeHeight);    
14.    if (ret == FAILED) {    
15.        ERROR_LOG("Resize image failed\n");    
16.        return FAILED;    
17.    }    
18.    
19.    
20.    return SUCCESS;    
21.}  
```
  

2. 模型推理，将预处理之后的图片进行人脸检测推理。
 **模型推理函数在FaceDetection::Inference中实现** 
 FaceDetection::Inference
函数在src/face_detection.cpp文件中
 **Inference 函数定义及相关源码注释如下所示：** 

```
1.Result FaceDetection::Inference(    
2.    const ImageData &resized_image,    
3.    aclmdlDataset*& detection_inference) {    
4.    
5.    Result ret = ResourceLoad::GetInstance().GetModel(1).CreateInput(resized_image.data.get(),    
6.                                    resized_image.size);    
7.    if (ret != SUCCESS) {    
8.        ERROR_LOG("Create mode input dataset failed\n");    
9.        return FAILED;    
10.    }    
11.    
12.    ret = ResourceLoad::GetInstance().GetModel(1).Execute();    
13.    if (ret != SUCCESS) {    
14.        ResourceLoad::GetInstance().GetModel(1).DestroyInput();    
15.        ERROR_LOG("Execute model inference failed\n");    
16.        return FAILED;    
17.    }    
18.    ResourceLoad::GetInstance().GetModel(1).DestroyInput();    
19.    
20.    detection_inference = ResourceLoad::GetInstance().GetModel(1).GetModelOutputData();    
21.    
22.    return SUCCESS;    
23.}    
```


3.后处理，处理模型推理之后的数据。在该模块，可以得到人脸检测的框体信息，左上和右下的坐标信息，将该数据传到关键点提取模块。
 **后处理函数在FaceDetection::PostProcess中实现** 
FaceDetection::PostProcess
函数在src/face_detection.cpp文件中
 **PostProcess函数定义及相关源码注释如下** 

```
1.Result FaceDetection::PostProcess(    
2.    shared_ptr<FaceRecognitionInfo> &image_handle,    
3.    aclmdlDataset* detection_inference) {    
4.    // inference result vector only need get first result    
5.    // because batch is fixed as 1    
6.    uint32_t dataSize = 0;    
7.    float* detectData = (float *)ResourceLoad::GetInstance().GetInferenceOutputItem(dataSize, detection_inference, kBBoxDataBufId);    
8.    
9.    if (detectData == nullptr)    
10.        return FAILED;    
11.    
12.    uint32_t width = image_handle->org_img.width;    
13.    uint32_t height = image_handle->org_img.height;    
14.    float *ptr = detectData;    
15.    for (int32_t i = 0; i < dataSize - kEachResultSize; i += kEachResultSize) {    
16.        ptr = detectData + i;    
17.    
18.    //for (uint32_t i = 0; i < totalBox; i++) {    
19.        //Point point_lt, point_rb;    
20.        uint32_t score_int = uint32_t(ptr[SCORE] * 100);    
21.        if (score_int < 70.0)    
22.            break;    
23.            
24.        // attribute    
25.        float attr = ptr[LABEL];    
26.        // confidence    
27.        float score = ptr[SCORE];    
28.    
29.        // position    
30.        FaceRectangle rectangle;    
31.        rectangle.lt.x = CorrectionRatio(ptr[TOPLEFTX]) * width;    
32.        rectangle.lt.y = CorrectionRatio(ptr[TOPLEFTY]) * height;    
33.        rectangle.rb.x = CorrectionRatio(ptr[BOTTOMRIGHTX]) * width;    
34.        rectangle.rb.y = CorrectionRatio(ptr[BOTTOMRIGHTY]) * height;       
35.        cout << "ltX " << rectangle.lt.x << "ltY " << rectangle.lt.y << "rbX " << rectangle.rb.x << "rbY " << rectangle.rb.y << endl;    
36.        // check results is invalid, skip it    
37.        if (!IsValidResults(attr, score, rectangle)) {    
38.            continue;    
39.        }    
40.    
41.        // push back to image_handle    
42.        FaceImage faceImage;    
43.        faceImage.rectangle = rectangle;    
44.        image_handle->face_imgs.emplace_back(faceImage);    
45.    }    
46.    return SUCCESS;    
47.}    

```
### 步骤 6 关键点提取模块

关键点检测模型，通过关键点提取模型推理检测出人脸的左眼、右眼、鼻子、左嘴角、右嘴角五个关键点位置信息，获得这五个关键点的作用是用来对图片中侧着的人脸进行对齐。在该模块中，接收到输入的原始图片之后调用DVPP接口先对其进行人脸的裁剪，得到裁剪后的人脸图片，再传入Resize处理到模型推理需要的尺寸再传到ImageYUV2BGR处理模块，将YUV格式转换成BGR格式。之后进行归一化处理。将归一化处理之后的图片送入到关键点提取模型进行模型推理。得到人脸中左眼、右眼、鼻子、左嘴角、右嘴角五个关键点位置信息。
为了对整体流程更清晰，代码展示实现过程，实现的流程代码如下：
 **调用代码在Result FaceFeatureMaskProcess::Process中实现** 
FaceFeatureMaskProcess::Process
函数在文件src/face_feature_mask.cpp文件中

```
1.Result FaceFeatureMaskProcess::Process(shared_ptr<FaceRecognitionInfo> &face_recognition_info)  {    
2.    
3.    if (!IsDataHandleWrong(face_recognition_info)) {    
4.        ERROR_LOG("The message status is not normal");    
5.        ResourceLoad::GetInstance().SendNextModelProcess("FaceFeatureMaskProcess",face_recognition_info);    
6.        return FAILED;    
7.    }    
8.    clock_gettime(CLOCK_REALTIME, &time1);    
9.    if (!Crop(face_recognition_info, face_recognition_info->org_img, face_recognition_info->face_imgs)) {    
10.        return SendFailed("Crop all the data failed, all the data failed",    
11.                      face_recognition_info);    
12.    }    
13.    vector<ImageData> resized_imgs;    
14.    if (!Resize(face_recognition_info->face_imgs, resized_imgs)) {    
15.        return SendFailed("Resize all the data failed, all the data failed",    
16.                      face_recognition_info);    
17.    }    
18.    vector<Mat> bgr_imgs;    
19.    if (!ImageYUV2BGR(resized_imgs, bgr_imgs)) {    
20.        return SendFailed("Convert all the data failed, all the data failed",    
21.                      face_recognition_info);    
22.    }    
23.    if (!NormalizeData(bgr_imgs)) {    
24.        return SendFailed("Normalize all the data failed, all the data failed",    
25.                      face_recognition_info);    
26.    }    
27.    // Inference the data    
28.    Result inference_flag = Inference(bgr_imgs, face_recognition_info->face_imgs);    
29.    if (!inference_flag) {    
30.        return SendFailed("Inference the data failed",    
31.                      face_recognition_info);    
32.    }    
33.    
34.    clock_gettime(CLOCK_REALTIME, &time2);    
35.    cout << "FaceFeatureMaskProcess::Process costtime is: " << (time2.tv_sec - time1.tv_sec)*1000 + (time2.tv_nsec - time1.tv_nsec)/1000000 << "ms" << endl;    
36.    
37.    return SendSuccess(face_recognition_info);    
38.}    
```
### 步骤 7 特征向量提取模块

特征向量提取模块利用关键点检测模型推理得到的五个关键点坐标对裁剪后的人脸图片进行对齐处理，最后将对齐的人脸和水平垂直翻转得到的人脸送入到特征向量提取模型推理，得到人脸特征向量，然后将该向量传入数据整理模块。特征向量提取模块的主要流程是预处理和推理。
预处理：首先调用DVPP 接口将图片resize至模型指定的尺寸；将YUV图片转成BGR图片，便于OpenCV处理；人脸对齐（Face Alignment）；人脸对齐的输入是经过裁剪的人脸图片，然后根据关键点检测模块推理所得的五个关键点的坐标对裁剪后的人脸图片进行对齐。最后将对齐的人脸送入到特征向量提取模型得到一个1024维向量（使用的特征向量是人脸图像的特征和水平垂直翻转之后的人脸图像的特征的连接向量，即512+512，故1024维度）。模型推理：将对齐之后的人脸和水平垂直翻转的图片送入模型进行推理，得到人脸特征向量。
为了对整体流程更清晰，代码展示实现过程，实现的流程代码如下：
 **调用代码在Result FaceRecognition::Process中实现** 
函数在文件src/face_recognition.cpp文件中

```
1.Result FaceRecognition::Process(    
2.    shared_ptr<FaceRecognitionInfo> &image_handle) {    
3.    string err_msg = "";    
4.    if (image_handle->err_info.err_code != AppErrorCode::kNone) {    
5.        INFO_LOG("front engine dealing failed, err_code=%d, err_msg=%s",    
6.                    image_handle->err_info.err_code,    
7.                    image_handle->err_info.err_msg.c_str());    
8.        SendResult(image_handle);    
9.        return FAILED;    
10.    }    
11.    clock_gettime(CLOCK_REALTIME, &time1);    
12.    // pre-process    
13.    vector<AlignedFace> aligned_imgs;    
14.    PreProcess(image_handle->face_imgs, aligned_imgs);    
15.    
16.    // need to inference or not    
17.    if (aligned_imgs.empty()) {    
18.    
19.        SendResult(image_handle);    
20.        return SUCCESS;    
21.    }    
22.    
23.    // inference and set results    
24.    InferenceFeatureVector(aligned_imgs, image_handle->face_imgs);    
25.    clock_gettime(CLOCK_REALTIME, &time2);    
26.    cout << "FaceRecognition::Process costtime is: " << (time2.tv_sec - time1.tv_sec)*1000 + (time2.tv_nsec - time1.tv_nsec)/1000000 << "ms" << endl;    
27.    
28.    // send result    
29.    SendResult(image_handle);    
30.    return SUCCESS;    
31.}    
```
### 步骤 8 分析样例模型推理的输出格式并解析模型推理结果

在该案例中后处理阶段是将模型推理之后所得到的数据整理之后发送到presenter sever。本案例中输入有两个来源，分别是摄像头输入和注册输入，注册和人脸识别需要做不同的处理，注册时发送到板侧的图片经过预处理和推理之后得到人脸坐标以及特征向量，之后将这些数据发送到Presenter Server侧再保存到文件中。
摄像头输入则是进行人脸识别，经过三个模型推理之后得到特征向量与注册时的特征向量作对比，当相似度达到或超过阈值时则说明是同一张人脸。二者实现的功能不同，因此后处理在输出数据的时候也会依据不同的来源进行不同的处理。如果是在人脸注册时则通过后处理将人脸框坐标以及人脸特征向量发送到Presenter Server保存成文件，而在人脸识别则除了发送人脸坐标以及特征向量还会发送原始图片至Presenter Server展示。
函数在文件src/face_post_process.cpp文件中

```
1.Result FacePostProcess::Process(const std::shared_ptr<FaceRecognitionInfo> &image_handle) {          
2.    // deal data from camera    
3.    if (image_handle->frame.image_source == 0) {    
4.        return SendFeature(image_handle);    
5.    }    
6.    // deal data from register    
7.    ReplyFeature(image_handle);    
8.    INFO_LOG( "post process dealing data from register end.");    
9.    return SUCCESS;    
10.}    
```

输入一个人脸特征，通过和注册在库中N个身份对应的特征进行逐个比对，找出一个与输入特征相似度最高的特征。将这个最高相似度值和预设的阈值相比较，如果达到或者超过阈值，则返回该特征对应的身份username，否则返回Unknow。
Presenter包含两个组件：Presenter Server（服务端）和Presnter Agent（被客户端调用），用以展示推理结果，推理结果解析后，调用Presenter Agent的接口向Presenter Server发送数据，Presenter Server接收到Presenter Agent发送的数据后，一帧一帧的展示，用户通过浏览器访问Presenter Server，可以查看到展示的结果。
本实验将模型推理的结果解析后，通过在本机部署的Presenter Server进程将检测结果可视化，利用Presenter Agent提供的API向Presenter Server推送媒体消息，Presenter Server接收Presenter Agent发过来的媒体数据，通过浏览器进行结果展示。

 **Presenter Agent 的使用方法基本如下：** 
首先创建并打开一个连接Presenter Server的通道。
发送一个包含一帧图像信息的结构体对象到Presenter Server。
 **1）打开通道的函数原型为：** 
Result OpenPresenterChannel();
函数在文件src/resource_load.cpp文件中
 **在本工程中打开通道的源码为：** 

```
1.Result ResourceLoad::OpenPresenterChannel() {    
2.    const char* configFile = "./param.conf";    
3.    map<string, string> config;    
4.    PresenterChannels::GetInstance().ReadConfig(config, configFile);    
5.    
6.    PresenterServerParams register_param;    
7.    register_param.app_type = "facial_recognition";    
8.    map<string, string>::const_iterator mIter = config.begin();    
9.    for (; mIter != config.end(); ++mIter) {    
10.        if (mIter->first == "presenter_server_ip") {    
11.            register_param.host_ip = mIter->second;    
12.        }    
13.        else if (mIter->first == "presenter_server_port") {    
14.            register_param.port = std::stoi(mIter->second);    
15.        }    
16.        else if (mIter->first == "channel_name") {    
17.            register_param.app_id = mIter->second;    
18.        }    
19.        /*else if (mIter->first == "content_type") {  
20.            register_param.app_type = mIter->second;  
21.        }*/    
22.    }    
23.    
24.    INFO_LOG("host_ip = %s,port = %d,app_name = %s,app_type %s",    
25.                  register_param.host_ip.c_str(), register_param.port,    
26.                  register_param.app_id.c_str(), register_param.app_type.c_str());    
27.    INFO_LOG("Init Presenter Channel \n");    
28.    // Init class PresenterChannels by configs    
29.    PresenterChannels::GetInstance().Init(register_param);    
30.    
31.    // create agent channel and register app    
32.    Channel *channel= PresenterChannels::GetInstance().GetChannel();    
33.    if (channel == nullptr) {    
34.        ERROR_LOG("register app failed.");    
35.        return FAILED;    
36.    }    
37.    
38.    return SUCCESS;    
39.}    
```

 **检测出的目标位置信息的定义DetectionResult 如下：** 

```
1.face_feature->mutable_box()->set_lt_x(face_imgs[i].rectangle.lt.x);  
2.        face_feature->mutable_box()->set_lt_y(face_imgs[i].rectangle.lt.y);  
3.        face_feature->mutable_box()->set_rb_x(face_imgs[i].rectangle.rb.x);  
4.        face_feature->mutable_box()->set_rb_y(face_imgs[i].rectangle.rb.y);  
```

 **检测到的特征向量** 

```
1.for (int j = 0; j < face_imgs[i].feature_vector.size(); j++) {    
2.           face_feature->add_vector(face_imgs[i].feature_vector[j]);    
3.       } 
```

后处理部分会根据当前输入时人脸注册还是摄像头输入作不同的处理：
注册时发送到板侧的图片经过预处理和推理之后得到人脸坐标以及特征向量，之后将这些数据发送到Presenter Server侧再保存到文件中。
 **Result FacePostProcess::ReplyFeature函数定义及相关源码注释如下所示：** 
函数在src/face_post_process.cpp文件中

```
1.Result FacePostProcess::ReplyFeature(    
2.    const shared_ptr<FaceRecognitionInfo> &info) {    
3.      // get channel for reply feature (data from register)    
4.    Channel *channel = PresenterChannels::GetInstance().GetChannel();    
5.    if (channel == nullptr) {    
6.        ERROR_LOG("get channel for send FaceResult failed.");    
7.        return FAILED;    
8.    }    
9.    
10.    // generate FaceResult    
11.    facial_recognition::FaceResult result;    
12.    result.set_id(info->frame.face_id);    
13.    unique_ptr<Message> resp;    
14.    INFO_LOG("FacePostProcess::ReplyFeature begin.");    
15.    // 1. front engine dealing failed, send error message    
16.    if (info->err_info.err_code != AppErrorCode::kNone) {    
17.        INFO_LOG("front engine dealing failed, reply error response to server");    
18.    
19.        result.mutable_response()->set_ret(facial_recognition::kErrorOther);    
20.        result.mutable_response()->set_message(info->err_info.err_msg);    
21.    
22.        // send    
23.        PresenterErrorCode error_code = channel->SendMessage(result, resp);    
24.        return CheckSendMessageRes(error_code);    
25.    }    
26.    // 2. dealing success, need set FaceFeature    
27.    result.mutable_response()->set_ret(facial_recognition::kErrorNone);    
28.    vector<FaceImage> face_imgs = info->face_imgs;    
29.    facial_recognition::FaceFeature *face_feature = nullptr;    
30.    for (int i = 0; i < face_imgs.size(); i++) {    
31.        // every face feature    
32.        face_feature = result.add_feature();    
33.        // box    
34.        face_feature->mutable_box()->set_lt_x(face_imgs[i].rectangle.lt.x);    
35.        face_feature->mutable_box()->set_lt_y(face_imgs[i].rectangle.lt.y);    
36.        face_feature->mutable_box()->set_rb_x(face_imgs[i].rectangle.rb.x);    
37.        face_feature->mutable_box()->set_rb_y(face_imgs[i].rectangle.rb.y);    
38.    
39.        // vector    
40.        for (int j = 0; j < face_imgs[i].feature_vector.size(); j++) {    
41.            face_feature->add_vector(face_imgs[i].feature_vector[j]);    
42.        }    
43.    }    
44.    PresenterErrorCode error_code = channel->SendMessage(result, resp);    
45.    INFO_LOG("FacePostProcess::ReplyFeature end.");    
46.    return CheckSendMessageRes(error_code);    
}   
```

摄像头输入时后处理如下：
摄像头输入则是进行人脸识别，经过三个模型推理之后得到特征向量与注册时的特征向量作对比，当相似度达到或超过阈值时则说明是同一张人脸，发送人脸坐标以及特征向量还会发送原始图片至Presenter Server展示。
 **Result FacePostProcess::SendFeature函数定义及相关源码注释如下所示：** 
函数在src/face_post_process.cpp文件中

```
1.Result FacePostProcess::SendFeature(    
2.    const shared_ptr<FaceRecognitionInfo> &info) {    
3.    // get channel for send feature (data from camera)    
4.    Channel *channel = PresenterChannels::GetInstance().GetPresenterChannel();    
5.    if (channel == nullptr) {    
6.        ERROR_LOG("get channel for send FrameInfo failed.");    
7.        return FAILED;    
8.    }    
9.    
10.    // front engine deal failed, skip this frame    
11.    if (info->err_info.err_code != AppErrorCode::kNone) {    
12.        INFO_LOG("front engine dealing failed, skip this frame, err_code=%d, err_msg=%s",    
13.        int(info->err_info.err_code), info->err_info.err_msg.c_str());    
14.        return FAILED;    
15.    }    
16.    
17.    ImageData jpgImage;    
18.    
19.    facial_recognition::FrameInfo frame_info;    
20.    if(GetOriginPic(info, jpgImage, frame_info) != SUCCESS){    
21.        info->err_info.err_code = AppErrorCode::kRecognition;    
22.        info->err_info.err_msg = "Get the original pic failed";    
23.    
24.        ERROR_LOG("Engine handle filed, err_code=%d, err_msg=%s",    
25.        int(info->err_info.err_code),    
26.        info->err_info.err_msg.c_str());    
27.    }    
28.    
29.    // 2. repeated FaceFeature    
30.    vector<FaceImage> face_imgs = info->face_imgs;    
31.    facial_recognition::FaceFeature *feature = nullptr;    
32.    for (int i = 0; i < face_imgs.size(); i++) {    
33.        // every face feature    
34.        feature = frame_info.add_feature();    
35.        // box    
36.        feature->mutable_box()->set_lt_x(face_imgs[i].rectangle.lt.x);    
37.        feature->mutable_box()->set_lt_y(face_imgs[i].rectangle.lt.y);    
38.        feature->mutable_box()->set_rb_x(face_imgs[i].rectangle.rb.x);    
39.        feature->mutable_box()->set_rb_y(face_imgs[i].rectangle.rb.y);    
40.    
41.        INFO_LOG("position is (%d,%d),(%d,%d)",face_imgs[i].rectangle.lt.x,face_imgs[i].rectangle.lt.y,face_imgs[i].rectangle.rb.x,face_imgs[i].rectangle.rb.y);    
42.    
43.        // vector    
44.        for (int j = 0; j < face_imgs[i].feature_vector.size(); j++) {    
45.            feature->add_vector(face_imgs[i].feature_vector[j]);    
46.        }    
47.    }    
48.    
49.    // send frame information to presenter server    
50.    unique_ptr<Message> resp;    
51.    PresenterErrorCode error_code;    
52.    error_code = channel->SendMessage(frame_info, resp);    
53.    
54.    return CheckSendMessageRes(error_code);    
55.    //return SUCCESS;    
56.}    
```
### 步骤 9 资源释放

 **资源释放分别在以下函数中实现：** 
函数在src/model_process.cpp文件中

```
1.void ModelProcess::DestroyResource()    
2.{    
3.    Unload();    
4.    DestroyDesc();    
5.    DestroyInput();    
6.    DestroyOutput();    
7.}    
```
