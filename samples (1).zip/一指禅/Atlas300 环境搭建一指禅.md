<!-- GFM-TOC -->
* [1. 运行环境安装](#1-运行环境安装)
* [2. 开发环境安装](#2-开发环境安装)
<!-- GFM-TOC -->





# 1 运行环境安装
运行环境即ubuntu18.04-x86的云端ai1环境（以下简称ai1环境）。此环境为华为提供的云端环境，对应设备中已经有300加速卡运行在上面了。

### 购买Ai1云端环境

1.登录华为云官网并进入购买配置界面。
华为云官网地址：https://www.huaweicloud.com。
根据网址进入网站后，注册登录华为云账号。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100114_c6dcfcfd_7380811.png "屏幕截图.png")
如下图所示，登陆后，单击控制台。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100158_ec255a90_7380811.png "屏幕截图.png")
如下图所示，进入控制台后，选择 “弹性云服务器ECS”。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100134_f3007893_7380811.png "屏幕截图.png")
如下图所示，单击 “购买弹性云服务器”，进入Ai1配置购买界面。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100224_5ff745bb_7380811.png "屏幕截图.png")

2.配置Ai1并购买。

1. 基础配置参考下列图片
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100323_b618d306_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100331_dd0d6032_7380811.png "屏幕截图.png")
2. 网络配置参考下列图片
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100358_adc1f706_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100415_7fa9c4ae_7380811.png "屏幕截图.png")
3. 高级配置参考下列图片
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100639_678db60e_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100648_61919df4_7380811.png "屏幕截图.png")
4. 确认配置操作参考下列图片
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100720_fbe69d85_7380811.png "屏幕截图.png")
5. 配置完成后，重新进入云服务器控制台
生成的弹性云服务器如下图所示。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100803_89da2622_7380811.png "屏幕截图.png")
云服务器的弹性公网ip就是云服务器的外网ip地址，如下图示所示。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100822_68d0e0da_7380811.png "屏幕截图.png")

# 连接Ai1云服务器

这里我们选择使用MobaXterm去连接Ai1云服务器。

1.在MobaXterm中新建Session。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100948_5d8734bb_7380811.png "屏幕截图.png")
2.在弹出的窗口中选择ssh连接，并进行配置，如下图所示。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/101042_7fdcadae_7380811.png "屏幕截图.png")
第一次建立连接的时候要输入Ai1 root用户的密码，root密码是申请ai1环境时高级配置中填写的密码，之后就可以直接连接。
3.连接上Ai1后，在root用户下执行如下命令，给HwHiAiUser用户设置密码。
`passwd HwHiAiUser`

```
root@ecs-bf1d:~# passwd HwHiAiUser
Enter new UNIX password:
Retype new UNIX password:
passwd: password updated successfully
root@ecs-bf1d:~#
```
### 旧版本驱动卸载

1.执行如下命令查看是否已经安装了1.32.0.0版本的驱动。
`cat /usr/local/HiAI/version.info`
如果显示如下，则表示当前环境上存在1.32.0.0版本的驱动。

```
root@ecs-bf1d:/usr/local/HiAI# cat /usr/local/HiAI/version.info
Version=V100R001C32B080
root@ecs-bf1d:/usr/local/HiAI#
```

2.执行以下命令，卸载旧版本驱动。

```
cd /usr/local/HiAI
./uninstall.sh
```
3.执行完毕后，执行以下命令重启环境。

```
reboot

```
4.重启约等待1min，重启后按ctrl+r，以root用户重新登录环境。
### ubuntu版本升级。

由于20.0.RC1版本要求ubuntu必须为18.04版本。所以需要对ubuntu版本进行升级。

1.执行以下命令，安装一些apt依赖。
执行过程中如果要求填写[Y/N]，请填写Y。

```
apt-get update
apt-get upgrade
apt dist-upgrade
apt-get install update-manager-core
```

完成后请执行以下命令重启环境。
`reboot`
重启后，使用root用户登录环境。

2.执行以下命令，升级ubuntu版本。
执行过程中如果要求填写[Y/N]，请填写Y。
`do-release-upgrade`
出现以下界面请选择 “install the package maintainer’s version”。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/103923_d9816208_7380811.png "屏幕截图.png")

安装最后，填写Y，会自动重启，重启后升级成功。

以root用户登录，执行以下命令，查询当前ubuntu版本。
cat /etc/lsb-release

```
root@ecs-bf1d:~# cat /etc/lsb-release
DISTRIB_ID=Ubuntu
DISTRIB_RELEASE=18.04
DISTRIB_CODENAME=bionic
DISTRIB_DESCRIPTION="Ubuntu 18.04.4 LTS"
```
可以看到当前版本已经升级为18.04了。

3.清理无用的安装包
```
apt-get remove

```
4.配置用户权限
执行以下命令，在root用户下打开“/etc/sudoers”文件。
```
chmod u+w /etc/sudoers
vi /etc/sudoers
```
在该文件“ # User privilege specification”下面增加如下内容：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/104024_c12ab787_7380811.png "屏幕截图.png")
其中， **HwHiAiUser** 为开发环境中普通用户用户名，需要根据自己的环境修改。

完成后，执行以下命令取消“ /etc/sudoers”文件的写权限。
` chmod u-w /etc/sudoers`
### 安装新版本驱动

安装推理卡相关驱动和固件

1.执行以下命令，查看环境中是否有Atlas300推理卡。

```
lspci | grep d100

```

```
root@ecs-bf1d:~# lspci | grep d100
00:0d.0 Processing accelerators: Huawei Technologies Co., Ltd. Device d100 (rev 20)
root@ecs-bf1d:~#
```
如上显示，证明环境中有300推理卡。
2.下载推理卡驱动和固件包
如下图，下载推理卡驱动和固件包。
下载链接：https://www.huaweicloud.com/ascend/resource/Software
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/104148_edcce61b_7380811.png "屏幕截图.png")

3.将这两个软件包上传到ai1环境的/opt目录下，执行以下命令，以root用户进入/opt目录，给软件包加执行权限。
 
```
cd /opt
chmod +x *.run 
```


```
root@ecs-bf1d:~# cd /opt/
root@ecs-bf1d:/opt# chmod +x *.run
root@ecs-bf1d:/opt# ll
total 90104
drwxr-xr-x  2 root root     4096 Jul 29 17:20 ./
drwxr-xr-x 26 root root     4096 Jul 29 16:40 ../
-rwxr-xr-x  1 root root 86440097 Jul 29 17:20 A300-3010-NPU_Driver-20.0.0-X86_64-Ubuntu18.04.run*
-rwxr-xr-x  1 root root  5812650 Jul 29 17:20 A300-3010-NPU_Firmware-1.73.5.1.b050.run*
root@ecs-bf1d:/opt#
```
4.安装驱动
执行以下命令，进行驱动安装。
 **./A300-3010-NPU_Driver-20.0.0-X86_64-Ubuntu18.04.run --full** 
安装成功后，执行以下命令，重启环境。
 **reboot** 
重启完成后，以root用户重新登陆，并执行以下命令进入/opt文件夹。
 **cd /opt** 

5.安装固件
执行以下命令，进行固件安装。
 **./A300-3010-NPU_Firmware-1.73.5.1.b050.run --full** 
安装过程中提示[y/n]，填入y。

安装成功后，执行以下命令，重启环境。
 **reboot** 
重启完成后，以root用户重新登陆。

6.检查安装
执行以下命令，检查是否安装成功。
 **npu-smi info** 
回显如下，则证明安装成功。
```
root@ecs-bf1d:~# npu-smi info
+------------------------------------------------------------------------------+
| npu-smi 20.0.0                       Version: 1.73.5.1.B050                  |
+-------------------+-----------------+----------------------------------------+
| NPU     Name      | Health          | Power(W)          Temp(C)              |
| Chip    Device    | Bus-Id          | AICore(%)         Memory-Usage(MB)     |
+===================+=================+========================================+
| 0       310       | OK              | 12.8              43                   |
| 0       0         | 0000:00:0D.0    | 0                 2457 / 8192          |
+===================+=================+========================================+
root@ecs-bf1d:~#
```

### 环境搭建

 
1.下载离线推理引擎包和实用工具包
如下图，下载运行环境所需的离线推理引擎包和实用工具包。
下载链接：https://www.huaweicloud.com/ascend/resource/Software
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/104700_64949612_7380811.png "屏幕截图.png")

2.HwHiAiUser普通用户登录云环境。
mobax新建会话，以普通用户HwHiAiUser登录ai1环境。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/104727_f1844694_7380811.png "屏幕截图.png")
执行以下命令，使用bash命令模式。
 **bash** 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/104742_3f4f26d4_7380811.png "屏幕截图.png")

3.上传软件包至ai1环境
将下载的离线推理引擎包和实用工具包上传到ai1环境中普通用户家目录下。
并执行以下命令，增加软件包的可执行权限。
`chmod +x *.run`

```
HwHiAiUser@ecs-bf1d:~$ chmod +x *.run
HwHiAiUser@ecs-bf1d:~$ ls -l
total 6456
-rwxrwxr-x 1 HwHiAiUser HwHiAiUser 5559441 Jul 29 17:48 Ascend-NNRT-20.0.0.RC1-x86_64-linux_gcc7.3.0.run
-rwxrwxr-x 1 HwHiAiUser HwHiAiUser 1030800 Jul 29 17:49 Ascend-Toolbox-20.0.0.RC1-x86_64-linux_gcc7.3.0.run
drwx------ 3 HwHiAiUser HwHiAiUser    4096 Jul 29 17:26 hdcd
d-wxr-x--- 2 HwHiAiUser HwHiAiUser    4096 Apr 10 15:15 hdc_ppc
drwx------ 3 HwHiAiUser HwHiAiUser    4096 Jul 29 17:31 ide_daemon
drwxr-x--- 2 HwHiAiUser HwHiAiUser    4096 Apr 10 15:14 profiler
HwHiAiUser@ecs-bf1d:~$
```

4.安装软件包
执行以下命令，在普通用户中安装离线推理引擎包。
 **./Ascend-NNRT-20.0.0.RC1-x86_64-linux_gcc7.3.0.run --install** 
执行以下命令，在普通用户中安装实用工具包。
 **./Ascend-Toolbox-20.0.0.RC1-x86_64-linux_gcc7.3.0.run --install** 

5.增加环境变量
由于软件包安装后，运行时需要链接libascendcl.so库，所以需要添加环境变量，保证运行时可以找到该库。

执行以下命令，在普通用户下查找libascendcl.so的绝对路径。
 **find ~ -name libascendcl.so** 
```
HwHiAiUser@ecs-bf1d:~$ find ~ -name libascendcl.so
/home/HwHiAiUser/Ascend/nnrt/20.0.0.RC1/x86_64-linux_gcc7.3.0/acllib/lib64/libascendcl.so
find: ‘/home/HwHiAiUser/hdc_ppc’: Permission denied
HwHiAiUser@ecs-bf1d:~$
```

执行以下命令，在普通用户下创建并打开.bashrc文件。
 **vi ~/.bashrc** 
将如下内容填写到配置文件中。

```
HwHiAiUser@ecs-bf1d:~$ cat ~/.bashrc
export LD_LIBRARY_PATH=$HOME/Ascend/nnrt/20.0.0.RC1/x86_64-linux_gcc7.3.0/acllib/lib64:$LD_LIBRARY_PATH
HwHiAiUser@ecs-bf1d:~$
```
填写完成后，执行以下命令，使环境变量生效。
 **source ~/.bashrc** 

6.将动态链接库路径 添加到 ldconfig 文件中。
切换到root用户下搜索 libascendcl.so 所在的路径：
 **su root
find / -name libascendcl.so** 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/110139_19121ffa_7380811.png "屏幕截图.png")

**cd /etc/ld.so.conf.d** 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/110158_bc41a26a_7380811.png "屏幕截图.png")
 **vim libc.conf** 
添加路径到此文件中
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/110243_2030d49c_7380811.png "屏幕截图.png")

添加完成后，执行  **ldconfig** 
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/110309_da8371eb_7380811.png "屏幕截图.png")

# 2 开发环境安装
开发环境即ubuntu18.04虚拟机环境（双系统也可，后面都以虚拟机做介绍），是AI代码的编译环境，主要用来做模型转换、代码编写、代码编译等操作。结合Mindstudio工具，充分体现了易操作，易安装、易使用等多种能力。

###     
我们是在普通用户下安装的，首先确保当前环境中有一个普通用户和一个root用户，如果是新建的虚拟机需要先给root用户配置密码后才可以正常登录root用户（sudo passwd root）。以下安装普通用户以ascend举例。

用户权限配置。
普通用户安装开发套件，需要有sudo权限，所以首先需要给普通用户配置权限。

切换为root用户。
`su root`

给sudoer文件配置写权限，并打开该文件。

```
chmod u+w /etc/sudoers
vi /etc/sudoers
```


在该文件“ # User privilege specification”下面增加如下内容：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/112334_f996724c_7380811.png "屏幕截图.png")

其中， **ascend** 为开发环境种普通用户用户名，需要根据自己的环境修改。

完成后，执行以下命令取消“ /etc/sudoers”文件的写权限。
` chmod u-w /etc/sudoers`
2.源配置。
由于安装过程中涉及很多apt依赖和pip依赖的安装，所以配置一个国内源是一个加快进度的好办法。

1. 配置ubuntu18.04-x86的apt清华源。
   root用户下打开apt源文件。
   `vi /etc/apt/sources.list`

将源文件内容替换为以下ubuntu18.04-x86的apt清华源。

```
root@ubuntu:/home/ascend# cat /etc/apt/sources.list
# 默认注释了源码镜像以提高 apt update 速度，如有需要可自行取消注释
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-updates main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-updates main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-backports main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-backports main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-security main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-security main restricted universe multiverse
root@ubuntu:/home/ascend# 
```
执行以下命令更新源。
 **apt-get update** 
 **说明：
如果apt-get update失败，可以试用其他的国内源https://www.cnblogs.com/dream4567/p/9690850.html。** 
2. 配置pip源（建议使用清华源或中科大源）。
执行以下命令，切换为普通用户。
 **exit** 

执行以下命令，创建后打开普通用户家目录下的.pip/pip.conf文件。

```
mkdir $HOME/.pip/
vi $HOME/.pip/pip.conf
```


将如下内容填写到pip.conf文件中。

```
ascend@ubuntu:~$ cat /home/ascend/.pip/pip.conf 
[global]
timeout = 6000
index-url = http://mirrors.aliyun.com/pypi/simple/
trusted-host = mirrors.aliyun.com
ascend@ubuntu:~$
```
3.安装相关apt依赖。
普通用户下安装，这些是开发环境中套件包所依赖的一些apt软件，都需要成功安装。
`sudo apt-get install -y gcc make cmake unzip zlib1g zlib1g-dev libsqlite3-dev openssl libssl-dev libffi-dev pciutils net-tools`

4.安装python环境。
执行以下命令，进入普通用户家目录。
 `cd $HOME`

下载python3.7.5源码包并解压。

```
wget https://www.python.org/ftp/python/3.7.5/Python-3.7.5.tgz
tar -zxvf Python-3.7.5.tgz
```


进入解压后的文件夹，执行配置、编译和安装命令。

```
cd Python-3.7.5
./configure --prefix=/usr/local/python3.7.5 --enable-shared
make -j8
sudo make install
```


执行以下命令将so拷贝到lib中，并设置软链接。

```
sudo cp /usr/local/python3.7.5/lib/libpython3.7m.so.1.0 /usr/lib
sudo ln -s /usr/local/python3.7.5/bin/python3 /usr/bin/python3.7
sudo ln -s /usr/local/python3.7.5/bin/pip3 /usr/bin/pip3.7
sudo ln -s /usr/local/python3.7.5/bin/python3 /usr/bin/python3.7.5
sudo ln -s /usr/local/python3.7.5/bin/pip3 /usr/bin/pip3.7.5
```


执行以下命令，安装环境所需的相关pip依赖。

```
pip3.7.5 install attrs psutil decorator numpy protobuf==3.11.3 scipy sympy cffi grpcio grpcio-tools requests --user

```
### 安装toolkit开发工具包

如下图，下载开发环境所需要的toolkit包。
下载链接：https://www.huaweicloud.com/ascend/resource/Software
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/112917_399ea0d9_7380811.png "屏幕截图.png")

将包放置到开发环境普通用户的$HOME目录下。
并执行以下命令，切换到普通用户的$HOME目录下。
`cd $HOME`
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/112938_4f3d92b7_7380811.png "屏幕截图.png")

执行以下命令，给run包增加可执行权限。
`chmod 755 *.run`

执行以下命令，安装toolkit包。
`./Ascend-Toolkit-20.0.0.RC1-x86_64-linux_gcc7.3.0.run --install`
### 安装mindstudio

如下图，获取最新的mindstudio工具，并安装。
下载链接：https://www.huaweicloud.com/ascend/resources/Tools/0
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/113256_95777f75_7380811.png "屏幕截图.png")
将压缩包放置到开发环境普通用户的$HOME目录下。并执行以下命令，安装Mindstudio。

```
cd $HOME
tar -zxvf mindstudio.tar.gz
cd MindStudio-ubuntu/bin
./Mindstudio.sh
```

注：运行过程中会有红字提示需要继续安装的软件包，安装完成后重新执行 **./Mindstudio.sh** 运行即可

导入设置选择 **Do not import settins** 即可。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/113323_31d0bc83_7380811.png "屏幕截图.png")

要求选择toolkit路径，选择对应路径即可（本案例为/home/ascend/Ascend/ascend-toolkit/20.0.RC1）。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/113336_07a99ab9_7380811.png "屏幕截图.png")

点击OK后，Mindstudio搭建完成。

通过以上步骤，一个基本的环境就搭建完了。


