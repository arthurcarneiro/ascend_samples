### DVPP一指禅


**初步认识DVPP**

DVPP\(Digital Vision Pre-Process\)是数字视觉预处理，可以做图片、视频的编码、解码，图片的缩放、抠图、格式转换等功能。

主要有如下功能模块:

![输入图片说明](https://images.gitee.com/uploads/images/2021/0204/174702_2b998923_5328750.png "zh-cn_image_0231893061.png")

<a name="table34246806"></a>
<table><tbody><tr id="row45298596"><td class="cellrowborder" valign="top" width="27.55102040816326%"><p id="p45307656"><a name="p45307656"></a><a name="p45307656"></a>缩略语</p>
</td>
<td class="cellrowborder" valign="top" width="39.795918367346935%"><p id="p46041549"><a name="p46041549"></a><a name="p46041549"></a>英文全名</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%"><p id="p38378011"><a name="p38378011"></a><a name="p38378011"></a>中文名称</p>
</td>
</tr>
<tr id="row9857780"><td class="cellrowborder" valign="top" width="27.55102040816326%"><p id="p60282721"><a name="p60282721"></a><a name="p60282721"></a>DVPP</p>
</td>
<td class="cellrowborder" valign="top" width="39.795918367346935%"><p id="p51062251"><a name="p51062251"></a><a name="p51062251"></a>Digital Vision Pre-Process</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%"><p id="p42401657"><a name="p42401657"></a><a name="p42401657"></a>数字视觉预处理</p>
</td>
</tr>
<tr id="row46070597"><td class="cellrowborder" valign="top" width="27.55102040816326%"><p id="p40730901"><a name="p40730901"></a><a name="p40730901"></a>VPC</p>
</td>
<td class="cellrowborder" valign="top" width="39.795918367346935%"><p id="p10868702"><a name="p10868702"></a><a name="p10868702"></a>Vision Preprocess Core</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%"><p id="p7949639"><a name="p7949639"></a><a name="p7949639"></a>视觉预处理模块</p>
</td>
</tr>
<tr id="row4437887"><td class="cellrowborder" valign="top" width="27.55102040816326%"><p id="p23924539"><a name="p23924539"></a><a name="p23924539"></a>JPEGD</p>
</td>
<td class="cellrowborder" valign="top" width="39.795918367346935%"><p id="p58839532"><a name="p58839532"></a><a name="p58839532"></a>JPEG Decode</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%"><p id="p1272826"><a name="p1272826"></a><a name="p1272826"></a>JPEG图片解码</p>
</td>
</tr>
<tr id="row11455439"><td class="cellrowborder" valign="top" width="27.55102040816326%"><p id="p55475379"><a name="p55475379"></a><a name="p55475379"></a>JPEGE</p>
</td>
<td class="cellrowborder" valign="top" width="39.795918367346935%"><p id="p64320678"><a name="p64320678"></a><a name="p64320678"></a>JPEG Encoder</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%"><p id="p42592467"><a name="p42592467"></a><a name="p42592467"></a>JPEG图片编码</p>
</td>
</tr>
<tr id="row47787886"><td class="cellrowborder" valign="top" width="27.55102040816326%"><p id="p45613538"><a name="p45613538"></a><a name="p45613538"></a>PNGD</p>
</td>
<td class="cellrowborder" valign="top" width="39.795918367346935%"><p id="p3709091"><a name="p3709091"></a><a name="p3709091"></a>Portable Network Graphics Decoder</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%"><p id="p32000920"><a name="p32000920"></a><a name="p32000920"></a>便携式网络图像格式解码</p>
</td>
</tr>
<tr id="row19572825"><td class="cellrowborder" valign="top" width="27.55102040816326%"><p id="p41895032"><a name="p41895032"></a><a name="p41895032"></a>VDEC</p>
</td>
<td class="cellrowborder" valign="top" width="39.795918367346935%"><p id="p38054464"><a name="p38054464"></a><a name="p38054464"></a>Video Decoder</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%"><p id="p62512728"><a name="p62512728"></a><a name="p62512728"></a>视频解码</p>
</td>
</tr>
<tr id="row25743641"><td class="cellrowborder" valign="top" width="27.55102040816326%"><p id="p4860205"><a name="p4860205"></a><a name="p4860205"></a>VENC</p>
</td>
<td class="cellrowborder" valign="top" width="39.795918367346935%"><p id="p58132325"><a name="p58132325"></a><a name="p58132325"></a>Video Encoder</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%"><p id="p11097898"><a name="p11097898"></a><a name="p11097898"></a>视频编码</p>
</td>
</tr>
</tbody>
</table>

**2.典型场景**

使用Acend310芯片,最典型的使用场景就是模型推理,模型推理离不开输入数据,输入数据的预处理是必须的.如下图, 描述了DVPP的视频解码和图片resize功能

![输入图片说明](https://images.gitee.com/uploads/images/2021/0204/174823_7ca40ddd_5328750.png "zh-cn_image_0231893055.png")

这是一个典型的业务流程， H264、H265视频使用DVPP的VDEC（视频解码）, VPC\(图片resize\)功能，为模型推理准备要求的数据。

**3.标准接口和sample介绍**

**3.1DVPP API文档**

Dvpp API说明参见https://support.huaweicloud.com/asdevg-c-cann/atlasdevelopment_01_0001.html 媒体数据处理 章节

Dvpp接口使用前需要申请acl资源，并填写各种资源参数。Ascend samples仓库对本仓库样例常用的dvpp接口使用进行了封装，包括resize、jpege、jpegd、vdec和venc等。

C++版本参见https://gitee.com/ascend/samples/tree/master/cplusplus/common/atlasutil

python版本参见https://gitee.com/ascend/samples/blob/master/python/common/atlas_utils/acl_dvpp.py

这些封装的公共接口仅为便于本仓库样例开发使用而封装，限定了使用场景和习惯，产品开发以原始的acl dvpp接口为准

**3.2DVPP sample说明**

Ascend samples仓库提供了dvpp的各种功能接口使用样例，参见https://gitee.com/ascend/samples/tree/master/cplusplus/level2_simple_inference/0_data_process。

**求助渠道（昇腾社区）**

可以在社区中查找解决方案或者提问题求助：

FAQ:  https://bbs.huaweicloud.com/forum/forum-1170-1.html

问题求助：https://bbs.huaweicloud.com/forum/forum-726-1.html

