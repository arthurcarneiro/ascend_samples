 **说明：宝藏三待补充，文档格式内容待优化，格式待更新** 
### Presenter Agent-Server通信一指禅


本指导（一指禅）主要是用于帮助您快速入门Presenter Agent与Presenter Server通信，这里的Presenter Agent指的是TCP通信中的客户端，一般在开发板一侧。  
- 宝藏一告诉你如何使用Python版本的Presenter Agent；  
- 宝藏二告诉你如何使用Python版本的Presenter Server；  
- 然后是一个常见问题（FAQ）。

**宝藏一 Presenter Agent For Python三步走**

**构建TCP通信的客户端对象以及连接**

**1.1接口说明**

为了清楚客户类功能特列了如下接口的说明：

类 PresenterSocketClient

构造函数参数：\_\_init\_\_\(self, server\_address, reconnectiontime=5,recvCallback=None\)

<a name="table22527890"></a>
<table><tbody><tr id="row53934008"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p6578555"><a name="p6578555"></a><a name="p6578555"></a>参数名称</p>
</td>
<td class="cellrowborder" valign="top" width="25.510204081632654%"><p id="p63100926"><a name="p63100926"></a><a name="p63100926"></a>参数说明</p>
</td>
<td class="cellrowborder" valign="top" width="11.224489795918368%"><p id="p10901353"><a name="p10901353"></a><a name="p10901353"></a>参数类型</p>
</td>
<td class="cellrowborder" valign="top" width="10.204081632653061%"><p id="p10594405"><a name="p10594405"></a><a name="p10594405"></a>默认值</p>
</td>
<td class="cellrowborder" valign="top" width="33.6734693877551%"><p id="p52840473"><a name="p52840473"></a><a name="p52840473"></a>备注</p>
</td>
</tr>
<tr id="row5802216"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p217508"><a name="p217508"></a><a name="p217508"></a>server_address</p>
</td>
<td class="cellrowborder" valign="top" width="25.510204081632654%"><p id="p17618221"><a name="p17618221"></a><a name="p17618221"></a>服务器IP地址和端口号</p>
</td>
<td class="cellrowborder" valign="top" width="11.224489795918368%"><p id="p17789802"><a name="p17789802"></a><a name="p17789802"></a>(str,int)</p>
</td>
<td class="cellrowborder" valign="top" width="10.204081632653061%"><p id="p31687876"><a name="p31687876"></a><a name="p31687876"></a>无</p>
</td>
<td class="cellrowborder" valign="top" width="33.6734693877551%"><p id="p16581154"><a name="p16581154"></a><a name="p16581154"></a>参数为元组</p>
</td>
</tr>
<tr id="row15012662"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p8066134"><a name="p8066134"></a><a name="p8066134"></a>reconnectiontime</p>
</td>
<td class="cellrowborder" valign="top" width="25.510204081632654%"><p id="p49377135"><a name="p49377135"></a><a name="p49377135"></a>重连时间(单位：秒)</p>
</td>
<td class="cellrowborder" valign="top" width="11.224489795918368%"><p id="p40124968"><a name="p40124968"></a><a name="p40124968"></a>int</p>
</td>
<td class="cellrowborder" valign="top" width="10.204081632653061%"><p id="p28896937"><a name="p28896937"></a><a name="p28896937"></a>5</p>
</td>
<td class="cellrowborder" valign="top" width="33.6734693877551%">&nbsp;&nbsp;</td>
</tr>
<tr id="row60792949"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p25281875"><a name="p25281875"></a><a name="p25281875"></a>recvCallback</p>
</td>
<td class="cellrowborder" valign="top" width="25.510204081632654%"><p id="p34566005"><a name="p34566005"></a><a name="p34566005"></a>接收数据回调</p>
</td>
<td class="cellrowborder" valign="top" width="11.224489795918368%">&nbsp;&nbsp;</td>
<td class="cellrowborder" valign="top" width="10.204081632653061%"><p id="p26712487"><a name="p26712487"></a><a name="p26712487"></a>None</p>
</td>
<td class="cellrowborder" valign="top" width="33.6734693877551%"><p id="p16227847"><a name="p16227847"></a><a name="p16227847"></a>接收服务器发送的数据</p>
</td>
</tr>
</tbody>
</table>

连接服务器：start\_connect\(self\) 返回值类型：无

发送数据参数：send\_data\(self, data\)返回值类型：无

<a name="table31767774"></a>
<table><tbody><tr id="row53247746"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p18100201"><a name="p18100201"></a><a name="p18100201"></a>参数名称</p>
</td>
<td class="cellrowborder" valign="top" width="25.510204081632654%"><p id="p56830139"><a name="p56830139"></a><a name="p56830139"></a>参数说明</p>
</td>
<td class="cellrowborder" valign="top" width="11.224489795918368%"><p id="p39838562"><a name="p39838562"></a><a name="p39838562"></a>参数类型</p>
</td>
<td class="cellrowborder" valign="top" width="10.204081632653061%"><p id="p5698118"><a name="p5698118"></a><a name="p5698118"></a>默认值</p>
</td>
<td class="cellrowborder" valign="top" width="33.6734693877551%"><p id="p58894414"><a name="p58894414"></a><a name="p58894414"></a>备注</p>
</td>
</tr>
<tr id="row60287683"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p51464189"><a name="p51464189"></a><a name="p51464189"></a>data</p>
</td>
<td class="cellrowborder" valign="top" width="25.510204081632654%"><p id="p7849808"><a name="p7849808"></a><a name="p7849808"></a>要发送的数据</p>
</td>
<td class="cellrowborder" valign="top" width="11.224489795918368%"><p id="p31854691"><a name="p31854691"></a><a name="p31854691"></a>bytes</p>
</td>
<td class="cellrowborder" valign="top" width="10.204081632653061%"><p id="p30093150"><a name="p30093150"></a><a name="p30093150"></a>无</p>
</td>
<td class="cellrowborder" valign="top" width="33.6734693877551%">&nbsp;&nbsp;</td>
</tr>
</tbody>
</table>

关闭连接：close\(self\)返回值类型：无

传输数据结构说明

类 ChannelManager

打开通道：OpenChannel\(self, channel\_name='video', content\_type=1\)返回值类型：bytes

<a name="table53989823"></a>
<table><tbody><tr id="row66889567"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p49345813"><a name="p49345813"></a><a name="p49345813"></a>参数名称</p>
</td>
<td class="cellrowborder" valign="top" width="25.510204081632654%"><p id="p37587916"><a name="p37587916"></a><a name="p37587916"></a>参数说明</p>
</td>
<td class="cellrowborder" valign="top" width="11.224489795918368%"><p id="p24722347"><a name="p24722347"></a><a name="p24722347"></a>参数类型</p>
</td>
<td class="cellrowborder" valign="top" width="10.204081632653061%"><p id="p56353115"><a name="p56353115"></a><a name="p56353115"></a>默认值</p>
</td>
<td class="cellrowborder" valign="top" width="33.6734693877551%"><p id="p1199620"><a name="p1199620"></a><a name="p1199620"></a>备注</p>
</td>
</tr>
<tr id="row10796581"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p2107829"><a name="p2107829"></a><a name="p2107829"></a>channel_name</p>
</td>
<td class="cellrowborder" valign="top" width="25.510204081632654%"><p id="p36516433"><a name="p36516433"></a><a name="p36516433"></a>通道名称</p>
</td>
<td class="cellrowborder" valign="top" width="11.224489795918368%"><p id="p5041122"><a name="p5041122"></a><a name="p5041122"></a>str</p>
</td>
<td class="cellrowborder" valign="top" width="10.204081632653061%"><p id="p5677776"><a name="p5677776"></a><a name="p5677776"></a>video</p>
</td>
<td class="cellrowborder" valign="top" width="33.6734693877551%"><p id="p57246722"><a name="p57246722"></a><a name="p57246722"></a>image或者video</p>
</td>
</tr>
<tr id="row45458457"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p58256364"><a name="p58256364"></a><a name="p58256364"></a>content_type</p>
</td>
<td class="cellrowborder" valign="top" width="25.510204081632654%"><p id="p21145081"><a name="p21145081"></a><a name="p21145081"></a>内容类型</p>
</td>
<td class="cellrowborder" valign="top" width="11.224489795918368%"><p id="p35029990"><a name="p35029990"></a><a name="p35029990"></a>int</p>
</td>
<td class="cellrowborder" valign="top" width="10.204081632653061%"><p id="p18856923"><a name="p18856923"></a><a name="p18856923"></a>1</p>
</td>
<td class="cellrowborder" valign="top" width="33.6734693877551%"><p id="p51015809"><a name="p51015809"></a><a name="p51015809"></a>kChannelContentTypeImage = 0;</p>
<p id="p56489102"><a name="p56489102"></a><a name="p56489102"></a>kChannelContentTypeVideo = 1;</p>
</td>
</tr>
</tbody>
</table>

打包数据：PackRequestData\(self, image\_frame\)返回值类型：bytes

<a name="table32787233"></a>
<table><tbody><tr id="row61821327"><td class="cellrowborder" valign="top" width="19.587628865979383%"><p id="p41471619"><a name="p41471619"></a><a name="p41471619"></a>参数名称</p>
</td>
<td class="cellrowborder" valign="top" width="24.742268041237114%"><p id="p3757979"><a name="p3757979"></a><a name="p3757979"></a>参数说明</p>
</td>
<td class="cellrowborder" valign="top" width="13.402061855670103%"><p id="p35960896"><a name="p35960896"></a><a name="p35960896"></a>参数类型</p>
</td>
<td class="cellrowborder" valign="top" width="9.278350515463918%"><p id="p27151449"><a name="p27151449"></a><a name="p27151449"></a>默认值</p>
</td>
<td class="cellrowborder" valign="top" width="32.98969072164948%"><p id="p51783759"><a name="p51783759"></a><a name="p51783759"></a>备注</p>
</td>
</tr>
<tr id="row63400648"><td class="cellrowborder" valign="top" width="19.587628865979383%"><p id="p35178835"><a name="p35178835"></a><a name="p35178835"></a>image_frame</p>
</td>
<td class="cellrowborder" valign="top" width="24.742268041237114%"><p id="p30913391"><a name="p30913391"></a><a name="p30913391"></a>图像信息结构图</p>
</td>
<td class="cellrowborder" valign="top" width="13.402061855670103%"><p id="p20956739"><a name="p20956739"></a><a name="p20956739"></a>imageframe</p>
</td>
<td class="cellrowborder" valign="top" width="9.278350515463918%"><p id="p19774328"><a name="p19774328"></a><a name="p19774328"></a>无</p>
</td>
<td class="cellrowborder" valign="top" width="32.98969072164948%">&nbsp;&nbsp;</td>
</tr>
</tbody>
</table>

ImageFrame结构体参数

<a name="table33132859"></a>
<table><tbody><tr id="row9643552"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p42930272"><a name="p42930272"></a><a name="p42930272"></a>参数名称</p>
</td>
<td class="cellrowborder" valign="top" width="24.489795918367346%"><p id="p54800025"><a name="p54800025"></a><a name="p54800025"></a>参数说明</p>
</td>
<td class="cellrowborder" valign="top" width="14.285714285714285%"><p id="p9617010"><a name="p9617010"></a><a name="p9617010"></a>参数类型</p>
</td>
<td class="cellrowborder" valign="top" width="9.183673469387756%"><p id="p40780307"><a name="p40780307"></a><a name="p40780307"></a>默认值</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%"><p id="p14870565"><a name="p14870565"></a><a name="p14870565"></a>备注</p>
</td>
</tr>
<tr id="row66726223"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p36115021"><a name="p36115021"></a><a name="p36115021"></a>format</p>
</td>
<td class="cellrowborder" valign="top" width="24.489795918367346%"><p id="p39635599"><a name="p39635599"></a><a name="p39635599"></a>格式</p>
</td>
<td class="cellrowborder" valign="top" width="14.285714285714285%"><p id="p56366974"><a name="p56366974"></a><a name="p56366974"></a>ContentType</p>
</td>
<td class="cellrowborder" valign="top" width="9.183673469387756%"><p id="p2322177"><a name="p2322177"></a><a name="p2322177"></a>0</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%"><p id="p53878657"><a name="p53878657"></a><a name="p53878657"></a>0图像1视频</p>
</td>
</tr>
<tr id="row15145867"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p18855696"><a name="p18855696"></a><a name="p18855696"></a>width</p>
</td>
<td class="cellrowborder" valign="top" width="24.489795918367346%"><p id="p50916422"><a name="p50916422"></a><a name="p50916422"></a>图像宽</p>
</td>
<td class="cellrowborder" valign="top" width="14.285714285714285%"><p id="p30589524"><a name="p30589524"></a><a name="p30589524"></a>int</p>
</td>
<td class="cellrowborder" valign="top" width="9.183673469387756%"><p id="p61832419"><a name="p61832419"></a><a name="p61832419"></a>0</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%">&nbsp;&nbsp;</td>
</tr>
<tr id="row45786357"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p17707452"><a name="p17707452"></a><a name="p17707452"></a>height</p>
</td>
<td class="cellrowborder" valign="top" width="24.489795918367346%"><p id="p25017536"><a name="p25017536"></a><a name="p25017536"></a>图像高</p>
</td>
<td class="cellrowborder" valign="top" width="14.285714285714285%"><p id="p13154536"><a name="p13154536"></a><a name="p13154536"></a>int</p>
</td>
<td class="cellrowborder" valign="top" width="9.183673469387756%"><p id="p58884509"><a name="p58884509"></a><a name="p58884509"></a>0</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%">&nbsp;&nbsp;</td>
</tr>
<tr id="row44243194"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p26928941"><a name="p26928941"></a><a name="p26928941"></a>size</p>
</td>
<td class="cellrowborder" valign="top" width="24.489795918367346%"><p id="p33760584"><a name="p33760584"></a><a name="p33760584"></a>图像大小</p>
</td>
<td class="cellrowborder" valign="top" width="14.285714285714285%"><p id="p50252788"><a name="p50252788"></a><a name="p50252788"></a>int</p>
</td>
<td class="cellrowborder" valign="top" width="9.183673469387756%"><p id="p43944024"><a name="p43944024"></a><a name="p43944024"></a>0</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%"><p id="p2696221"><a name="p2696221"></a><a name="p2696221"></a>暂时未用上，可以不用赋值</p>
</td>
</tr>
<tr id="row24265995"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p19388612"><a name="p19388612"></a><a name="p19388612"></a>data</p>
</td>
<td class="cellrowborder" valign="top" width="24.489795918367346%"><p id="p26973745"><a name="p26973745"></a><a name="p26973745"></a>图像数据</p>
</td>
<td class="cellrowborder" valign="top" width="14.285714285714285%"><p id="p37389755"><a name="p37389755"></a><a name="p37389755"></a>bytes</p>
</td>
<td class="cellrowborder" valign="top" width="9.183673469387756%">&nbsp;&nbsp;</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%">&nbsp;&nbsp;</td>
</tr>
<tr id="row13148517"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p58396974"><a name="p58396974"></a><a name="p58396974"></a>detection_results</p>
</td>
<td class="cellrowborder" valign="top" width="24.489795918367346%"><p id="p32534423"><a name="p32534423"></a><a name="p32534423"></a>边框位置信息列表</p>
</td>
<td class="cellrowborder" valign="top" width="14.285714285714285%"><p id="p18042568"><a name="p18042568"></a><a name="p18042568"></a>list</p>
</td>
<td class="cellrowborder" valign="top" width="9.183673469387756%"><p id="p52161898"><a name="p52161898"></a><a name="p52161898"></a>[]</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%">&nbsp;&nbsp;</td>
</tr>
</tbody>
</table>

DetectionResult结构体参数

<a name="table61772230"></a>
<table><tbody><tr id="row54340131"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p39474480"><a name="p39474480"></a><a name="p39474480"></a>参数名称</p>
</td>
<td class="cellrowborder" valign="top" width="24.489795918367346%"><p id="p43316293"><a name="p43316293"></a><a name="p43316293"></a>参数说明</p>
</td>
<td class="cellrowborder" valign="top" width="14.285714285714285%"><p id="p18958859"><a name="p18958859"></a><a name="p18958859"></a>参数类型</p>
</td>
<td class="cellrowborder" valign="top" width="9.183673469387756%"><p id="p59272617"><a name="p59272617"></a><a name="p59272617"></a>默认值</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%"><p id="p36352712"><a name="p36352712"></a><a name="p36352712"></a>备注</p>
</td>
</tr>
<tr id="row58738960"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p60235282"><a name="p60235282"></a><a name="p60235282"></a>lt</p>
</td>
<td class="cellrowborder" valign="top" width="24.489795918367346%"><p id="p47219689"><a name="p47219689"></a><a name="p47219689"></a>左上角坐标</p>
</td>
<td class="cellrowborder" valign="top" width="14.285714285714285%"><p id="p66698493"><a name="p66698493"></a><a name="p66698493"></a>Point</p>
</td>
<td class="cellrowborder" valign="top" width="9.183673469387756%"><p id="p33868853"><a name="p33868853"></a><a name="p33868853"></a>(0,0)</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%">&nbsp;&nbsp;</td>
</tr>
<tr id="row61441228"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p10683599"><a name="p10683599"></a><a name="p10683599"></a>rb</p>
</td>
<td class="cellrowborder" valign="top" width="24.489795918367346%"><p id="p60065170"><a name="p60065170"></a><a name="p60065170"></a>右下角坐标</p>
</td>
<td class="cellrowborder" valign="top" width="14.285714285714285%"><p id="p33440573"><a name="p33440573"></a><a name="p33440573"></a>Point</p>
</td>
<td class="cellrowborder" valign="top" width="9.183673469387756%"><p id="p24331897"><a name="p24331897"></a><a name="p24331897"></a>(0,0)</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%">&nbsp;&nbsp;</td>
</tr>
<tr id="row21213148"><td class="cellrowborder" valign="top" width="19.387755102040817%"><p id="p40543448"><a name="p40543448"></a><a name="p40543448"></a>Result_text</p>
</td>
<td class="cellrowborder" valign="top" width="24.489795918367346%"><p id="p62793889"><a name="p62793889"></a><a name="p62793889"></a>文本信息</p>
</td>
<td class="cellrowborder" valign="top" width="14.285714285714285%"><p id="p53140254"><a name="p53140254"></a><a name="p53140254"></a>str</p>
</td>
<td class="cellrowborder" valign="top" width="9.183673469387756%"><p id="p9393336"><a name="p9393336"></a><a name="p9393336"></a>“”</p>
</td>
<td class="cellrowborder" valign="top" width="32.6530612244898%">&nbsp;&nbsp;</td>
</tr>
</tbody>
</table>

1.2构建客户端对象

使用PresenterSocketClient类直接可以构建客户端对象，传递服务器IP地址和端口号、重连次数、以及接受数据回调的参数即可，然后建立连接，这里注意连接需要开启线程连接，否则会阻塞下面代码的执行，为了有充分建立连接的时间，需要在线程开启后延时一定时间，以下是简单的示例：

import PresenterSocketClient

import time

def recvdata\(data\):

print\(data\)

psc = PresenterSocketClient\(\("192.168.1.246", 7006\), 5, recvdata\)

threading.Thread\(target=psc.start\_connect\).start\(\)

time.sleep\(0.1\)

**代码解读** 上述先定义一个回调函数，然后新建客户端对象，并与Presenter Server连接，最后延时100ms，注意客户端连接前需要先打开Presenter Server，就是服务器开启。客户端才能连接。比如腾讯服务器不开启，你的QQ就不能登录是一个道理。

**和Presenter Server进行第一次握手，建立传输通道**

和Presenter Server正式数据通信之前需要建立一个握手，告诉Server端我俩初次见面，请多关照。如果不事先和Server打招呼，则Server端认为咱们不是“一伙的”，不会进行通信，即客户端发送任何数据，Server端都不会理睬。为了能够正常通信我们进行握手机制分为如下步骤：

（1）和服务器建立连接

（2）打开通道返回通道信息

（3）发送通道信息

（4）正式建立通信

以下是简单的示例：

channel\_manager = ChannelManager.ChannelManager\(\)

data = channel\_manager.OpenChannel\(\)

psc.send\_data\(data\)

**代码解读** 首先我们构建通道管理器类对象，然后调用OpenChannel打开通道返回一个通道数据，数据类型为bytes。Psc就是1.2节中构建的客户端对象，我们只需要调用send\_data即可完成第一次握手。

**和Presenter Server进行数据通信**

和Presenter Server通信。可以分为3个步骤：

1.  填充Image\_Frame结构体参数，结构体参数具体在1.1小结已经给出，请参考
2.  打包结构体数据 （3）发送数据

以下是简单的示例：

image\_data = b'' \#图像数据

with open\('test.jpg', mode='rb'\) as f: \#打开文件

image\_data = f.read\(\)\#读取文件

image\_frame = ImageFrame\(\) \#新建结构体对象

image\_frame.format = 0 \#Jpeg格式,0表示为Jpeg格式，目前Presenter Server只接收Jpeg图片

image\_frame.width = 300 \#图像宽

image\_frame.height = 200 \#图像高

image\_frame.data = image\_data \# 图形bytes数据

image\_frame.size = 0 \#为了与C++版本一样，这个参数保留，没有用上，赋值为0即可

dr= DetectionResult\(\) \# BOX1信息

dr.lt.x = 10 \# 左上角X

dr.lt.y = 10 \# 左上角Y

dr.rb.x = 100 \# 右上角X

dr.rb.y = 100 \# 右上角Y

dr.result\_text = 'hello!' \# BOX1文本信息

image\_frame.detection\_results.append\(dr\) \# 填充到image\_frame结构体中

dr= DetectionResult\(\)\# BOX2信息

dr.lt.x = 20 \# 左上角X

dr.lt.y = 20 \# 左上角Y

dr.rb.x = 200 \# 右上角X

dr.rb.y = 200 \# 右上角Y

dr.result\_text = 'world' \# BOX2文本信息

image\_frame.detection\_results.append\(dr\)\# 填充到image\_frame结构体中

all\_data = channel\_manager.PackRequestData\(image\_frame\)\#打包结构体数据

psc.send\_data\(data\) \#发送数据

**代码解读** 首先我们读取了一张图片，并赋值给image\_data，这里作为示例只是读取一张图片，如果是从摄像头还需要自己转成JPEG图像数据。然后构建通Image\_Frame类对象，依次填写我们要发送的图像信息。如图像的大小、宽高、数据以及需要画框的信息以及画框上的文本信息，数据类型为bytes。Psc就是1.2节中构建的客户端对象，我们只需要调用send\_data即可完成一次数据通信。

**宝藏二 Presenter Server核心解读和回传数据**

本部分将为大家讲解Presenter Server核心接收数据和发送数据规则，由于官方已经提供完成的代码，这里我们解读一下，让大家更加了解Server端的工作机制。然而官方并未给我们提供一个回传数据的案例，本部分，我们通过一个具体示例看看如何传输数据到客户端。

**接口说明**

接口说明以sample-facedetection项目的Presenter Server文件里面的函数为准。我们先简单看下Presenter Server的源代码结构：

├─common

├─app\_manager.py

├─channel\_handler.py

├─channel\_manager.py

├─parameter\_validation.py

├─presenter\_pb2.py

├─presenter\_socket\_server.py

├─display

├─config

├─config.conf

├─looging.conf

├─src

├─config\_parser.py

├─display\_server.py

├─web.py

├─ui 网页部分

├─static

├─css

├─images

├─js

├─templates   临时文件夹

├─test测试文件

├─test\_app\_manager.py

├─test\_channel\_handler.py

├─test\_channel\_manager.py

├─test\_presenter\_server.py

├─test\_presenter\_socket\_server.py

├─prepare\_presenter\_server.sh 部署脚本，负责写入IP配置文件。

├─presenter\_server.py   调用入口

├─requirement   包含使用的python,protobuf,tornado版本

我们的重点接口都在common文件夹下面，下面是具体接口说明：

Common/app\_manager.py

1.  App类

    用来响应presenter\_agent请求的对象

    \_\_init\_\_\(self,app\_id,conn=None\)

    功能：初始化参数

    详细：无

    输入：id，socket

    输出：无

2.  AppManger类

包含了实际处理响应处理的方法

\_\_init\_\_\(self\)

功能：初始化

详细：无

输入：无

输出：无

\_\_new\_\_\(self\)

功能：初始化

详细：只初始化一次，产生一个使用对象

输入：无

输出：无

\_create\_thread\(cls\)

功能：开启线程

详细：以函数\_app\_thread开启线程

输入：无

输出：无

\_app\_thread\(cls\)

功能：线程函数

详细：每隔一秒检测所有App的心跳时间与当前时间之差是否小于心跳设置时间，超过则删除

输入：无

输出：无

set\_thread\_switch\(self\)

功能：停止\_app\_thread线程

详细：无

输入：无

输出：无

register\_app\(self,app,id,socket\)

功能：添加新的App

详细：如果id重复则失败，否则成功

输入：id，socket

输出：成功返回true，失败返回false

unregister\_app\(self,sock\_fileno\)

功能：通过socket去除App

详细：无

输入：socket

输出：无

get\_socket\_by\_app\_id\(self,app\_id\)

功能：通过id获得App的socket

详细：无

输入：app\_id

输出：找到对象返回socket没有返回None

get\_app\_id\_by\_socket\(self,sock\_fd\)

功能：通过socket获得App

详细：无

输入：socket

输出：找到对象返回App\_id没有返回None

is\_app\_exist\(self,app\_id\)

功能：判断App是否存在

详细：无

输入：id

输出：找到返回true，未找到返回false

get\_app\_num\(self\)

功能：获取App个数

详细：无

输入：无

输出：个数

set\_heartbeat\(self,sock\_fileno\)

功能：设置心跳值

详细：将对应socket接口的心跳值设为当前时间（刷新）

输入：socket

输出：无

increase\_frame\_num\(self,app\_id,channel\_id\)

功能：将channel添加到App中

详细：同一个channel可以添加多次

输入：app\_id,channel\_id

输出：无

get\_frame\_num\(aeld,app\_id,channel\_id\)

功能：获得App中？特定channel的个数

详细：无

输入：app\_id,channel\_id

输出：无

list\_app\(self\)

功能：获得App列表

详细：无

输入：无

输出：App列表

common/channel\_handler.py

1.  ThreadEvent类

    包装了线程同步机制

    包含一个线程标识和时间的字典event和timeout超时时间

    wait\(self\)

    功能：阻塞

    详细：当前线程阻塞，等待set，或者超时

    输入：无

    输出：无

    set\(self\)

    功能：释放

    详细：释放当前所有阻塞线程，如果释放超过5秒，则从字典删除

    输入：无

    输出：无

    clear\(self\)

    功能：清除

    详细：删除字典里所有值

    输入：无

    输出：无

2.  ChannelHandler类

close\_thread\(self\)

功能：关闭当前线程

详细：无

输入：无

输出：无

set\_heartbeat\(self\)

功能：设置心跳

详细：设置心跳为当前时间

输入：无

输出：无

set\_thread\_switch\(self\)

功能：设置关闭线程标志

详细：设置关闭线程标志为true

输入：无

输出：无

save\_image\(self,data,width,height,rectangle\_list\)

功能：保存图片数据

详细：如果是视频模式，则只保留一秒以内的图片，同时写入fps

输入：图片，宽，高，框

输出：无

get\_image\(self\)

功能：获取数据格式

详细：区别是图片和视频

输入：无

输出：数据格式

\_create\_thread\(self\)

功能：创建线程

详细：只创建一次线程，线程为\_video\_thread

输入：无

输出：无

get\_frame\(self\)

功能：获取数据

详细：等待web响应，返回数据，超时返回None

输入：无

输出：图片迭代器，fps，宽，高，框

frames\(self\)

功能：获取图片

详细：迭代器，等待图片响应，超时或者退出时返回None

输入：无

输出：图片

\_video\_thread\(self\)

功能：视频线程

详细：从frames获取图片，然后通过get\_frame传输给web端

输入：无

输出：无

common/channel\_manager.py

1.  ChannelResource类
2.  ChannelFd类
3.  Channel类
4.  ChannelManager类

只创建一次，channel工具类

所有函数都加同步锁，保证不会同时运行

\_register\_channel\_fd\(self,sock\_fileno,channel\_name\)

功能：创建fd对象连接handler和channel

详细：删除原先fd的socket接口

输入：socket接口，channel名

输出：无

create\_channel\_resource\(self,channel\_name,channel\_fd,media\_type,handler\)

功能：创建channel的资源对象，包含所有需要使用的资源

详细：根本方法

输入：channel名，fd对象，数据格式，handler

输出：无

\_clean\_channel\_resource\(self,channel\_name\)

功能：清理channel的资源对象

详细：根本方法

输入：channel名

输出：无

clean\_channel\_resource\_by\_fd\(sock\_fileno\)

功能：清理channel的资源对象

详细：通过socket接口找到name后调用\_clean\_channel\_resource

输入：socket接口

输出：handler

get\_channel\_resource\_by\_fd\(sock\_fileno\)

功能：通过socket接口找到handler

详细：无

输入：socket接口

输出：handler

is\_channel\_busy\(self,channel\_name\)

功能：判断channel是正在被使用

详细：无

输入：channel名

输出：忙为true，空闲为false

close\_all\_thread\(self\)

功能：关闭所有channel

详细：无

输入：无

输出：无

get\_channel\_hanndler\_by\_name\(self,channel\_name\)

功能：根据名称找到handler

详细：无

输入：channel名

输出：对应的handler

list\_channels\(self\)

功能：返回所有channel组成的列表

详细：无

输入：无

输出：所有channel组成的列表

register\_one\_channel\(self,channel\_name\)

功能：根据名称创建channel

详细：无

输入：channel名

输出：无

unregister\_one\_channel\(self,channel\_name\)

功能：根据名称删除channel

详细：判断channel是否重名，判断长度是否小于10

输入：channel名

输出：返回是否成功标志

is\_channel\_exist\(self,channel\_name\)

功能：判断channel是否存在

详细：无

输入：channel名

输出：存在为true，不存在为false

save\_channel\_image\(self,channel\_name,image\_data,rectangle\_list\)

功能：写入channel的图片

详细：需要channel\_list有channel，没有情况下不做任何操作

输入：channel名称，图片，框

输出：无

get\_channel\_image\(self,channel\_name\)

功能：获取channel的图片

详细：无

输入：channel名称

输出：channel的图片，未找到返回None

get\_channel\_image\_with\_rectangle\(self,channel\_name\)

功能：获取channel的图片和框

详细：无

输入：channel名称

输出：channel的图片和框，未找到返回None

clean\_channel\_image\(self,channel\_name\)

功能：删除channel

详细：将channel\_list中的对应项置None

输入：channel名称

输出：无

common/parameter\_validation.py

1.validate\_ip\(ip\_str\)

功能：判断ip是否合法

输入：str格式ip

输出：合法为true，不合法为false

2.validate\_port\(ip\_str\)

功能：判断ip是否合法

详细：port需在\[1024,49151\]之间

输入：str格式port

输出：合法为true，不合法为false

3.validate\_integer\(value\_str,begin.,end\)

功能：判断整数是否合法

详细：value需在\[begin,end\]之间

输入：str格式整数

输出：合法为true，不合法为false

3.validate\_greater\(value\_str,compared\_value\)

功能：判断整数是否大于给定值

详细：value需大于等于compared\_value

输入：str格式value

输出：合法为true，不合法为false

4.validate\_float\(value\_str,begin.,end\)

功能：判断浮点数是否合法

详细：value需在\[begin,end\]之间

输入：str格式value

输出：合法为true，不合法为false

common/presenter\_socket\_server.py

PresenterSocketServer类

1.  \_\_init\_\_\(self,server\_address\)

    功能：创建对象

    详细：调用\_create\_socket\_server

    输入：服务器地址

    输出：无

2.  \_create\_socket\_server\(self,server\_address\)

    功能：创建socket服务器

    详细：打开端口，并开启\_server\_listen\_thread线程监听端口

    输入：服务器地址

    输出：无

3.  set\_exit\_switch\(self\)

    功能：设置结束标志

    详细：将结束标志位值True，通知线程结束

    输入：无

    输出：无

4.  \_read\_socket\(self,conn,read\_len\)

    功能：读取数据

    详细：从socket读取read\_len长度数据，成功标志位位true，否则为false

    输入：socket连接，读取长度

    输出：标志位和数据流

5.  \_read\_msg\_head\(self,sock\_fileno,coons\)

    功能：读取消息头

    详细：读取特定socket接口的数据，根据消息头长度获得名称长度和数据总长度

    输入：socket描述符，连接列表

    输出：数组总长度，名称长度

6.  \_read\_msg\_name\(self,sock\_fileno,coons,msg\_name\_len\)

    功能：读取消息名

    详细：读取特定socket接口的数据，根据名称长度读取名称，成功标志位为true，失败为false

    输入：socket描述符，连接列表，名称长度

    输出：标志位，名称

7.  \_read\_msg\_body\(self,sock\_fileno,coons,msg\_body\_len,msgs\)

    功能：读取消息体

    详细：读取特定socket接口的数据，根据数据体长度读取数据，并保存到msgs\[sock\_fileno\]里

    输入：socket描述符，连接列表，名称长度，数据列表

    输出：标志位（成功标志位为true，失败为false）

8.  \_read\_sock\_and\_process\_msg\(self,sock\_fileno,coons,msgs\)

    功能：读取消息并发送

    详细：分别调用5,6,7,8函数读取数据

    输入：socket描述符，连接列表，数据列表

    输出：标志位（成功标志位为true，失败为false）

9.  \_process\_epollin\(self.sock\_fileno,coons,msgs\)

    功能：读取消息事件回调函数

    详细：调用\_read\_sock\_and\_process\_msg，失败则调用清除连接

    输入：socket描述符，连接列表，数据列表

    输出：无

10. \_accept\_new\_socket\(self,epoll,conns\)

    功能：确认新的socket连接

    详细：尝试连接socket接口，把socket描述符添加到epoll，把连接添加到列表

    输入：对应连接的标号，连接列表

    输出：无

11. \_server\_listien\_thread\(self\)

    功能：服务器监听线程

    详细：调用9,10函数

    输入：无

    输出：无

12. \_process\_heartbeat\(self,conn\)

    功能：处理心跳

    详细：用socket描述符找到特定接口

    输入：socket连接

    输出：ture

13. \_process\_open\_channe\(self,conn,msg\_data\)

    功能：处理打开channel消息

    详细：用socket描述符找到特定接口，寻找channel之后调用\_response\_open\_channel

    输入：socket连接,要发送的消息

    输出：错误标识符

14. \_response\_open\_channel\(self,conn，channel\_name,reponse,err\_code\)

    功能：回复打开channel消息

    详细：对特定channel，调用send\_message回复消息

    输入：socket连接

    输出：错误标识符

15. send\_message\(self,conn,protobuf,msg\_name\)

功能：发送消息

详细：把全部数据二进制化，添加长度信息，发送数据

输入：socket连接，要发送的数据，数据名称

输出：无

display/src/config\_parser.py

1.  ConfigParser类 

只创建一次

从配置文件config/config.conf中获取web\_server和presenter\_server的ip和port参数

config\_verify\(self\)

功能：判断ip和port是否合法

详细：无

输入：无

输出：合法为true，非法为false

config\_parser\(cls\)

功能：从config/config.conf里获取ip和port，保存到类变量里

详细：无

输入：无

输出：无

2.get\_rootpath函数

功能：返回程序根目录

详细：无

输入：无

输出：根目录路径

display/src/display\_server.py

1.  DisplayServer类

从PresenterSocketServer类继承

\_\_init\_\_\(self.server\_address\)

功能：初始化

详细：创建channel\_manager，调用PresenterSocketServer类初始化

输入：无

输出：无

\_clean\_connect\(self,sock\_fileno,epoll,conns,msgs\)

功能：关闭连接

详细：调用channel\_manager关闭连接，从socket列表，消息列表删除对应项

输入：sock标识，epoll，socket列表，消息列表

输出：无

\_process\_msg\(self,conn,msg\_name,mag\_data\)

功能：发送消息

详细：根据消息类型（打开channel回应，数据接收回应，心跳消息回应）调用不同的方法

输入：socket，消息名称，消息体

输出：消息成功发送为true，失败为false

\_response\_image\_request\(self,conn,response,err\_code\)

功能：图片接收回复

详细：根据错误代码，添加错误消息

输入：socket，回应，错误代码

输出：消息成功发送为true，失败为false

\_process\_image\_request\(self,conn,msg\_data\)

功能：图片接收处理

详细：从消息体力接收数据，保存，并调用\_response\_image\_request回复消息

输入：socket，消息体

输出：消息成功发送为true，失败为false

stop\_thread\(self\)

功能：停止线程

详细：无

输入：无

输出：无

run\(\)函数

Presenter服务器入口，负责监听agent发过来的数据

首先用ConfigParser解析ip和port，之后将这些参数传给DisplayServer，创建对象

display/src/web.py

1.  WebApp类

    \_\_init\_\_\(self\)

    功能：初始化

    详细：引用一个channel\_manager，创建一个请求列表

    输入：无

    输出：无

    \_\_new\_\_\(cls,\*args,\*\*kwargs\)

    功能：初始化

    详细：保证WebApp只创建一次

    输入：无

    输出：无

    add\_channel\(self,channel\_name\)

    功能：增加channel

    详细：调用channel\_manager，添加channel

    输入：channel名

    输出：成功返回true，失败返回fakse

    del\_channel\(self,names\)

    功能：删除channel

    详细：调用channel\_manager，删除channel

    输入：channel名，可以多个，用逗隔开

    输出：成功返回true，失败返回fakse

    list\_channels\(self\)

    功能：返回channel列表

    详细：调用channel\_manager，返回channel列表

    输入：无

    输出：channel列表

    is\_channel\_exist\(self,request\)

    功能：判断channel是否存在

    详细：调用channel\_manager，判断channel是否存在

    输入：无

    输出：找到返回true，否则返回false

    add\_request\(self,request\)

    功能：在请求列表中添加请求

    详细：和has\_request互斥

    输入：请求

    输出：无

    has\_request\(self,request\)

    功能：判断请求列表中是否有特定请求

    详细：和add\_request互斥

    输入：请求

    输出：找到返回true，否则返回false

    get\_media\_data\(self,channel\_name\)

    功能：返回视频数据

    详细：分别有静态图片，单张图片，多张的图片

    输入：channel名

    输出：视频数据\{类型，图片，fps，状态，框（可没有）\}

2.  BaseHandler类

    继承自tornado.web.RequestHandler类

    内容为空

3.  HomeHandler类

    继承自BaseHandler类

    get\(self,\*args,\*\*kwargs\)

    功能：渲染页面，并对所以channel添加响应

4.  AddHandler类

    继承自BaseHandler类

    post\(self,\*args,\*\*kwargs\)

    功能：读取channel的名称，添加channel

5.  DelHandler类

    post\(self,\*args,\*\*kwargs\)

    功能：读取channel的名称，删除channel

6.  ViewHandler类

    post\(self,\*args,\*\*kwargs\)

    功能：处理查看channel请求

7.  WebSocket类

    继承自tornado.websocket.WebSocketHandler类

    open\(self,\*args,\*\*kwargs\)

    功能：读取请求和channel名称，失败则关闭

    send\_message\(obj,message,binary=false\)

    静态方法

    功能：发送消息到客户端，成功返回true，失败返回false

    on\_close\(self\)

    关闭页面时动作，内容为空

    on\_message\(self,message\)

    功能：调用run\_task处理信息

    run\_task\(self\)

    功能：首先判断名称和请求正确性，调用get\_media\_data获取数据，验证数据之后调用send\_message发送 数据，如果是静态图片或者出现错误，则结束响应

8.  get\_webapp\(\)函数

    功能：加载网页配置文件， 生成http服务器

    详细：无

    输入：无

    输出：http服务器

9.  start\_webapp\(\)函数

    功能：开启web服务

    详细：对web端口进行监听

    输入：无

    输出：无

10. stop\_webapp\(\)函数

功能：停止web服务

详细：无

输入：无

输出：无

**Presenter Server核心解读**

1.1 Presenter Server接收数据解读

本部分我们以sample-facedetection的Presenter Server核心代码作为解读，首先我们下载sample-facedetection源码，https://github.com/Ascend/sample-facedetection，然后我们打开presenterserver\\common\\presenter\_socket\_server.py，这个就是我们重点解读的对象文件。首先我们看看核心处理的代码

def \_read\_sock\_and\_process\_msg\(self, sock\_fileno, conns, msgs\):

'''

Args:

sock\_fileno: a socket fileno, return value of socket.fileno\(\)

conns: all socket connections registered in epoll

msgs: msg read from a socket

Returns:

ret: True or False

'''

\# 读取包头

msg\_total\_len, msg\_name\_len = self.\_read\_msg\_head\(sock\_fileno, conns\)

if msg\_total\_len is None:

logging.error\("msg\_total\_len is None."\)

return False

\# 读取包名

ret, msg\_name = self.\_read\_msg\_name\(sock\_fileno, conns, msg\_name\_len\)

if not ret:

return ret

\#  读取包体

msg\_body\_len = msg\_total\_len - self.msg\_head\_len - msg\_name\_len

if msg\_body\_len < 0:

logging.error\("msg\_total\_len:%u, msg\_name\_len:%u, msg\_body\_len:%u",

msg\_total\_len, msg\_name\_len, msg\_body\_len\)

return False

ret = self.\_read\_msg\_body\(sock\_fileno, conns, msg\_body\_len, msgs\)

if not ret:

return ret

\#  处理消息

ret = self.\_process\_msg\(conns\[sock\_fileno\], msg\_name, msgs\[sock\_fileno\]\)

return ret

**代码解读** 上面我们可以清楚看到Presenter Server接收数据处理步骤：

1.  读取消息头，共计5个字节；
2.  读取消息名，是一个字符串；
3.  读取数据，这个数据是一个Protobuf序列化的bytes数据，其实就是我们在Presenter Agent打包的数据，就是Image\_Frame数据；
4.  对Protobuf序列化的bytes数据进行进一步处理。

读取消息头具体是怎么读取的呢，我们进去 self.\_read\_msg\_head看看

def \_read\_msg\_head\(self, sock\_fileno, conns\):

'''

Args:

sock\_fileno: a socket fileno

conns: all socket connections which created by server.

Returns:

msg\_total\_len: total message length.

msg\_name\_len: message name length.

'''

ret, msg\_head = self.\_read\_socket\(conns\[sock\_fileno\], self.msg\_head\_len\)

if not ret:

logging.error\("socket %u receive msg head null", sock\_fileno\)

return None, None

\# in Struct\(\), 'I' is unsigned int, 'B' is unsigned char

msg\_head\_data = struct.Struct\('IB'\)

\(msg\_total\_len, msg\_name\_len\) = msg\_head\_data.unpack\(msg\_head\)\#解包数据

msg\_total\_len = socket.ntohl\(msg\_total\_len\)

return msg\_total\_len, msg\_name\_len

**代码解读** 我们可以看到首先读取了5个字节数据，然后用了一个结构体类包数据到元组，就可以直接得到消息总长度和消息名长度，然后消息总长度并不是是一个整数，需要字节序列反解才是真正的数据长度。

def \_read\_msg\_name\(self, sock\_fd, conns, msg\_name\_len\):

'''

Args:

sock\_fd: a socket fileno

conns: all socket connections which created by server.

msg\_name\_len: message name length.

Returns:

ret: True or False

msg\_name: message name.

'''

ret, msg\_name = self.\_read\_socket\(conns\[sock\_fd\], msg\_name\_len\)

if not ret:

logging.error\("socket %u receive msg name null", sock\_fd\)

return False, None

try:

msg\_name = msg\_name.decode\("utf-8"\)

except UnicodeDecodeError:

logging.error\("msg name decode to utf-8 error"\)

return False, None

return True, msg\_name

**代码解读** 在传入消息名长度参数后，socket直接读取指定消息名长度数据，然后调用decode函数解码即可得到消息名。

def \_read\_msg\_body\(self, sock\_fd, conns, msg\_body\_len, msgs\):

'''

Args:

sock\_fd: a socket fileno

conns: all socket connections which created by server.

msg\_name\_len: message name length.

msgs: msg read from a socket

Returns:

ret: True or False

'''

ret, msg\_body = self.\_read\_socket\(conns\[sock\_fd\], msg\_body\_len\)

if not ret:

logging.error\("socket %u receive msg body null", sock\_fd\)

return False

msgs\[sock\_fd\] = msg\_body

return True

**代码解读** 在传入消息体长度参数后，socket直接读取指定消息体长度数据，然后传给msgs\[sock\_fd\] ，msg\_body就是Protobuf序列化的bytes数据。

综上可以看出，整个从Presenter Agent发来的数据为：

包头+包名+包体

其中包头=结构体打包\(\(字节序列\(消息总长度\), 消息名长度\)\)

包名=消息名称,由protbuf定义

包体=序列化的Image\_Frame结构体bytes数据

1.2 Presenter Server 发送数据解读

Presenter回传数据只要调用了sned\_message函数。定义如下

def send\_message\(self, conn, protobuf, msg\_name\):

'''

API for send message

Args:

conn: a socket connection.

protobuf: message body defined in protobuf.

msg\_name: msg name.

Returns: NA

'''

message\_data = protobuf.SerializeToString\(\) \#将protobuf数据序列bytes

message\_len = len\(message\_data\)\#求序列化的长度

msg\_name\_size = len\(msg\_name\) \#消息名长度

msg\_total\_size = self.msg\_head\_len + msg\_name\_size + message\_len\#消息总长度

\# in Struct\(\), 'I' is unsigned int, 'B' is unsigned char

s = struct.Struct\('IB'\)

msg\_head = \(socket.htonl\(msg\_total\_size\), msg\_name\_size\)\#包头是个元组类型，其中消息总长度被字节序列

packed\_msg\_head = s.pack\(\*msg\_head\) \#打包结构体

msg\_data = packed\_msg\_head + \\

bytes\(msg\_name, encoding="utf-8"\) + message\_data \#消息名被encode

conn.sendall\(msg\_data\) \# socket发送数据到Presenter Agent端

**代码解读** 从发送的函数可以看出，Presenter Server接收的数据结构和发送到Presenter Agent数据结构一样。我们必须遵循这个结构，否则我们需要自己定义一套TCP通信规则完成通信任务。

**Presenter Server回传数据**

本部分通过一个具体示例讲解，如何从Presenter Server回传数据到Presenter Agent。我们仍然以宝藏一第3小结作为示例，我们读取一张图片，然后由Presnter Server接收再转发回来保存这个图片。经过宝藏一的详细介绍，我们知道Agent和Server通信数据结构一样，因此我们只需要将Server处理消息的结构代码搬移到Agent稍微改下即可正常运行。请看下面片段代码，后面我们将给出完整待代码和程序案例给大家研究。

def \_\_start\_listenning\(self\):

while self.\_bstart:

try:

self.\_read\_sock\_and\_process\_msg\(\)

except Exception as e:

print\(e\)

self.\_sock\_client.close\(\)

self.start\_connect\(\)

break

def \_read\_socket\(self, read\_len\):\# 读取指定长度read\_len的socket字节数据

has\_read\_len = 0

read\_buf = b''

total\_buf = b''

while has\_read\_len != read\_len:

try:

read\_buf = self.\_sock\_client.recv\(read\_len - has\_read\_len\)

except socket.error:

print\("socket error"\)

return False, None

if read\_buf == b'':

return False, None

total\_buf += read\_buf

has\_read\_len = len\(total\_buf\)

return True, total\_buf

def \_read\_msg\_head\(self,read\_len\):\# 读取包头

ret, msg\_head = self.\_read\_socket\(read\_len\)

print\("msg head data is :", msg\_head\)

if not ret:

print\("socket receive msg head null"\)

return None, None

\# in Struct\(\), 'I' is unsigned int, 'B' is unsigned char

msg\_head\_data = struct.Struct\('IB'\)

\(msg\_total\_len, msg\_name\_len\) = msg\_head\_data.unpack\(msg\_head\)

msg\_total\_len = socket.ntohl\(msg\_total\_len\)

print\("msg total length is :",msg\_total\_len\)

print\("msg name is :", msg\_name\_len\)

return msg\_total\_len, msg\_name\_len

def \_read\_msg\_name\(self, msg\_name\_len\): \# 读取包名

ret, msg\_name = self.\_read\_socket\(msg\_name\_len\)

print\("direct msg name is :", msg\_name\)

if not ret:

print\("socket receive msg name null"\)

return False, None

try:

msg\_name = msg\_name.decode\("utf-8"\)

print\("decode msg name is :", msg\_name\)

except Exception as e:

print\("msg name decode to utf-8 error"\)

return False, None

return True, msg\_name

def \_read\_msg\_body\(self,  msg\_body\_len\):\# 读取包体

print\("msg body length is :", msg\_body\_len\)

ret, msg\_body = self.\_read\_socket\(msg\_body\_len\)

if not ret:

print\("socket receive msg body null"\)

return False,None

return True,  msg\_body

def \_read\_sock\_and\_process\_msg\(self\): \#处理消息

\# Step1: read msg head

msg\_total\_len, msg\_name\_len = self.\_read\_msg\_head\(5\)

if msg\_total\_len is None:

print\("msg\_total\_len is None."\)

return False

\# Step2: read msg name

ret, msg\_name = self.\_read\_msg\_name\(msg\_name\_len\)

if not ret:

return ret

\# Step3:  read msg body

msg\_body\_len = msg\_total\_len - 5 - msg\_name\_len

if msg\_body\_len < 0:

print\("msg\_total\_len is 0"\)

return False

ret, msg\_body = self.\_read\_msg\_body\(msg\_body\_len\)

if not ret:

return ret

\# Step4: process msg

ret = self.\_process\_msg\(msg\_name, msg\_body\)

return ret

def \_process\_msg\(self, msg\_name,msg\_data\):\#保存我们从Presenter Server发来的数据

if msg\_name == pb2.\_PRESENTIMAGEREQUEST.full\_name:

request = pb2.PresentImageRequest\(\)

try:

print\("ParseFromString start"\)

print\("msg\_data type is :", type\(msg\_data\)\)

request.ParseFromString\(msg\_data\)

except Exception as e:

print\("ParseFromString exception: Error parsing message"\)

return

with open\('result.jpg','wb'\) as f:

f.write\(request.data\)

**代码解读** 通过上面的改写，我们明显看到，我们可以直接从Presenter Server接收处理消息的代码复制到Agent端稍作修改就可以完成接收数据的任务。为了发送数据到Agent，我们只需要在presenterserver\\face\_detection\\src\\face\_detection\_server.py第173行下面添加一条发送代码即可，看下面标红的数据。

try:

request.ParseFromString\(msg\_data\)

except DecodeError:

logging.error\("ParseFromString exception: Error parsing message"\)

err\_code = pb2.kPresentDataErrorOther

return self.\_response\_image\_request\(conn, response, err\_code\)

self.send\_message\(conn, request, pb2.\_PRESENTIMAGEREQUEST.full\_name\)

sock\_fileno = conn.fileno\(\)

完整的代码案例请参考https://github.com/futureflsl/TcpCommunication



**常见问题（FAQ）**

如果遇到一些问题，可以在如下一站式FAQ中查找问题解决办法；

FAQ：[http://122.112.191.122:4000](http://122.112.191.122:4000/)

**求助渠道（昇腾社区）**

可以在社区中查找解决方案或者提问题求助：

[https://bbs.huaweicloud.com/forum/forum-949-1.html](https://bbs.huaweicloud.com/forum/forum-949-1.html)
