

一个转换成功的OM模型放在我们面前，怎么应用这个模型呢？

三板斧： 首先，确定模型的输入/输出信息；其次，按照输入shape构造模型的输入数据，将输入数据送给模型去推理；最后，根据模型的输出shape 以及输出shape的含义，解析推理结果。

## 1、查看模型输入输出

### 1.1查看模型输入信息


需要获取的模型的输入信息有：模型输入的宽高，模型输入的数据类型以及模型输入的图像格式。

其中模型输入的宽高，模型输入的数据类型可以通过使用MindStudio工具查看模型网络拓扑结构得到，而模型输入的图像格式则根据是否配置AIPP，获取方式有所不同，如果没有进行AIPP配置，则输入的图像格式与原始网络模型的输入类型一致，如果进行了AIPP的配置，且配置信息里有input_format，则根据AIPP配置信息中的图像格式确定模型的输入图像格式。
MindStudio工具查看模型网络拓扑结构参考：
https://support.huaweicloud.com/usermanual-MindStudioC76/atlasms_02_0060.html

#### 查看模型的输入shape

要查看模型的输入信息，首先要确定模型是否有进行AIPP的配置，对于未进行AIPP配置的离线模型，直接打开转换好的离线模型，在模型显示图上方，选中”data”节点， 右侧展开input_desc ，查看各输入节点的shape。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0224/111331_a5159020_5423530.png "屏幕截图.png")

例：如上图 input[0]的shape是[1，3，600，800]，dtype =3 int8 类型。

上图中有两个data节点，说明，此模型有两个输入shape。另一个data节点的shape是[1,3,1,1]，dtype=1 float 类型。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0224/111402_671b1758_5423530.png "屏幕截图.png")

若配置了AIPP，查看模型的AIPP信息，模型输入数据的shape参考AIPP参数配置信息。

#### 查看模型的AIPP信息

AIPP配置参数说明参考：
https://support.huaweicloud.com/usermanual-MindStudioC76/atlasms_02_0059.html

色域转换配置说明

https://support.huaweicloud.com/atc-model-convert-Atlas200DK202/atlasatc_16_0065.html

推理输入数据的shape 参考AIPP参数： src_image_size_w/src_image_size_h

```
src_image_size_w/src_image_size_h
# 图像的宽度、高度
# 类型：uint
# 取值范围 & 约束： [0,4096]、对于YUV420SP_U8类型的图像，要求取值是偶数
# 说明：请根据实际图片的宽、高配置src_image_size_w、src_image_size_h，若src_image_size_w、src_image_size_h同时不设置或同时设置为0，则会取网络输入定义的w和h
# src_image_size_w :0
# src_image_size_h :0
```
推理输入数据的图像格式： 参考input_format:
```
input_format：
1 输入图像类型
2 类型: enum
3 取值范围：YUV420SP_U8/XRGB8888_U8/RGB888_U8/YUV400_U8
4 input_format :1/2/3/4
```

例：

input_format =1 , 推理输入数据的图像格式为YUV420SP；
src_image_size_h =608; src_image_size_w =896   输入的图片信息宽高分别为896/608；
因此om模型需要的输入信息为：宽高为896/606的YUV420SP格式图片信息。

### 1.2查看模型输出信息

选中”Netoutput”节点， 右侧展开output_desc ，查看各输出节点的shape 。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0224/113238_c834f281_5423530.png "屏幕截图.png")
例：如上图   output[0]的shape是[1，32，1，1]，dtype =7  int32；

output[1]的shape是[304，32，1，16]，dtype =1  float；

## 2.构造推理输入数据

模型输入输出结构已明确，构造模型的输入数据送去推理。输入数据的常用构造方法有两种：使用opencv读图片信息；使用Dvpp进行图片信息处理；

### 2.1使用opencv接口

使用opencv 读取图片信息：
```
cv::Mat mat = cv::imread(image_path, CV_LOAD_IMAGE_COLOR);
```
使用opencv 进行宽高缩放：
```
cv::resize(mat, mat_rs, cv::Size(224,224));
```
使用opencv 进行数据格式转换：
```
mat_rs.convertTo(mat_rs,CV_32FC3);
```
使用opencv 进行图像格式转换：
```
cv::cvtColor(mat_rs, mat_rs, CV_BGR2Lab);
```
### 2.2 使用Dvpp接口

Dvpp 接口使用：
https://support.huaweicloud.com/devg-cpp-Atlas200DK202/atlasapi_07_0128.html

### 2.3 注意点

根据原始模型的特点，模型预处理选择减均值、归一化操作、色域转换。减均值、归一化、色域转换可通过编码实现，也可以通过转模型时AIPP实现。推荐使用AIPP。
转模型时填写Mean Less/Multiplying Factor参数实现减均值、归一化操作。
转模型时填写Input Image Format/Model Image Format参数实现色域变化。

#### 2.3.1 减均值

例1： 对图像RGB减均值，在转模型时填写Mean less[R|G|B]参数。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0224/113433_09fd7b06_5423530.png "屏幕截图.png")
代码中减均值：
```
img = cv2.imread(img_path + name, 0)
img = np.array(img)
img = (img - 127.5) / 128
```
也可在模型转换时填写Mean less 参数：127.5

#### 2.3.2 归一化

例： 对图像RGB归一化，在转模型时填写Multiplying Factor[R|G|B] 参数。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0224/113458_ae2c6201_5423530.png "屏幕截图.png")
代码中归一化：
```
img = cv2.imread(img_path + name, 0)
img = np.array(img)
img = (img - 127.5) / 128
```
也可在模型转换时填写Multiplying Factor 参数：0.007813

#### 2.3.3 格式转换

例： 对图像色域转换，在转模型时填写Input Image format/Model Image Format  参数。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0224/113536_b9266c93_5423530.png "屏幕截图.png")
如上图：输入图像格式为YUV420SP\_U8，转换后图像格式为RGB888\_U8

## 3、模型预测结果解析

模型预测结果下面分别以分类网络、检测网络为例，说明如何解析模型推理结果。

### 3.1 分类网络预测结果解析

以googlenet网络模型为例：

模型下载地址:

https://gitee.com/ascend/modelzoo/tree/master/contrib/TensorFlow/Research/cv/googlenet/ATC_googlenet_caffe_AE 

googlenet模型转换为om模型，模型的输出结构为[1,1000,1,1]，0-999，分别给出所有标签的置信度。图片的推理类别 为1000个值中最大值的位置索引，测试图片的置信度为1000个值中的最大值。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0224/113719_8459c869_5423530.png "屏幕截图.png")

例： 推理结果保存在 confidenceArray 中

检测出的类别： 
```
detectClass = np.argmax(confidenceArray)
```
检测出类别的置信度： detectConfidence = confidenceArray[detectClass]

### 3.2 检测网络预测结果解析

以Fasterrcnn网络模型为例：

模型下载地址:

[https://gitee.com/HuaweiAscend/models/tree/master/computer\_vision/object\_detect/faster\_rcnn](https://gitee.com/HuaweiAscend/models/tree/master/computer_vision/object_detect/faster_rcnn)

Fasterrcnn模型转换为om模型，模型有两个输出：output[0]的shape是[1，32，1，1]，dtype =7 int32；output[1]的shape是[304，32，1，16\]，dtype =1  float；

![输入图片说明](https://images.gitee.com/uploads/images/2021/0224/113823_e485bf0b_5423530.png "屏幕截图.png")

例： 推理结果保存在 resultList中, resultList[0]保存output[0]： [1，32，1，1] ；resultList[1]保存output[1]：  [304，32，1，16]

**求助渠道（昇腾社区）**

可以在samples仓的wiki中查找解决方案或者提issue求助：

[https://gitee.com/ascend/samples/issues](https://gitee.com/ascend/samples/issues)