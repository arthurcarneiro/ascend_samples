将一个在GPU上训练好的模型移植到Atlas200DK上需要先将原模型转为离线模型，然后编写应用程序对离线模型进行测试，确定离线模型的正确性。应用程序包括前输入数据预处理、模型推理接口调用以及后处理。本文档将说明如何进行模型转换、预处理和后处理。移植示例为googlenet模型，原始代码和模型参见https://github.com/BVLC/caffe/tree/master/models/bvlc_googlenet

模型转换

模型转换可以使用命令行方式和MindStudio工具，在https://support.huaweicloud.com/ug-mindstudioc75/atlasms_02_0196.html有使用方法说明。我们以工具转换方式为例：

步骤1：在MindStudio工具栏Ascend->Model Convert打开模型转换工具：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0210/141452_1d009e2e_5302634.png "屏幕截图.png")

步骤2：加载本地存放的模型
![输入图片说明](https://images.gitee.com/uploads/images/2021/0210/115237_3bd2c816_5302634.png "屏幕截图.png")


目前支持原生caffe和原生tensorflow pb模型转离线模型，如果模型中有自定义的算子，或者其他演进版本的算子，可能会出现转换失败。此时需要用户使用Hiai Matrix的TBE和TCL实现该算子，或者更换模型。tensorflow ckpt模型需要转换为pb模型（参考https://blog.csdn.net/yjl9122/article/details/78341689?depth\_1-utm\_source=distribute.pc\_relevant.none-task&utm\_source=distribute.pc\_relevant.none-task），再进行离线模型转换。keras的h5模型文件也可以转pb模型（参考https://github.com/amir-abdi/keras\_to\_tensorflow）后再转离线模型。

上图中Input Format是输入格式，目前有NCHW、NHWC和ND三种，其中NCHW、NHWC两者的差别可以参考https://www.cnblogs.com/sunny-li/p/9630305.html。如果我们移植的是caffe模型，格式就是NCHW；如果是tensorflow pb模型，则为NHWC格式。

原始模型的输入图片的shape为10, 3，224, 224，通俗的讲，就是说模型要求的输入是一个四维数组，第一维长度是1，代表Batch即一次可以处理多少张图片，第二维长度是3,代表图片的通道数，第三维长度是224，代表图片的高度， 第四维长度是224，代表图片的宽度。 特别强调下，这里的第三四维是原始模型输入数据（图片）的H和W，不是离线模型的。输入数据类型可根据模型的需要进行选择，主要有FP32、FP6、Uint8三种类型，当选择Uint8精度后可以在下一步进行AIPP配置

步骤3：点击NEXT进入AIPP参数配置页面

![输入图片说明](https://images.gitee.com/uploads/images/2021/0210/144724_877f7529_5302634.png "屏幕截图.png")


AIPP配置是配置一些算法参数，让Atlas200DK对我们传入的数据（图片）自动按照参数做预处理。如果我们移植的模型的输入数据不是图片，或者是图片但是是灰度图，通常是不需要开启AIPP的，直接关闭Image Pre-processing的开关即可；否则需要关注以下参数：

Input Image Format:离线模型输入的图像格式。注意这里是转换后的离线模型输入，不是原始caffe和tensorflow模型输入。如果移植后我们在Atlas200DK上运行时送进模型的是YUV格式图片，则本参数选择YUV420 sp；如果RGB，则选择RGB相关项。

Input Image Size:离线模型输入图像宽高。原始图像和模型输入图像尺寸往往不一致，需要进行缩放。如果是使用DVPP接口进行缩放，缩放后的图片通常是128*16对齐的。比如说我们想缩放到224*224，DVPP缩放后得到的会是256*224，Input Image Size的宽参数必须是256，高度参数是224；如果是直接使用opencv或者PIL缩放，则不需要进行对齐，直接让离线模型输入和原始模型输入保持一致即可。

Model Image Format:可以简单的理解为原始模型要求的输入图片格式。如果Input Image Format和原始模型要求输入的格式一致，这一项可以关闭。

Corp: 对图片进行截取，当需要时打开截取功能，本例不需要，关闭。

Normlization: 标准化处理。当uint8->fp16时才能使能标准化处理
Mean:每个通道的均值,类型：uint8,取值范围：[0, 255]。
min:每个通道的最小值，类型：float16，取值范围：[0, 255]
variance:代表每个通道的方差类型：float16, 取值范围：[-65504, 65504]。可以从原始模型的说明文档或者应用demo代码中，确认图像输入模型前是否需要标准化处理以及参数。
当uint8->fp16时，pixel_out_chx(i) = [pixel_in_chx(i) – mean_chn_i – min_chn_i] * var_reci_chn

以本文档举例模型googlenet为例，参数填写如下：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0210/144644_cabeaddf_5302634.png "屏幕截图.png")


步骤4：点击NEXT进入Advanced Options Preview配置页面
![输入图片说明](https://images.gitee.com/uploads/images/2021/0210/142038_3b6e83d8_5302634.png "屏幕截图.png")

在该页面的command preview中可以看到根据之前的配置生成的ａｔｃ转换命令，将该命令复制下来，在终端中执行也能实现模型的转换

在MindStudio的输出窗口中，最后一行有转好的模型路径：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0210/142340_0b31106b_5302634.png "屏幕截图.png")


预处理

预处理是指原始数据送进模型推理前的处理，使数据大小和格式符合模型要求，包括读取图片、缩放图片到模型指定大小操作，例如：

import sys
import os

import acl

from utils import *
from acl_dvpp import Dvpp
from acl_model import Model
from acl_image import AclImage
from image_net_classes import get_image_net_class
from PIL import Image, ImageDraw, ImageFont

#读入图片
image = AclImage(image_file)

#通过DVPP将图片缩放到224*224，之所以没用opencv接口而用DVPP接口是因为DVPP接口具有硬件加速功能
#DVPP解码jpeg图片成YUV
yuv_image = self._dvpp.jpegd(image)
resized_image = self._dvpp.resize(yuv_image, 224, 224)

至此，我们完成了图片数据推理前的预处理。

模型推理

Atlas200DK的python接口包中提供推理接口对模型进行推理，使用如下：
#调用模型的推理接口，分别传入图片的数据地址和长度
self._model.execute(resized_image.data(), resized_image.size)。

后处理

后处理即从推理接口的返回值中解析出模型推理数据。返回的输出数据有多少个单元是由模型决定的。我们可以使用MindStudio查看离线模型的输出节点描述信息，确定输出了单元个数。

步骤1：使用MindStudio双击模型的om文件即可加载模型的算子结构

![输入图片说明](https://images.gitee.com/uploads/images/2021/0210/102418_27d38cc8_5302634.png "屏幕截图.png")

步骤2：拖动模型查看窗口右侧的滚动条到最下面，点击最下面的一个节点，即输出节点。右侧会出现节点信息窗口：
![输入图片说明](https://images.gitee.com/uploads/images/2021/0210/102251_51aba9a7_5302634.png "屏幕截图.png")


步骤3：点击input_desc，可以看到输出个数，以及每个输出的 shape。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0210/104344_b4dcc9c1_5302634.png "屏幕截图.png")


示例输出如上图，有一个输出，即下标为0的单元数据的shape为（1， 1000），即一个[1, 1000]的二维数组，代表模型推理输出的1000个分类的置信度。数组元素类型dtype为DT_FLOAT类型。


#从模型获得推理的结果后先把结果拉成一个一维的向量
data = infer_output[0]
vals = data.flatten()
#对模型输出的一个1000维向量排序，并取得最高的5个数的下标
top_k = vals.argsort()[-1:-6:-1]
#打印top5的下标对应的类别
for n in top_k:
            object_class = get_image_net_class(n)
            print("label:%d  confidence: %f, class: %s" % (n, vals[n], object_class))
#获得top1的类别,即置信度最高的类别
object_class = get_image_net_class(top_k[0])
#使用pillow，将置信度最高的类别写在图片上，并保存到本地
output_path = os.path.join(os.path.join(SRC_PATH, "../outputs"), os.path.basename(image_file))
origin_img = Image.open(image_file)
draw = ImageDraw.Draw(origin_img)
font = ImageFont.truetype(os.path.join(SRC_PATH, "SourceHanSansCN-Normal.ttf"), size=30)
draw.text((10, 50), object_class, font=font, fill=255)
origin_img.save(output_path)

第41行显示下标为2的单元为置信度：

conf = object_result[:, 0, 0, 2]

完整的后处理：

    def post_process(self, infer_output, image_file):
        print("post process")
        data = infer_output[0]
        vals = data.flatten()
        top_k = vals.argsort()[-1:-6:-1]
        print("images:{}".format(image_file))
        print("======== top5 inference results: =============")
        for n in top_k:
            object_class = get_image_net_class(n)
            print("label:%d  confidence: %f, class: %s" % (n, vals[n], object_class))
        
        #使用pillow，将置信度最高的类别写在图片上，并保存到本地
        if len(top_k):
            object_class = get_image_net_class(top_k[0])
            output_path = os.path.join(os.path.join(SRC_PATH, "../outputs"), os.path.basename(image_file))
            origin_img = Image.open(image_file)
            draw = ImageDraw.Draw(origin_img)
            font = ImageFont.truetype(os.path.join(SRC_PATH, "SourceHanSansCN-Normal.ttf"), size=30)
            draw.text((10, 50), object_class, font=font, fill=255)
            origin_img.save(output_path)

推理结果显示：

![输入图片说明](https://images.gitee.com/uploads/images/2021/0210/142633_be8e6823_5302634.png "屏幕截图.png")


附录 示例代码清单

import sys
import os

import acl

from utils import *
from acl_dvpp import Dvpp
from acl_model import Model
from acl_image import AclImage
from image_net_classes import get_image_net_class
from PIL import Image, ImageDraw, ImageFont

class Classify(object):
    def __init__(self, model_path, model_width, model_height):
        self.device_id = 0
        self.context = None
        self.stream = None
        self._model_path = model_path
        self._model_width = model_width
        self._model_height = model_height
        self._dvpp = None

    def __del__(self):
        if self._model:
            del self._model
        if self._dvpp:
            del self._dvpp
        if self.stream:
            acl.rt.destroy_stream(self.stream)
        if self.context:
            acl.rt.destroy_context(self.context)
        acl.rt.reset_device(self.device_id)
        acl.finalize()
        print("[Sample] class Samle release source success")

    def _init_resource(self):
        print("[Sample] init resource stage:")
        ret = acl.init()
        check_ret("acl.rt.set_device", ret)

        ret = acl.rt.set_device(self.device_id)
        check_ret("acl.rt.set_device", ret)

        self.context, ret = acl.rt.create_context(self.device_id)
        check_ret("acl.rt.create_context", ret)

        self.stream, ret = acl.rt.create_stream()
        check_ret("acl.rt.create_stream", ret)

        self.run_mode, ret = acl.rt.get_run_mode()
        check_ret("acl.rt.get_run_mode", ret)

        print("Init resource stage success") 

    def init(self):
        #初始化 acl 资源
        self._init_resource() 
        self._dvpp = Dvpp(self.stream, self.run_mode)

        #初始化dvpp
        ret = self._dvpp.init_resource()
        if ret != SUCCESS:
            print("Init dvpp failed")
            return FAILED
        
        #加载模型
        self._model = Model(self.run_mode, self._model_path)
        ret = self._model.init_resource()
        if ret != SUCCESS:
            print("Init model failed")
            return FAILED

        return SUCCESS

    def pre_process(self, image):
        yuv_image = self._dvpp.jpegd(image)
        print("decode jpeg end")
        resized_image = self._dvpp.resize(yuv_image, 
                        self._model_width, self._model_height)
        print("resize yuv end")
        return resized_image

    def inference(self, resized_image):
        return self._model.execute(resized_image.data(), resized_image.size)

    def post_process(self, infer_output, image_file):
        print("post process")
        data = infer_output[0]
        vals = data.flatten()
        top_k = vals.argsort()[-1:-6:-1]
        print("images:{}".format(image_file))
        print("======== top5 inference results: =============")
        for n in top_k:
            object_class = get_image_net_class(n)
            print("label:%d  confidence: %f, class: %s" % (n, vals[n], object_class))
        
        #使用pillow，将置信度最高的类别写在图片上，并保存到本地
        if len(top_k):
            object_class = get_image_net_class(top_k[0])
            output_path = os.path.join(os.path.join(SRC_PATH, "../outputs"), os.path.basename(image_file))
            origin_img = Image.open(image_file)
            draw = ImageDraw.Draw(origin_img)
            font = ImageFont.truetype(os.path.join(SRC_PATH, "SourceHanSansCN-Normal.ttf"), size=30)
            draw.text((10, 50), object_class, font=font, fill=255)
            origin_img.save(output_path)


SRC_PATH = os.path.realpath(__file__).rsplit("/", 1)[0]
MODEL_PATH = os.path.join(SRC_PATH, "../model/googlenet_yuv.om")
MODEL_WIDTH = 224
MODEL_HEIGHT = 224


def main():
    #程序执行时带图片目录参数
    if (len(sys.argv) != 2):
        print("The App arg is invalid")
        exit(1)
    
    #实例化分类检测,传入om模型存放路径,模型输入宽高参数
    classify = Classify(MODEL_PATH, MODEL_WIDTH, MODEL_HEIGHT)
    #推理初始化
    ret = classify.init()
    check_ret("Classify.init ", ret)
    
    #从参数获取图片存放目录,逐张图片推理
    image_dir = sys.argv[1]
    images_list = [os.path.join(image_dir, img)
                   for img in os.listdir(image_dir)
                   if os.path.splitext(img)[1] in IMG_EXT]
    
    #创建目录，保存推理结果
    if not os.path.isdir(os.path.join(SRC_PATH, "../outputs")):
        os.mkdir(os.path.join(SRC_PATH, "../outputs"))

    for image_file in images_list:
        #读入图片
        image = AclImage(image_file)
        #对图片预处理
        resized_image = classify.pre_process(image)
        print("pre process end")
        #推理图片
        result = classify.inference(resized_image)
        #对推理结果进行处理
        classify.post_process(result, image_file)

if __name__ == '__main__':
    main()