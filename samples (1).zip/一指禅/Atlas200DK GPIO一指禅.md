### 开发者板（Atlas200DK）GPIO一指禅



本指导（一指禅）主要是用于帮助您快速使用开发者板（Atlas 200 DK）的7个GPIO口，（后文中全部叫开发板）。

# 一、开发环境软硬件配置
**准备环境**
1.  一套开发板。
2.  Ubuntu-18.04操作系统，安装好C75 环境。
3. GPIO\_DEMO代码。到https://gitee.com/ascend/samples/tree/master/cplusplus/level1_single_api/5_200dk_peripheral下载源码。
以上基于C75环境，样例代码以此环境开发运行，但不仅限于此环境。只是以C75系统环境对开发板GPIO进行分析讲解。

# 二、开发板对外输出脚说明

## 2.1开发板输出管脚

开发板共有40个管脚输出，其中有7个GPIO脚供用户控制使用。GPIO0 GPIO1 GPIO3 GPIO4 GPIO5 GPIO6 GPIO7开发板管脚数字对应可以看开发板40PIN 的两边板子标记，有标记哪个是1脚，哪个是40脚，然后和下图对应接IO口使用。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0207/161756_38df3b64_5578318.png "屏幕截图.png")

## 2.2 GPIO
### 2.2.1 GPIO管脚说明

直接从昇腾AI处理器引出的GPIO有：GPIO0、GPIO1。
由PCA6416引出的GPIO有：GPIO3、GPIO4、GPIO5、GPIO6、GPIO7。
https://support.huaweicloud.com/productdesc-A200dk_3000_c75/atlas200_DK_pdes_19_0020.html

![输入图片说明](https://images.gitee.com/uploads/images/2021/0207/161909_d0e4b582_5578318.png "屏幕截图.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0207/161921_2115bb57_5578318.png "屏幕截图.png")

由于GPIO3，4，5，6，7是通过IO口扩展芯片扩展的IO口，控制是使用I2C方式控制PCA6416.读取控制速度不如GPIO0，GPIO1，如果程序中有使用输入口作为检测使用（while\(1\)中一直监控IO口输入状态，例如按键检测）请优先使用GPIO0，GPIO1.

### 2.2.2 GPIO软件代码使用

#### 1. 获取GPIO操作权限。

首先让开发板默认用户 HwHiAiUser 获得开发板硬件软件控制权限，这个可以登录开发板在开发板/etc/rc.local 中修改，增加如下语句
```
echo 504 \>/sys/class/gpio/export
echo 444 \>/sys/class/gpio/export
chown -R HwHiAiUser /sys/class/gpio/gpio444
chown -R HwHiAiUser /sys/class/gpio/gpio504
chown -R HwHiAiUser /sys/class/gpio/gpio444/direction
chown -R HwHiAiUser /sys/class/gpio/gpio504/direction
chown -R HwHiAiUser /sys/class/gpio/gpio444/value
chown -R HwHiAiUser /sys/class/gpio/gpio504/value
chown -R HwHiAiUser /dev/i2c-1
chown -R HwHiAiUser /dev/i2c-2
chown -R HwHiAiUser /dev/ttyAMA0
usermod -aG HwHiAiUser HwHiAiUser
```
以上指令总体上就是引出GPIO0，GPIO1，并且让HwHiAiUser获取GPIO0 ，GPIO1，I2C等硬件的软件控制权限，如果rc.local已经加上了这些指令，就不需要重新添加了。

#### 2.  开发板GPIO样例代码下载。

到码云上下载GPIO demo源码。

代码中包含2个模块，其中GPIO文件夹封装了一个GPIO类，封装了3个接口函数。

Custom文件夹里面包含了如何调用这3个接口函数的样例代码。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0207/162122_6c6f8778_5578318.png "屏幕截图.png")


#### 3. GPIO模块接口函数说明

GPIO 4个接口函数如下。
```
int gpio_set_direction(int pin,int direction);
int gpio_set_value(int pin,int val);
int gpio_get_value(int pin,int *val);
int gpio_set_direction(int pin,int direction);
```
这个函数是设置IO口的状态，输入还是输出。

参数 pin 只能设置为（0,1,3,4,5,6,7），控制对应的IO口。

参数 direction 设置输入还是输出  0代表输入，1代表输出。

```
int gpio_set_value(int pin,int val);
```

这个函数是设置IO口的输出高电平还是低电平，前提是已经用gpio\_set\_direction设置这个口为输出口，否则无效。

参数 pin 只能设置为（0,1,3,4,5,6,7），控制对应的IO口。
参数 val设置输出高电平还是低电平  0代表低电平，1代表高电平。
```
int gpio_get_value(int pin,int *val\);
```

这个函数是获取IO口的输入高电平还是低电平，前提是已经用gpio\_set\_direction设置这个口为输入口，否则读取数值不对。

参数 pin 只能设置为（0,1,3,4,5,6,7），控制对应的IO口。

参数 val , int value ,将&value放入到函数中，获取value值。Value 0代表低电平，1代表高电平。

#### 4.  GPIO模块接口函数调用说明

在https://gitee.com/ascend/samples/blob/master/cplusplus/level1_single_api/5_200dk_peripheral/gpio/src/main.cpp中。

![](figures/zh-cn_image_0231893157.png)

**开发板GPIO深入了解**
https://ascend.huawei.com/doc/

## 2.3 关于UART和I2C的简单介绍**

## 2.3.1 UART

UART0是8脚和10脚，用于Ascend 310的默认调试串口（console），波特率115200。

UART1是16和18脚，可以用于扩展及与其他模块通信。

UART-Hi3559是38和40脚，用于MIPI-CSI接口接入芯片Hi3559调试，波特率115200。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0207/163926_cde92af3_5578318.png "屏幕截图.png")

UART的接口如下：
这个函数打开调试串口
```
    int uart_open(void);
```
这个函数关闭调试串口
```
    int uart_close(void);
```
代码详情链接如下：
https://gitee.com/ascend/samples/tree/master/cplusplus/level1_single_api/5_200dk_peripheral/uart

## 2.3.2 I2C
I2C2-SCL和I2C2-SDA组成I2C2接口，可以用来外接传感器，与其他模块通信等，速率最高支持400KHz。
I2C的接口如下：
```
 int i2c_write(unsigned char slave, unsigned char reg, unsigned char value);
 int i2c_read(unsigned char slave, unsigned char reg, unsigned char *buf);
```
代码详情链接如下：
https://gitee.com/ascend/samples/tree/master/cplusplus/level1_single_api/5_200dk_peripheral/i2c


