### 开发者板（Atlas200DK）环境搭建一指禅


本指导（一指禅）主要是用于帮助您快速搭建开发者板（Atlas 200 DK，后文中全部叫开发板）所需的开发环境；

**一、准备配件和开发服务器**

**准备配件**

<a name="table52618583"></a>
<table><thead align="left"><tr id="row60797095"><th class="cellrowborder" colspan="2" valign="top" id="mcps1.1.5.1.1"><p id="p25617672"><a name="p25617672"></a><a name="p25617672"></a><strong id="b29232460"><a name="b29232460"></a><a name="b29232460"></a>配件名称</strong></p>
</th>
<th class="cellrowborder" valign="top" id="mcps1.1.5.1.2"><p id="p19019073"><a name="p19019073"></a><a name="p19019073"></a><strong id="b36953931"><a name="b36953931"></a><a name="b36953931"></a>描述</strong></p>
</th>
<th class="cellrowborder" valign="top" id="mcps1.1.5.1.3"><p id="p40478462"><a name="p40478462"></a><a name="p40478462"></a><strong id="b28761840"><a name="b28761840"></a><a name="b28761840"></a>推荐型号</strong></p>
</th>
</tr>
</thead>
<tbody><tr id="row48007674"><td class="cellrowborder" colspan="2" valign="top" headers="mcps1.1.5.1.1 "><p id="p63416368"><a name="p63416368"></a><a name="p63416368"></a>SD卡</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.2 "><p id="p36452220"><a name="p36452220"></a><a name="p36452220"></a>用于制作Atlas 200 DK开发板启动系统</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.3 "><p id="p66948675"><a name="p66948675"></a><a name="p66948675"></a>推荐使用经过测试的SD卡：</p>
<a name="ul65667169"></a><a name="ul65667169"></a><ul id="ul65667169"><li>三星UHS-I U3 CLASS 10 64G</li><li>金士顿UHS-I U1 CLASS 10 64G</li></ul>
</td>
</tr>
<tr id="row22746728"><td class="cellrowborder" rowspan="2" valign="top" width="25%" headers="mcps1.1.5.1.1 "><p id="p30545685"><a name="p30545685"></a><a name="p30545685"></a>制作SD卡时所需配件，读卡器与跳线帽二选一，<strong id="b6475715"><a name="b6475715"></a><a name="b6475715"></a>推荐使用读卡器</strong></p>
</td>
<td class="cellrowborder" valign="top" width="25%" headers="mcps1.1.5.1.1 "><p id="p54770906"><a name="p54770906"></a><a name="p54770906"></a>读卡器</p>
</td>
<td class="cellrowborder" valign="top" width="25%" headers="mcps1.1.5.1.2 "><p id="p7258393"><a name="p7258393"></a><a name="p7258393"></a>使用读卡器制作SD卡的场景</p>
</td>
<td class="cellrowborder" valign="top" width="25%" headers="mcps1.1.5.1.3 "><p id="p51058985"><a name="p51058985"></a><a name="p51058985"></a>支持USB3.0协议</p>
</td>
</tr>
<tr id="row56877687"><td class="cellrowborder" valign="top" headers="mcps1.1.5.1.1 "><p id="p43689923"><a name="p43689923"></a><a name="p43689923"></a>跳线帽/杜邦线</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.1 "><p id="p49222835"><a name="p49222835"></a><a name="p49222835"></a>通过跳线帽/杜邦线短接开发板引脚的方式制作SD卡的场景</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.2 "><p id="p27626671"><a name="p27626671"></a><a name="p27626671"></a>跳线帽：间距2.54mm

杜邦线：母对母，间距2.54mm</p>
</td>
</tr>
<tr id="row47313454"><td class="cellrowborder" colspan="2" valign="top" headers="mcps1.1.5.1.1 "><p id="p7184552"><a name="p7184552"></a><a name="p7184552"></a>Type-C连接线</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.2 "><p id="p45077859"><a name="p45077859"></a><a name="p45077859"></a>用于与Mind Studio所在服务器通过USB方式连接</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.3 "><p id="p27427975"><a name="p27427975"></a><a name="p27427975"></a>支持USB3.0的Type-C连接线</p>
</td>
</tr>
<tr id="row45525183"><td class="cellrowborder" colspan="2" valign="top" headers="mcps1.1.5.1.1 "><p id="p63661202"><a name="p63661202"></a><a name="p63661202"></a>网线</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.2 "><p id="p56283746"><a name="p56283746"></a><a name="p56283746"></a>用于与Mind Studio所在服务器通过网线方式连接</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.3 "><p id="p62689558"><a name="p62689558"></a><a name="p62689558"></a>普通网线，接口类型为RJ45</p>
</td>
</tr>
<tr id="row27335113"><td class="cellrowborder" colspan="2" valign="top" headers="mcps1.1.5.1.1 "><p id="p66660559"><a name="p66660559"></a><a name="p66660559"></a>摄像头</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.2 "><p id="p30796205"><a name="p30796205"></a><a name="p30796205"></a>用于与Atlas 200 DK连接获取视频</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.3 "><p id="p11464716"><a name="p11464716"></a><a name="p11464716"></a>兼容树莓派摄像头，如果使用树莓派摄像头，需要额外购买黄色排线</p>
</td>
</tr>
<tr id="row36073588"><td class="cellrowborder" colspan="2" valign="top" headers="mcps1.1.5.1.1 "><p id="p36279478"><a name="p36279478"></a><a name="p36279478"></a>摄像头支架（可选）</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.2 "><p id="p52956621"><a name="p52956621"></a><a name="p52956621"></a>用于固定摄像头</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.3 "><p id="p61627937"><a name="p61627937"></a><a name="p61627937"></a>树莓派透明摄像头支架</p>
</td>
</tr>
<tr id="row17780525"><td class="cellrowborder" colspan="2" valign="top" headers="mcps1.1.5.1.1 "><p id="p30936422"><a name="p30936422"></a><a name="p30936422"></a>串口线（可选）</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.2 "><p id="p22822288"><a name="p22822288"></a><a name="p22822288"></a>用于Atlas 200 DK启动灯状态异常或者制卡成功但无法正常与Mind Studio安装服务器通信时，通过串口查看启动日志</p>
</td>
<td class="cellrowborder" valign="top" headers="mcps1.1.5.1.3 "><p id="p36666067"><a name="p36666067"></a><a name="p36666067"></a>USB转TTL串口线，3.3V接口电平</p>
</td>
</tr>
</tbody>
</table>

**准备开发服务器**

一个操作系统为Ubuntu X86架构的服务器，用途如下：

SD卡制作时，读卡器或者Atlas200DK会通过USB与此Ubuntu服务器连接，制作Atlas200DK的系统启动盘，详情请参见制作SD卡。

用于安装开发工具，详情请参见部署开发工具。

Ubuntu操作系统的版本可以为：18.04.4、18.04.5，下载命令：

```
wget http://releases.ubuntu.com/releases/bionic/ubuntu-18.04.5-desktop-amd64.iso
```

下载对应版本软件进行安装：
可以下载桌面版“ubuntu-18.04.xx-desktop-amd64.iso”，或Server版“ubuntu-18.04.xx-server-amd64.iso”。

**二、搭建硬件环境**

**安装摄像头**

-   拆卸开发板上盖参考

[https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0005.html](https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0005.html)

-   安装摄像头参考

主板为IT21DMDA参考：[https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0006.html](https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0006.html)

主板为IT21VDMB参考：[https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0007.html](https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0007.html)

**制作SD卡**

Atlas 200 DK开发板SD卡制作方式有如下两种：

-   如果有读卡器，可以将SD卡放入读卡器，将读卡器与Ubuntu服务器所在PC的USB连接，然后通过制卡脚本进行SD卡的制作。

**准备工作：**

SD卡：准备一张SD卡（建议容量不低于16G）

软件包：

<a name="table33132859"></a>
<table><thead align="left"><tr id="row4287423"><th class="cellrowborder" valign="top" width="15.306122448979592%" id="mcps1.1.4.1.1"><p id="p11736974"><a name="p11736974"></a><a name="p11736974"></a><strong id="b38523909"><a name="b38523909"></a><a name="b38523909"></a>包信息</strong></p>
</th>
<th class="cellrowborder" valign="top" width="28.57142857142857%" id="mcps1.1.4.1.2"><p id="p33428900"><a name="p33428900"></a><a name="p33428900"></a><strong id="b32424647"><a name="b32424647"></a><a name="b32424647"></a>包名</strong></p>
</th>
<th class="cellrowborder" valign="top" width="56.12244897959183%" id="mcps1.1.4.1.3"><p id="p9150720"><a name="p9150720"></a><a name="p9150720"></a><strong id="b15247616"><a name="b15247616"></a><a name="b15247616"></a>说明</strong></p>
</th>
</tr>
</thead>
<tbody><tr id="row27097356"><td class="cellrowborder" valign="top" width="15.306122448979592%" headers="mcps1.1.4.1.1 "><p id="p47402253"><a name="p47402253"></a><a name="p47402253"></a>制卡入口脚本</p>
</td>
<td class="cellrowborder" valign="top" width="28.57142857142857%" headers="mcps1.1.4.1.2 "><p id="p14377323"><a name="p14377323"></a><a name="p14377323"></a>make_sd_card.py</p>
</td>
<td class="cellrowborder" valign="top" width="56.12244897959183%" headers="mcps1.1.4.1.3 "><p id="p23712525"><a name="p23712525"></a><a name="p23712525"></a>请从<a href="https://www.huaweicloud.com/ascend/resource/Software" target="_blank" rel="noopener noreferrer">https://www.huaweicloud.com/ascend/resource/Software</a>中获取。

1.请选择配套的CANN版本。

2.“产品系列”请选择“Atlas 200 DK”。

3.“产品型号”请选择“Atlas 200 DK 开发者套件”。</p>
</td>
</tr>
<tr id="row41666396"><td class="cellrowborder" valign="top" width="15.306122448979592%" headers="mcps1.1.4.1.1 "><p id="p19534911"><a name="p19534911"></a><a name="p19534911"></a>制作SD卡操作系统脚本</p>
</td>
<td class="cellrowborder" valign="top" width="28.57142857142857%" headers="mcps1.1.4.1.2 "><p id="p38823967"><a name="p38823967"></a><a name="p38823967"></a>make_ubuntu_sd.sh</p>
</td>
<td class="cellrowborder" valign="top" width="56.12244897959183%" headers="mcps1.1.4.1.3 "><p id="p57733603"><a name="p57733603"></a><a name="p57733603"></a>请从<a href="https://www.huaweicloud.com/ascend/resource/Software" target="_blank" rel="noopener noreferrer">https://www.huaweicloud.com/ascend/resource/Software</a>中获取。

1.请选择配套的CANN版本。

2.“产品系列”请选择“Atlas200DK”。

3.“产品型号”请选择“Atlas200DK 开发者套件”。

</p>
</td>
</tr>
<tr id="row45910260"><td class="cellrowborder" valign="top" width="15.306122448979592%" headers="mcps1.1.4.1.1 "><p id="p27743545"><a name="p27743545"></a><a name="p27743545"></a>Ubuntu操作系统镜像包</p>
</td>
<td class="cellrowborder" valign="top" width="28.57142857142857%" headers="mcps1.1.4.1.2 "><p id="p32634650"><a name="p32634650"></a><a name="p32634650"></a>ubuntu-18.04.xx-server-arm64.iso</p>
</td>
<td class="cellrowborder" valign="top" width="56.12244897959183%" headers="mcps1.1.4.1.3 "><p id="p34122633"><a name="p34122633"></a><a name="p34122633"></a>开发者板操作系统镜像包。

Ubuntu操作系统的版本可以为：18.04.4、18.04.5。

 **注意：为ARM版本的Server软件包。** </p>
<p id="p38668243"><a name="p38668243"></a><a name="p38668243"></a>请从<a href="https://repo.huaweicloud.com/ubuntu-cdimage/releases/" target="_blank" rel="noopener noreferrer">华为开源镜像</a>或者<a href="http://releases.ubuntu.com/releases/" target="_blank" rel="noopener noreferrer">Ubuntu官网</a>下载此软件包。</p>
</td>
</tr>
<tr id="row30840926"><td class="cellrowborder" valign="top" width="15.306122448979592%" headers="mcps1.1.4.1.1 "><p id="p15087078"><a name="p15087078"></a><a name="p15087078"></a>开发者板驱动包与运行包</p>
</td>
<td class="cellrowborder" valign="top" width="28.57142857142857%" headers="mcps1.1.4.1.2 "><p id="p14093819"><a name="p14093819"></a><a name="p14093819"></a>A200dk-npu-driver-{software version}-ubuntu18.04-aarch64-minirc.tar.gz</p>

<p id="p59735509"><a name="p59735509"></a><a name="p59735509"></a>说明：</p>
<p id="p748676"><a name="p748676"></a><a name="p748676"></a>xxx为具体版本号信息。</p>
</td>
<td class="cellrowborder" valign="top" width="56.12244897959183%" headers="mcps1.1.4.1.3 "><p id="p60642794"><a name="p60642794"></a><a name="p60642794"></a>Linux环境，要求Ubuntu版本为18.04。</p>
<p id="p8914235"><a name="p8914235"></a><a name="p8914235"></a>请从<a href="http://releases.ubuntu.com/releases/" target="_blank" rel="noopener noreferrer">http://releases.ubuntu.com/releases/</a>网站下载对应版本软件进行安装。</p>
<p id="p50964406"><a name="p50964406"></a><a name="p50964406"></a>说明：</p>
<p id="p56026474"><a name="p56026474"></a><a name="p56026474"></a>Ubuntu Package类型需要选择“arm64”、"server"版本。</p>
<p id="p34476226"><a name="p34476226"></a><a name="p34476226"></a>Ubuntu Package的版本需要与Mind Studio安装的Ubuntu版本保持一致。</p>
</td>
</tr>
</tbody>
</table>

**操作步骤：**

（1）请将SD卡放入读卡器，并将读卡器与Ubuntu服务器的USB接口连接。

（2）在Ubuntu服务器中执行如下命令安装qemu-user-static、binfmt-support、yaml与交叉编译器。

```
su - root
```

执行如下命令更新源：

```
apt-get update
```

执行如下命令安装相关依赖库：

```
pip3 install pyyaml

apt-get install qemu-user-static binfmt-support python3-yaml gcc-aarch64-linux-gnu g++-aarch64-linux-gnu
```

（3）将软件包准备获取的SD卡制作脚本“make\_sd\_card.py”、“make\_ubuntu\_sd.sh”、Atlas 200 DK运行包与Ubuntu Package以普通用户上传到Ubuntu服务器任一目录，例如/home/ascend/mksd。

注意：以上脚本与软件包请放置到同一目录下。

本地制卡只允许当前目录下存放一个版本的软件包。

（4）切换到root用户，并进入制卡脚本所在目录/home/ascend/mksd。

```
su - root

cd /home/ascend/mksd/
```

（5）（可选）SD制卡脚本中默认配置的Atlas 200 DK开发者板的USB网卡的IP地址为192.168.1.2，NIC网卡的IP地址为192.168.0.2，若您想修改默认IP地址，请参考此步骤进行修改。

分别修改“ **make_sd_card.py** ”中的“ **NETWORK_CARD_DEFAULT_IP** ”与“ **USB_CARD_DEFAULT_IP** ”的参数值。

- **NETWORK_CARD_DEFAULT_IP** ”：Atlas 200 DK开发者板NIC网卡的IP地址。

- “ **USB_CARD_DEFAULT_IP** ”：Atlas 200 DK开发者板USB网卡的IP地址。

（6）执行制卡脚本。

执行如下命令查找SD卡所在的USB设备名称。

```
fdisk -l
```

例如，SD卡所在USB设备名称为“/dev/sdb”，可通过插拔SD卡的方式确定设备名称。

运行SD制卡脚本“make_sd_card.py”。

```
python3 make_sd_card.py local /dev/sdb

```

“ **local** ”表示使用本地方式制作SD卡。

“ **/dev/sdb** ”为SD卡所在的USB设备名称。

如图1所示表示制卡成功。

图1 SD制卡回显信息示例

![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/141631_0c337628_8018002.png "屏幕截图.png")

-   如果没有读卡器，可以将SD卡放入Atlas 200 DK开发板卡槽，通过跳线帽/杜邦线进行开发板相关针脚连接，将开发板与Ubuntu服务器所在PC的USB连接，然后通过制卡脚本进行SD卡的制作。参考[https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0014.html](https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0014.html)

**三、部署开发工具**

**Mind Studio工具部署环境准备**

**软件包获取**

根据需要的版本自行下载[https://www.huaweicloud.com/ascend/resources/tools/mindStudio/download](https://www.huaweicloud.com/ascend/resources/tools/mindStudio/download)

Mind Studio工具包

**环境要求**

<a name="table51926520"></a>
<table><thead align="left"><tr id="row3472933"><th class="cellrowborder" valign="top" width="9.090909090909092%" id="mcps1.1.5.1.1"><p id="p12872118"><a name="p12872118"></a><a name="p12872118"></a><strong id="b48740201"><a name="b48740201"></a><a name="b48740201"></a>类别</strong></p>
</th>
<th class="cellrowborder" valign="top" width="15.151515151515152%" id="mcps1.1.5.1.2"><p id="p55642234"><a name="p55642234"></a><a name="p55642234"></a><strong id="b31018066"><a name="b31018066"></a><a name="b31018066"></a>版本限制</strong></p>
</th>
<th class="cellrowborder" valign="top" width="29.292929292929294%" id="mcps1.1.5.1.3"><p id="p29435437"><a name="p29435437"></a><a name="p29435437"></a><strong id="b63592346"><a name="b63592346"></a><a name="b63592346"></a>获取方式</strong></p>
</th>
<th class="cellrowborder" valign="top" width="46.464646464646464%" id="mcps1.1.5.1.4"><p id="p50706425"><a name="p50706425"></a><a name="p50706425"></a><strong id="b53704644"><a name="b53704644"></a><a name="b53704644"></a>注意事项</strong></p>
</th>
</tr>
</thead>
<tbody><tr id="row55108945"><td class="cellrowborder" valign="top" width="9.090909090909092%" headers="mcps1.1.5.1.1 "><p id="p34639550"><a name="p34639550"></a><a name="p34639550"></a>硬件</p>
</td>
<td class="cellrowborder" valign="top" width="15.151515151515152%" headers="mcps1.1.5.1.2 "><a name="ul54340147"></a><a name="ul54340147"></a><ul id="ul54340147"><li>内存：最小4GB，推荐8GB</li><li>磁盘空间：最小6GB</li></ul>
</td>
<td class="cellrowborder" valign="top" width="29.292929292929294%" headers="mcps1.1.5.1.3 "><p id="p43423319"><a name="p43423319"></a><a name="p43423319"></a>-</p>
</td>
<td class="cellrowborder" valign="top" width="46.464646464646464%" headers="mcps1.1.5.1.4 "><a name="ul27627990"></a><a name="ul27627990"></a><ul id="ul27627990"><li>若Linux宿主机内存为4G，在Mind Studio中进行模型转换时，建议Model文件大小不超过350M，如果超过此规格，操作系统可能会因为超过安全内存阈值而工作不稳定。</li><li>若Linux宿主机配置升级，比如8G内存，则相应支持的操作对象规格按比例提升。</li></ul>
<p id="p8146160"><a name="p8146160"></a><a name="p8146160"></a>例如，内存由4G升级到8G，则Model文件建议大小不超过700M。</p>
<a name="ul6206582"></a><a name="ul6206582"></a><ul id="ul6206582"><li>&nbsp;</li></ul>
</td>
</tr>
<tr id="row32971110"><td class="cellrowborder" valign="top" width="9.090909090909092%" headers="mcps1.1.5.1.1 "><p id="p53414263"><a name="p53414263"></a><a name="p53414263"></a>操作系统</p>
</td>
<td class="cellrowborder" valign="top" width="15.151515151515152%" headers="mcps1.1.5.1.2 "><p id="p31588048"><a name="p31588048"></a><a name="p31588048"></a>版本：18.04 64位X86操作系统</p>
</td>
<td class="cellrowborder" valign="top" width="29.292929292929294%" headers="mcps1.1.5.1.3 "><p id="p8495130"><a name="p8495130"></a><a name="p8495130"></a>请从<a href="http://releases.ubuntu.com/releases/" target="_blank" rel="noopener noreferrer">http://releases.ubuntu.com/releases/</a>下载对应版本软件进行安装。<strong id="b17016957"><a name="b17016957"></a><a name="b17016957"></a></strong></p>
</td>
<td class="cellrowborder" valign="top" width="46.464646464646464%" headers="mcps1.1.5.1.4 "><p id="p2519427"><a name="p2519427"></a><a name="p2519427"></a>模型转换时，如果加载了TE自定义插件，可能会出现界面卡住的现象；如果界面卡住，请使用命令<strong id="b22674843"><a name="b22674843"></a><a name="b22674843"></a>uname -r</strong>或者<strong id="b2747002"><a name="b2747002"></a><a name="b2747002"></a>cat /proc/version</strong>检查Linux内核版本是否低于4.18，如果低于4.18请参见如下链接升级Linux内核补丁：</p>
<p id="p24723024"><a name="p24723024"></a><a name="p24723024"></a><a href="https://bugzilla.kernel.org/attachment.cgi?id=277305" target="_blank" rel="noopener noreferrer">https://bugzilla.kernel.org/attachment.cgi?id=277305</a></p>
<p id="p56407950"><a name="p56407950"></a><a name="p56407950"></a>升级Linux内核的方法请参见：<a href="https://bbs.huaweicloud.com/forum/thread-22441-1-1.html" target="_blank" rel="noopener noreferrer">https://bbs.huaweicloud.com/forum/thread-22441-1-1.html</a>。</p>
</td>
</tr>
<tr id="row5641212"><td class="cellrowborder" valign="top" width="9.090909090909092%" headers="mcps1.1.5.1.1 "><p id="p54284994"><a name="p54284994"></a><a name="p54284994"></a>Python</p>
</td>
<td class="cellrowborder" valign="top" width="15.151515151515152%" headers="mcps1.1.5.1.2 "><p id="p35008393"><a name="p35008393"></a><a name="p35008393"></a>3.7.5</p>
</td>
<td class="cellrowborder" valign="top" width="29.292929292929294%" headers="mcps1.1.5.1.3 "><p id="p19750463"><a name="p19750463"></a><a name="p19750463"></a>-</p>
</td>
<td class="cellrowborder" valign="top" width="46.464646464646464%" headers="mcps1.1.5.1.4 "><p id="p56283646"><a name="p56283646"></a><a name="p56283646"></a>Mind Studio安装需要同时安装python2和python3。</p>
</td>
</tr>
<tr id="row36790769"><td class="cellrowborder" valign="top" width="9.090909090909092%" headers="mcps1.1.5.1.1 "><p id="p27262282"><a name="p27262282"></a><a name="p27262282"></a>OpenJDK</p>
</td>
<td class="cellrowborder" valign="top" width="15.151515151515152%" headers="mcps1.1.5.1.2 "><p id="p60761195"><a name="p60761195"></a><a name="p60761195"></a>openjdk-8</p>
</td>
<td class="cellrowborder" valign="top" width="29.292929292929294%" headers="mcps1.1.5.1.3 "><p id="p22709757"><a name="p22709757"></a><a name="p22709757"></a>-</p>
</td>
<td class="cellrowborder" valign="top" width="46.464646464646464%" headers="mcps1.1.5.1.4 "><p id="p27551015"><a name="p27551015"></a><a name="p27551015"></a>-</p>
</td>
</tr>
</tbody>
</table>

**创建Mind Studio安装用户**

安装前需要创建好 Mind Studio用户，并使用该用户安装。目前推荐使用非root用户安装，且确保该用户$HOME目录权限为750，支持任意非root用户安装，如果需要使用新用户安装 Mind Studio，则使用如下命令创建新用户。本节所有操作请在root用户下执行。

1、执行以下命令创建Mind Studio安装用户并设置该用户的$HOME目录。

```
useradd -d /home/username -m username
```

2、执行以下命令设置密码。

```
passwd username
```

3、执行以下命令设置权限，进入“/home”目录。

```
chmod 750 /home/username
```

**说明：**

username为安装 Mind Studio的用户名，该用户的umask值不能大于0027：

若要查看umask的值，则执行命令：

```
umask
```

若要修改umask的值，则执行命令：

```
umask 新的取值
```

-   配置Mind Studio安装用户权限

Mind Studio安装前需要下载相关依赖软件，下载依赖软件需要使用 sudo apt-get权限，请以root用户执行如下操作。

1、以root用户打开“/etc/sudoers”文件：

```
chmod u+w /etc/sudoers
vi /etc/sudoers
```

2、在该文件“\# User privilege specification”下面增加如下内容：

```
username ALL=(ALL:ALL)   NOPASSWD:SETENV:/usr/bin/apt-get, /usr/bin/pip, /bin/tar, /bin/mkdir, /bin/rm, /bin/sh, /bin/cp, /bin/bash, /usr/bin/make install, /bin/ln -s /usr/local/python3.7.5/bin/python3 /usr/bin/python3.7, /bin/ln -s /usr/local/python3.7.5/bin/pip3 /usr/bin/pip3.7, /bin/ln -s /usr/local/python3.7.5/bin/python3 /usr/bin/python3.7.5, /bin/ln -s /usr/local/python3.7.5/bin/pip3 /usr/bin/pip3.7.5, /usr/bin/unzip

```

“username”为执行安装脚本的普通用户名。

**说明：**

请确保“/etc/sudoers”文件的最后一行为“\#includedir /etc/sudoers.d”，如果没有该信息，请手动添加。

3、添加完成后，执行如下命令保存文件。

```
:wq!
```

4、执行以下命令取消“/etc/sudoers”文件的写权限：

```
chmod u-w /etc/sudoers
```

-   检查源

Mind Studio安装过程需要下载相关依赖，请确保安装Mind Studio的服务器能够连接网络。

请在root用户下执行如下命令检查源是否可用。

```
apt-get update
```

**说明：**

如果命令执行报错，则检查网络是否连接或者把“/etc/apt/sources.list”文件中的源更换为可用的源。

-   安装依赖

请切换到Mind Studio安装用户执行如下操作，安装Mind Studio工具依赖的python2、python3、JDK等组件。

**1、安装Mind Studio相关依赖**

```
sudo apt-get install scite xorg xubuntu-desktop python python3 python-pip python3-pip
```

**说明：**

如果用户直接在Ubuntu系统上安装并运行Mind Studio，在执行上述命令前，请先执行如下命令检查是否安装xubuntu-desktop软件，如果已经安装，则执行上述命令时请把xubuntu-desktop软件删除。

```
dpkg -l xubuntu-desktop
```

**2、安装 Python开发环境**

**Python3环境安装**

环境部署依赖pip3.7.5；安装开发套件包中算子比对工具依赖：protobuf、scipy；profiling工具依赖：protobuf、grpcio、grpcio-tools、requests，执行如下命令分别安装：

```
pip3.7.5 install numpy --user
pip3.7.5 install decorator --user
pip3.7.5 install attrs --user
pip3.7.5 install psutil --user
pip3.7.5 install decorator --user
pip3.7.5 install numpy --user
pip3.7.5 install protobuf==3.11.3 --user
pip3.7.5 install scipy --user
pip3.7.5 install sympy --user
pip3.7.5 install cffi --user
pip3.7.5 install grpcio --user
pip3.7.5 install grpcio-tools --user
pip3.7.5 install requests --user
```

Python3.7.5环境检查

使用如下命令分别检查python3、pip3：

```
python3.7.5 --version
pip3.7.5 --version
```

若分别返回如下所示信息，则说明安装成功：

```
Python 3.7.5
pip 19.2.3 from /usr/local/python3.7.5/lib/python3.7/site-packages/pip (python 3.7)
```

**3、安装JDK**

（1）执行如下命令安装JDK。

```
sudo apt-get install -y openjdk-8-jdk
```

（2）配置JAVA\_HOME环境变量，Mind Studio的安装及运行都依赖该环境变量，设置方法如下：

1、在任何目录下执行如下命令，打开.bashrc文件。

```
vi \~/.bashrc
```

2、在文件的最后一行后面添加如下内容。

```
export JAVA\_HOME=/usr/lib/jvm/java-8-openjdk-amd64
export PATH=$JAVA\_HOME/bin:$PATH
```

**说明：**

“JAVA\_HOME”为JDK的安装目录，若用户已经配置了JDK，请根据安装目录的实际情况进行修改。若根据上述步骤安装的JDK，则安装目录不用修改。

（3）执行如下命令保存文件并退出。

```
:wq!
```

（4）执行如下命令使环境变量生效。

```
source \~/.bashrc
```

（5）执行如下命令检查环境变量设置，回显信息如下：

```
echo $JAVA\_HOME
```

**/usr/lib/jvm/java-8-openjdk-amd64**

（6）执行which jconsole命令检查JDK安装。

如果输出如下回显信息表示安装成功，如果未输出如下回显信息表示JDK安装失败。

```
/usr/lib/jvm/java-8-openjdk-amd64/bin/jconsole
```

**安装Mind Studio**

（1）使用Mind Studio的安装用户将如下文件上传至Mind Studio安装服务器任意目录，本示例为上传到$HOME目录：

**Mind Studio安装包下载路径：**[https://www.huaweicloud.com/ascend/resources/tools/mindStudio/download](https://www.huaweicloud.com/ascend/resources/tools/mindStudio/download)

1.  安装Mind Studio

    [https://support.huaweicloud.com/ug-mindstudioc75/atlasms_02_0191.html](https://support.huaweicloud.com/ug-mindstudioc75/atlasms_02_0191.html)

2.  卸载Mind Studio

    [https://support.huaweicloud.com/ug-mindstudioc75/atlasms_02_0197.html](https://support.huaweicloud.com/ug-mindstudioc75/atlasms_02_0197.html)

3.  升级Mind Studio

    Mind Studio为绿色版软件，如果用户想升级新版本，请参见单独卸载Mind Studio卸载Mind Studio后， 再参见软件包完整性校验和安装Mind Studio重新安装新版本Mind Studio。

4.  启动Mind Studio

    如果用户关闭了Mind Studio，想要重新启动，则可以参见如下方式操作：

    使用安装Mind Studio普通用户，进入安装包解压后的“MindStudio-ubuntu/bin”目录，执行如下命令启动Mind Studio：

    `./MindStudio.sh`

    启动Mind Studio后，查询进程命令为：

    `ps -ef|grep idea`

5.  停止Mind Studio

    如果用户想要关闭Mind Studio，在Mind Studio运行界面直接单击窗口右上角x的退出即可。

6.  查询Mind Studio版本

安装完成后您可以通过如下方式查询所安装Mind Studio版本是否正确：

Mind Studio安装完成后，在欢迎界面中，单击右下角的“Get Help \> About”查看所安装的版本信息。

进入Mind Studio工程页面，单击菜单栏的“Help \> About”弹出版本信息，查看版本信息是否正确。

**配置交叉编译环境**

参考：[https://support.huaweicloud.com/ug-mindstudioc75/atlasms_02_0192.html](https://support.huaweicloud.com/ug-mindstudioc75/atlasms_02_0192.html)


