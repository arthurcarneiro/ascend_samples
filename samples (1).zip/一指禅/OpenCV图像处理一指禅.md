# OpenCV图像处理一指禅

OpenCV是一个基于BSD许可（开源）发行的跨平台计算机视觉库，可以运行在Linux、Windows、Android和Mac OS操作系统上，它由一系列 C 函数和 C++ 类构成，同时提供了Python、Ruby、MATLAB等语言的接口，实现了图像处理和计算机视觉方面的很多通用算法。 

## 图像获取

OpenCV读取图像图像空间为BGR，图像数据格式为HWC

**1 读取图像**

***cv2.imread(filepath,flags)***

 **参数：**

​     *filepath*：图像路径
​     *flags*：读入图片的标志
​         *cv2.IMREAD_COLOR*：*1* , 默认参数，读入一副彩色图片，忽略alpha通道
​         *cv2.IMREAD_GRAYSCALE*：*0*, 读入灰度图片
​         *cv2.IMREAD_UNCHANGED*：读入完整图片，包括alpha通道

例：

```
import cv2

img_color = cv2.imread('ori.jpg')  # 读入彩色图像
img_gray = cv2.imread('ori.jpg', 0) # 读入灰度图像
```

![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/164703_70bd988d_8113712.png "1612767872180.png")

**2 图像保存**

***cv2.imwrite(filepath，img，num)***

 **参数：**

​     *filepath*：图像保存路径
​     *img*：要保存的图片
​     *num*：可选项，它针对特定的格式
​         对于JPEG，其表示的是图像的质量，用0 - 100的整数表示，默 认95;
​         对于png ,第三个参数表示的是压缩级别。默认为3.

例：

```
import cv2

img_color = cv2.imread('0.jpg')
cv2.imwrite('img_color.jpg', img_color)
```

## 图像通道操作

**图像通道拆分与合并**

图像通道拆分：***cv2.split***

图像通道合并：***cv2.merge***

```
import cv2
img_color = cv2.imread('0.jpg')
R, G, R = cv2.split(img_color)
# 显示各个分离出的通道
cv2.imshow("Blue", B)
cv2.imshow("Green", G)
cv2.imshow("Red", R)
cv2.waitKey(0)
```

![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/164728_3cdc61c1_8113712.png "1612770647509.png")

```
import numpy as np
import cv2

img_color = cv2.imread('0.jpg')
R, G, B = cv2.split(img_color)

# 生成一个值为0的单通道数组
zeros = np.zeros(img_color.shape[:2], dtype="uint8")

# 扩展B、G、R成为三通道, 另外两个通道用上面的值为0的数组填充
cv2.imshow("Blue", cv2.merge([B, zeros, zeros]))
cv2.imshow("Green", cv2.merge([zeros, G, zeros]))
cv2.imshow("Red", cv2.merge([zeros, zeros, R]))
cv2.waitKey(0)
```

![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/164743_43d0e794_8113712.png "1612770695944.png")

## 图像变换

### 图像颜色空间变换

***cv2.cvtColor(img,mode)***

 **参数：**

​     img：需要进行色彩变换的图像
​     mode：要进行的色彩变换方式
​     ![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/164959_172e9ee7_8113712.png "1612772185610.png")

例：

```
import cv2

img_BGR = cv2.imread('0.jpg')
img_RGB = cv2.cvtColor(img_BGR, cv2.COLOR_BGR2RGB)
img_GRAY = cv2.cvtColor(img_BGR, cv2.COLOR_BGR2GRAY)
img_YcrCb = cv2.cvtColor(img_BGR, cv2.COLOR_BGR2YCrCb)
img_LAB = cv2.cvtColor(img_BGR, cv2.COLOR_BGR2LAB)
img_YUV = cv2.cvtColor(img_BGR, cv2.COLOR_BGR2YUV)
cv2.imshow("img_BGR", img_BGR)
cv2.imshow("img_RGB", img_RGB)
cv2.imshow("img_GRAY", img_GRAY)
cv2.imshow("img_YcrCb", img_YcrCb)
cv2.imshow("img_LAB", img_LAB)
cv2.imshow("img_YUV", img_YUV)
cv2.waitKey(0)
```

![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/164758_aaf47851_8113712.png "1612772018849.png")

![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/164817_e7fc6cf4_8113712.png "1612772059975.png")

### 图像几何变换

**缩放**

***cv2.resize(img, Size, interpolation)*** 

 **参数：**

​     *img*：需要进行色彩变换的图像
​     *size*：输出图像尺寸
​    *interpolation*: 默认使用双线性插值

![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/164832_5c8fc768_8113712.png "1612772901930.png")

例：

```
import cv2

img = cv2.imread('0.jpg')
res1 = cv2.resize(img, (400,400), interpolation=cv2.INTER_AREA)
height, width = img.shape[ : 2]
res2 = cv2.resize(img, (int(0.5*width), int(0.5*height)),interpolation=cv2.INTER_AREA)
cv2.imshow("img", img)
cv2.imshow("res1", res1)
cv2.imshow("res2", res2)
cv2.waitKey(0)
```

![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/164855_18afa2a2_8113712.png "1612773722140.png")

**镜像**

***cv2.flip(img,flipcode)***

 **参数：**

​     *img*：需要进行色彩变换的图像
​     *flipcode*：控制反转效果
​              *flipcode* = 0：沿x轴翻转
​              *flipcode* > 0：沿y轴翻转
​              *flipcode* < 0：x,y轴同时翻转

例：

```
img = cv2.imread('0.jpg')
flip = cv2.flip(img, 1)
cv2.imshow("img", img)
cv2.imshow("flip", flip)
cv2.waitKey(0)
```

![输入图片说明](https://images.gitee.com/uploads/images/2021/0208/164907_19e173ea_8113712.png "1612773904445.png")

