
## 说在前头
本指南使用版本：CANN 20.1
配套MindStudio：2.0.0 版本(beta2)

##  概述
本指南可指导用户在有了模型的情况下

1. 快速评估自己的模型是否可以转换至昇腾310支持的离线模型；

2. 通过推理工具验证是否可以在昇腾310跑通推理过程；

##  准备工作

1. 硬件准备

   1. Atlas200DK开发者板套件（包含USB-Typec、网线、电源、SD卡）。
   2. ubuntu18.04虚拟机或双系统（最好是新建的干净环境）。
   3. 一个可上网的网络端口（路由器网口）（用来开发者板联网）。

2. 开发环境安装

   1. 安装ubuntu18.04虚拟机环境
   2. 安装Mindstudio工具 

   > **说明**:
   >
   > 具体的安装方法请参考官方文档：[Atlas200DK环境搭建]( https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0008.html)。
   > 也可以参考用户在CSDN上分享的极简安装方法：[Atlas200DK环境搭建]( https://blog.csdn.net/Hello_yes112/article/details/109096883)

3. 模型准备

   昇腾310支持将caffe模型或TensorFlow的.pb模型转换至离线(.om)模型，若用户的模型为TensorFlow框架的其他格式文件或Pytorch模型文件，请先将其转换为.pb模型或caffe模型，然后才可以开始转换至om模型。

## 模型转换

昇腾提供两种方式进行模型转换，一种是通过Mind Studio进行图像界面的模型转换方式，另一种是通过终端ATC指令进行模型转换。

1. Mind Studio模型转换方式

   具体参考：[Mind Studio 模型转换](https://support.huaweicloud.com/ug-mindstudioc75/atlasms_02_0053.html)

2. ATC指令模型转换方式
    具体参考：[ATC工具使用指导](https://support.huaweicloud.com/tg-A200dk_3000_c75/atlasatc_16_0002.html)   

## 模型推理评估

本教程提供参考msame工具进行模型推理，若msame工具可以进行推理，表明转换后的工具可以在昇腾310上跑通推理过程。

1. msame工具安装

   用户可参考[msame工具安装指南](https://gitee.com/ascend/modelzoo/tree/develop/contrib/msame)安装msame工具。

2. 推理

   使用msame推理工具，参考如下命令，发起推理性能测试

    ```
   ./msame --model model/yolov3.om --output output/ --loop 100
    ```

​        若成功推理，显示如下结果：

       [INFO] output data success
       Inference average time: 4.538660 ms
       Inference average time without first time: 4.535606 ms
       [INFO] unload model success, model Id is 1
       [INFO] Execute sample success.
       Test Finish!

## 应用开发
接下来就可以进行应用开发了，也就是部署你的模型到推理设备上了；
那么可以参考[Atlas 200 DK 开发者套件全套手册(20.1)](https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0002.html)中应用开发等相关章节。
另外可以参考[samples仓](https://gitee.com/ascend/samples)中的案例，或者直接选择其中的某个案例，替换模型，并进行前处理和后处理适配，完成自己的应用开发。
更有应用开发[视频教程](https://education.huaweicloud.com/courses/course-v1:HuaweiX+CBUCNXA024+Self-paced/about?isAuth=0&cfrom=hwc)供大家学习。


## 相关内容

- [昇腾论坛](https://bbs.huaweicloud.com/forum/forum-726-1.html)                    

- [samples仓](https://gitee.com/ascend/samples)

- [Mind Studio 使用指南](https://support.huaweicloud.com/ug-mindstudioc75/atlasms_02_0002.html)

- [ATC工具介绍](https://support.huaweicloud.com/tg-A200dk_3000_c75/atlasatc_16_0002.html)

- [Atlas 200 DK 开发者套件全套手册(20.1)](https://support.huaweicloud.com/dedg-A200dk_3000_c75/atlased_04_0002.html)











