还不知道如何提交pr的朋友，可以戳他 :arrow_right: [如何fork仓库并提交](https://gitee.com/ascend/samples/wikis/%E5%A6%82%E4%BD%95fork%E4%BB%93%E5%BA%93%E5%B9%B6%E6%8F%90%E4%BA%A4PR?sort_id=3271318)。

#### 一、辛辛苦苦搬砖，提个pr，为啥会有冲突呢？
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/172220_265d335b_7401379.png "屏幕截图.png")
这里的冲突是指，你在forK的仓库里修改代码后，想合入原始仓库，但不幸的是，你修改的文件与原始仓库里的文件有冲突。

举个 :chestnut: ，你在A文件里加了行`print("hello world!")`，张三也动了A文件，他加了行`print("dududu")`，不过他是在你之前提的pr，并已经合入原始仓库。这时候你的pr就会有冲突，因为你的A文件里并没有`print("dududu")`。

#### 二、那如何尽量避免冲突呢？
1. 在想提pr时，先同步下fork的仓库，让其尽量与原始仓内容一致。毕竟，你无法保证原始仓啥时候会更新嘛。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/164714_2727f497_7401379.png "屏幕截图.png")

2. 一个仓，只能有一个开启的pr, 若你又更新了fork的仓库，在pr未关闭之前，这些修改都会算在一个pr里。提交pr后，及时让commiter合入你的pr。

![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/165421_d6cb944b_7401379.png "屏幕截图.png")

#### 三、如何解决冲突


1. 记录下pr提交记录的hash值，然后关闭这个pr。
    下图表明，这个pr里有两次提交记录。
    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/172608_728be378_7401379.png "屏幕截图.png")

2. 同步下仓库，让fork的仓库变成最新状态。

    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/172914_6da37977_7401379.png "屏幕截图.png")

3. 在终端里，git clone 仓库的目录下，执行`git log`命令，找到更新前的一次版本。
    通过git log命令可以看到操作记录，结合第1步记录的哈希值或者时间，可以知道蓝色箭头所指的更新前的版本，记录红色和蓝色的哈希值。

    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/173624_d0110a63_7401379.png "屏幕截图.png")

4. 回退到更新前的版本。

    `git reset --hard <hash>`

    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/174141_c5f8a51b_7401379.png "屏幕截图.png")

5. 拉取fork的仓库代码。 
 
    `git pull origin master` 

    此时，本地终端里仓库的代码和fork的仓库代码一致了。 

    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/174546_1887d927_7401379.png "屏幕截图.png")

6. 将之前提交的两次记录添加进来，这边的hash 可以填多个，并用git status 命令查看

    `git cherry-pick <hash> <hash>`
    `git status`

    下图中的both modified 记录的就是有冲突的文件，这里可能会有多个冲突文件，都需要修改。
    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/184136_9b81da4c_7401379.png "屏幕截图.png")
 
7. 解决所有有冲突的文件

    打开有冲突的文件，并修改。

    \<<<< 和 \>>>>之间的就是有冲突的部分，以====分隔，上面是原始仓里的改动。这边的修改，需要根据实际情况来。


    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/184426_5af3e685_7401379.png "屏幕截图.png")

    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/185546_39fe42c9_7401379.png "屏幕截图.png")

8. 将修改后的文件加入提交
    `git add <file>`
    使用`git status`查看，会发现，之前的红色冲突，变绿了。
    git提示我们输入 `git cherry-pick --continue`,依据提示执行它。
    ![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/190607_34fe0e39_7401379.png "屏幕截图.png")

9. 提交代码
   `git push origin master`

10. 在码云页面上重新创建一个pr
    好了，大功告成，没有冲突了~
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/192301_20deba98_7401379.png "屏幕截图.png")



