1.forked仓库   
![forked](https://images.gitee.com/uploads/images/2020/1218/181030_5d47351f_5400693.png "屏幕截图.png")

2.选择fork到自己的分支   
![](https://images.gitee.com/uploads/images/2020/1218/181045_0742690a_5400693.png "屏幕截图.png")

3.在自己的分支上做代码修改（比如修改了readme）

4.在自己的分支上选择PullRequests
![](https://images.gitee.com/uploads/images/2020/1218/181105_069e1f50_5400693.png "屏幕截图.png")

5.选择新建Pull Request
![](https://images.gitee.com/uploads/images/2020/1218/181112_41a612d9_5400693.png "屏幕截图.png")

6.选择源分支和目标分支，注意，选择好对应的分支，不要提交错了
![](https://images.gitee.com/uploads/images/2020/1218/181121_315312cf_5400693.png "屏幕截图.png")

7.选择完成后，点击创建即可
![](https://images.gitee.com/uploads/images/2020/1218/181128_53e4c837_5400693.png "屏幕截图.png")
