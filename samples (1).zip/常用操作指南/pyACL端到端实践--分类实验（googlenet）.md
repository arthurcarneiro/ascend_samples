本文的目的是教你学会如何快速的将实验室训练的神经网络模型落地为一个边侧或者端侧（包含了Ascend310的Atlas系列产品）应用。如果你是一个老鸟，请绕行哈。
Ascend软件栈20.1版本，终于发布了AscendCL的python版本，那么我们就学习用python实现一个简单的图像分类应用。

老规矩，介绍一下开发全流程：
![输入图片说明](https://images.gitee.com/uploads/images/2020/1210/234604_0849c630_5651712.png "屏幕截图.png")

从上图看，好像很复杂，对吧，其实完全不用担心，入门的话，先只关注模型转换部分和第三步应用开发即可。

那么接下来，我们一步一步的来了解。

当然，在开始之前，你也可以先将代码下下来，跑一下找下感觉：https://gitee.com/ascend/samples/tree/dev/Python/level2_simple_inference/1_classification/googlenet_imagenet_picture

### 模型准备
在这里我们选用googlenet，关于googlenet的详解，以防篇幅过长，请参考这里：https://gitee.com/ascend/samples/wikis/%E5%9B%BE%E7%89%87googlenet%E5%88%86%E7%B1%BB?sort_id=3164842
如果该文章还无法让你完全理解googlenet，请移步原始模型进一步了解（https://github.com/BVLC/caffe/tree/master/models/bvlc_googlenet）

#### 从modelzoo获取此应用中所需要的原始网络模型。
https://gitee.com/ascend/modelzoo/tree/master/contrib/Research/cv/googlenet/ATC_googlenet_caffe_AE

### 理解模型
理解模型，就是通过阅读原始模型的运行脚本，或者训练源码，去弄明白原始模型的输入和输出，对应着，也就是必须搞明白原始模型的预处理过程和后处理过程。

图像预处理：该模型算法需要BGR格式，输入图像分辨率为224x224，并对颜色通道进行减均值。
本应用图像预处理时DVPP和AIPP分工处理（也可以有其他的分工，这个分工直接影响着模型转换时AIPP参数的配置，这里就先按照这个来哈）：

DVPP：
JGEGE对jpeg图片进行解码；
图像缩放为模型需要的尺寸：224x224
输出图像数据类型为：Uint8

AIPP:
颜色通道减均值
图像数据类型转换：Uint8->FP16(达芬奇推理的要求，模型最后实际的输入为fp16)

图像后处理：模型的输出为1000个float型数据，1000个float型数据代表1000中物体类别，每个float型数据为归一化数据范围0 ~ 1。代表该类物体识别的置信度，选取其中置信度最高的类别，作为图像的分类结果。

### 模型转换

执行以下命令下载aipp配置文件并使用atc命令进行模型转换。

先下载AIPP配置文件：https://c7xcode.obs.cn-north-4.myhuaweicloud.com/models/googlenet_imagenet_picture-python/insert_op.cfg
请参考指导书理解下这个配置文件（https://support.huaweicloud.com/tg-A200dk_3000_c75/atlasatc_16_0061.html）：
```
aipp_op { 
related_input_rank : 0
src_image_size_w : 224
src_image_size_h : 224
crop : false
input_format : YUV420SP_U8
aipp_mode: static
csc_switch : true
rbuv_swap_switch : false
matrix_r0c0 : 298
matrix_r0c1 : 516
matrix_r0c2 : 0
matrix_r1c0 : 298
matrix_r1c1 : -100
matrix_r1c2 : -208
matrix_r2c0 : 298
matrix_r2c1 : 0
matrix_r2c2 : 409
input_bias_0 : 16
input_bias_1 : 128
input_bias_2 : 128
mean_chn_0 : 104
mean_chn_1 : 117
mean_chn_2 : 123
min_chn_0 : 0.0
min_chn_1 : 0.0
min_chn_2 : 0.0
var_reci_chn_0 : 1.0
var_reci_chn_1 : 1.0
var_reci_chn_2 : 1.0
}
```

然后执行如下atc命令完成模型转换，获取到om：
```
atc --model=./googlenet.prototxt --weight=./googlenet.caffemodel --framework=0 --output=googlenet_yuv --soc_version=Ascend310 --insert_op_conf=./insert_op.cfg --input_shape="data:1,3,224,224" --input_format=NCHW
```

### 应用开发
当模型转换结束后，就意味着准备工作已经完成，接下来编码实现。
如下，解释直接看中文注释即可。

```
# 这两个就不解释了
import sys
import os

import acl # pyACL的接口库，必须导入
from utils import *  # utils里面是封装的几个内存管理类的接口

# acl_dvpp是对DVPP的acl接口的封装，大家可以直接使用，里面包括了常用的几个接口，例如jpegd，resize等
from acl_dvpp import Dvpp

# acl_model封装了model相关的函数，包括加载模型/输入数据准备等
from acl_model import Model

from acl_image import AclImage # 封装了图像文件读入等一些操作

# image_net_classes里面是imagenet的1000个类别
from image_net_classes import get_image_net_class

from PIL import Image, ImageDraw, ImageFont

# 本应用的主类，这个类是我们要重点实现的
class Classify(object):
    # 定义一些变量
    def __init__(self, model_path, model_width, model_height):
        self.device_id = 0
        self.context = None
        self.stream = None
        self._model_path = model_path
        self._model_width = model_width
        self._model_height = model_height
        self._dvpp = None
    
    # 析构函数，释放资源
    def __del__(self):
        if self._model:
            del self._model
        if self._dvpp:
            del self._dvpp
        if self.stream:
            acl.rt.destroy_stream(self.stream)
        if self.context:
            acl.rt.destroy_context(self.context)
        acl.rt.reset_device(self.device_id)
        acl.finalize()
        print("[Sample] class Samle release source success")

    # 设置芯片，创建context/stream等资源，被init调用使用
    def _init_resource(self):
        print("[Sample] init resource stage:")
        ret = acl.init()
        check_ret("acl.rt.set_device", ret)

        ret = acl.rt.set_device(self.device_id)
        check_ret("acl.rt.set_device", ret)

        self.context, ret = acl.rt.create_context(self.device_id)
        check_ret("acl.rt.create_context", ret)

        self.stream, ret = acl.rt.create_stream()
        check_ret("acl.rt.create_stream", ret)

        self.run_mode, ret = acl.rt.get_run_mode()
        check_ret("acl.rt.get_run_mode", ret)

        print("Init resource stage success") 
    
    # 初始化函数并加载模型
    def init(self):
        #初始化 acl 资源
        self._init_resource() 
        self._dvpp = Dvpp(self.stream, self.run_mode)

        #初始化dvpp
        ret = self._dvpp.init_resource()
        if ret != SUCCESS:
            print("Init dvpp failed")
            return FAILED
        
        #加载模型
        self._model = Model(self.run_mode, self._model_path)
        ret = self._model.init_resource()
        if ret != SUCCESS:
            print("Init model failed")
            return FAILED

        return SUCCESS

    # 预处理，调用dvpp将图片解码并resize
    def pre_process(self, image):
        yuv_image = self._dvpp.jpegd(image)
        print("decode jpeg end")
        resized_image = self._dvpp.resize(yuv_image, 
                        self._model_width, self._model_height)
        print("resize yuv end")
        return resized_image
    
    # 推理
    def inference(self, resized_image):
        return self._model.execute(resized_image.data(), resized_image.size)

    # 后处理
    def post_process(self, infer_output, image_file):
        print("post process")
        data = infer_output[0]
        vals = data.flatten()
        top_k = vals.argsort()[-1:-6:-1]
        print("images:{}".format(image_file))
        print("======== top5 inference results: =============")
        for n in top_k:
            object_class = get_image_net_class(n)
            print("label:%d  confidence: %f, class: %s" % (n, vals[n], object_class))
        
        #使用pillow，将置信度最高的类别写在图片上，并保存到本地
        if len(top_k):
            object_class = get_image_net_class(top_k[0])
            output_path = os.path.join("./outputs", os.path.basename(image_file))
            origin_img = Image.open(image_file)
            draw = ImageDraw.Draw(origin_img)
            font = ImageFont.truetype("SourceHanSansCN-Normal.ttf", size=30)
            draw.text((10, 50), object_class, font=font, fill=255)
            origin_img.save(output_path)

MODEL_PATH = "./model/googlenet_yuv.om"
MODEL_WIDTH = 224
MODEL_HEIGHT = 224

def main():
    #程序执行时带图片目录参数
    if (len(sys.argv) != 2):
        print("The App arg is invalid")
        exit(1)
    
    #实例化分类检测,传入om模型存放路径,模型输入宽高参数
    classify = Classify(MODEL_PATH, MODEL_WIDTH, MODEL_HEIGHT)
    #推理初始化
    ret = classify.init()
    check_ret("Classify.init ", ret)
    
    #从参数获取图片存放目录,逐张图片推理
    image_dir = sys.argv[1]
    images_list = [os.path.join(image_dir, img)
                   for img in os.listdir(image_dir)
                   if os.path.splitext(img)[1] in IMG_EXT]
    
    #创建目录，保存推理结果
    if not os.path.isdir('./outputs'):
        os.mkdir('./outputs')

    for image_file in images_list:
        #读入图片
        image = AclImage(image_file)
        #对图片预处理
        resized_image = classify.pre_process(image)
        print("pre process end")
        #推理图片
        result = classify.inference(resized_image)
        #对推理结果进行处理
        classify.post_process(result, image_file)

if __name__ == '__main__':
    main()
```

ok，到这里就结束了，从其中来看main函数中的逻辑就是读数据/准备数据/推理/处理推理出来的数据，还是比较清晰的。
关于如何运行/环境搭建等等，就不扯那么多了，看该案例的readme即可。

接下来，你就可以尝试去换个模型，比如说换成你自己的模型，一般只需要改造下预处理过程和后处理过程即可。



