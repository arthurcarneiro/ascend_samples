工欲善其事，必先利器其器！

Ascend软件栈有自己的IDE（MindStudio），而且MindStudio在算子开发/模型转换以及C++的AscendCL应用开发过程中的确有很大帮助，特别是在算子开发时，提供了一整套的测试框架/单步调试等等，非常方便，无可替代；另外在模型转换方面，将复杂的过程可视化，对转出的离线模型（om模型）也提供可视化，对于查看转换前后的模型结构/输入输出规格等等很是方便，强烈建议大家使用。

但在pyACL（AscendCL的python版本）应用开发过程中，写代码时，这里分享另外一个选择，使用vscode（当然你也可以选择pycharm或者其他）提升你的开发效率。

## 方案：本地PC安装VSCode，远程linux环境（假定已安装昇腾开发环境或者运行环境）

至于VSCode的远程方案，其实有很多了，你可以很方便的在网上搜到，这里就不介绍了，安装remote插件即可，这里只说几个关键点。

## 关键点
### 一. VSCode免密连接远程环境
如果没有配置免密登录，vscode每次断掉重连/重启/打开文件夹都需要输入密码，很是麻烦，这里说下如何配置免密。

首先说下原理(节省时间不想了解的同学可以略过，直接到实际操作步骤，按照步骤操作就可以了。)

SSH免密登录即公钥登录。
![输入图片说明](https://images.gitee.com/uploads/images/2020/1213/165404_693b1b4b_5651712.png "屏幕截图.png")

1. 在客户端使用ssh-keygen生成一对密钥：公钥+私钥
1. 将客户端公钥追加到服务端的authorized_key文件中，完成公钥认证操作
1. 认证完成后，客户端向服务端发起登录请求，并传递公钥到服务端
1. 服务端检索authorized_key文件，确认该公钥是否存在
1. 如果存在该公钥，则生成随机数R，并用公钥来进行加密，生成公钥加密字符串pubKey(R)
1. 将公钥加密字符串传递给客户端
1. 客户端使用私钥解密公钥加密字符串，得到R
1. 服务端和客户端通信时会产生一个会话ID(sessionKey)，用MD5对R和SessionKey进行加密，生成摘要（即MD5加密字符串）
1. 客户端将生成的MD5加密字符串传给服务端
1. 服务端同样生成MD5(R,SessionKey)加密字符串
1. 如果客户端传来的加密字符串等于服务端自身生成的加密字符串，则认证成功
1. 此时不用输入密码，即完成建连，可以开始远程执行shell命令了

参考：https://www.cnblogs.com/276815076/p/10449354.html

#### 步骤：
1. 配置rsa密钥
如果你的本地是windows
ssh-keygen -t rsa -b 4096 -f C:\Users\用户\\.ssh\id_rsa
注意：用户请修改成你自己的用户名
如果你本地是linux
ssh-keygen -t rsa -b 4096 -f ~/.ssh/id_rsa
一直回车确认，为了免密登录 此过程中请不要键入密码。
![输入图片说明](https://images.gitee.com/uploads/images/2020/1213/171025_9509751d_5651712.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2020/1213/170831_09eef642_5651712.png "屏幕截图.png") 

2. 将生成的公钥上传至远程环境并将该公钥追加到~/.ssh/authorized_keys文件中，注意一定是追加(>>)，以防覆盖了其他的公钥。
   #linux terminal
   cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
![输入图片说明](https://images.gitee.com/uploads/images/2020/1213/171146_db207307_5651712.png "屏幕截图.png")

操作完成。


### 二. Python环境配置
昇腾软件栈开发环境需要预装python3.7.5，但是pyACL其实是在ubuntu18.04自带的python 3.6.9（当前是，以后可能会升级）下可以运行的，且安装opencv等用pip3安装即可，所以配置python环境时，可以直接选择python3.6.9.
步骤：
1. 远程连接上以后，需要安装python插件后才可以配置python远程解释器
![输入图片说明](https://images.gitee.com/uploads/images/2020/1213/172515_71e7af1c_5651712.png "屏幕截图.png")

2. 选择python解释器版本
![输入图片说明](https://images.gitee.com/uploads/images/2020/1213/172703_0c524fff_5651712.png "屏幕截图.png")

3. 测试acl是否可以使用，import成功，即成。
![输入图片说明](https://images.gitee.com/uploads/images/2020/1213/172836_f352e83e_5651712.png "屏幕截图.png")

<未完待补充--在开发中发现的pyACL开发的关键点均会补充到这里，也欢迎看到该wiki的你提出问题和建议>








