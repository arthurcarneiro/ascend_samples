


## 1-登录华为云官网并进入购买配置界面。
华为云官网地址：https://www.huaweicloud.com。
根据网址进入网站后，注册登录华为云账号。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100114_c6dcfcfd_7380811.png "屏幕截图.png")
如下图所示，登陆后，单击控制台。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100158_ec255a90_7380811.png "屏幕截图.png")
如下图所示，进入控制台后，选择 “弹性云服务器ECS”。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100134_f3007893_7380811.png "屏幕截图.png")
如下图所示，单击 “购买弹性云服务器”，进入Ai1配置购买界面。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100224_5ff745bb_7380811.png "屏幕截图.png")

## 2-配置Ai1并购买。
### 2.1. 基础配置
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100323_b618d306_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0209/143744_59e9b761_5423530.png "屏幕截图.png")
### 2.2. 网络配置
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100358_adc1f706_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100415_7fa9c4ae_7380811.png "屏幕截图.png")
### 2.3. 高级配置
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100639_678db60e_7380811.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100648_61919df4_7380811.png "屏幕截图.png")
### 2.4. 确认配置操作
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100720_fbe69d85_7380811.png "屏幕截图.png")
### 2.5. 配置完成后，重新进入云服务器控制台
生成的弹性云服务器如下图所示。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100803_89da2622_7380811.png "屏幕截图.png")
云服务器的弹性公网ip就是云服务器的外网ip地址，如下图示所示。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0202/100822_68d0e0da_7380811.png "屏幕截图.png")
