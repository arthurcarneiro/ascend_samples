运行环境搭建–用镜像恢复的方式
以下过程在windows上直接操作，推荐用Etcher工具快速恢复镜像至您的SD卡。
1.下载Etcher工具、sd卡镜像
Etcher工具下载地址：https://www.balena.io/etcher/

sd卡镜像下载地址（复制到浏览器直接下载）：
20.1：
https://c7xcode.obs.cn-north-4.myhuaweicloud.com/sdimg/c75images20201114.img.tar.gz   
20.2：
https://c7xcode.obs.cn-north-4.myhuaweicloud.com/sdimg/176-catenation-32G-20210308.zip


2.恢复镜像
解压镜像后，打开Etcher工具，选择img文件和sd卡设备，点击Flash，一直等到Flash成功，usb3.0大概需要20分钟左右。
![输入图片说明](https://images.gitee.com/uploads/images/2021/0316/093003_afc93698_7985487.png "屏幕截图.png")

拔出sd卡，将其插入Atlas200DK开发板中，上电启动，开发板会进行自动升级固件、重启灯动作，大概需要等待5分钟左右，四个led灯全亮，至此大功告成！！！


